'use client'

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  showConfirmDialog,
  showSuccessAlert,
  showErrorAlert
} from '@/app/utils/sweetalerts'

interface LibraryUser {
  id: number
  full_name: string
  user_type: 'STUDENT' | 'EMPLOYEE' | 'ALUMNI'
  email?: string
  course?: string
  year_level?: string
  department?: string
  status: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED'
  is_archived: boolean
  created_at: string
  last_activity?: string
}

export default function LibraryUsersPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [users, setUsers] = useState<LibraryUser[]>([])
  const [loading, setLoading] = useState(true)
  const [authReady, setAuthReady] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [userTypeFilter, setUserTypeFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(15)

  useEffect(() => {
    const checkAuth = async () => {
      if (status === 'loading') {
        return
      }

      if (status === 'authenticated' && session?.user) {
        console.log('NextAuth session ready for library users')
        setAuthReady(true)
      } else {
        try {
          const response = await fetch('/api/users/profile', {
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json',
            },
          })
          
          if (response.ok) {
            console.log('JWT token authentication ready for library users')
            setAuthReady(true)
          } else {
            console.warn('No valid authentication found, redirecting to login')
            router.push('/login')
            return
          }
        } catch (error) {
          console.warn('Auth check failed, redirecting to login:', error)
          router.push('/login')
          return
        }
      }
    }

    checkAuth()
  }, [session, status, router])

  useEffect(() => {
    if (authReady) {
      fetchLibraryUsers()
    }
  }, [authReady])

  const fetchLibraryUsers = async () => {
    try {
      setLoading(true)
      console.log('Fetching library users...')
      
      const response = await fetch('/api/library-users', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
      })
      
      console.log('Library users API response status:', response.status)
      
      if (response.ok) {
        const data = await response.json()
        console.log('Fetched library users:', data)
        setUsers(data.users || data)
      } else {
        const errorData = await response.text()
        console.error('Failed to fetch library users:', response.status, errorData)
        
        if (response.status === 403) {
          router.push('/dashboard')
        } else if (response.status === 401) {
          router.push('/login')
        } else {
          showErrorAlert('Error', 'Failed to fetch library users')
        }
      }
    } catch (error) {
      console.error('Error fetching library users:', error)
      showErrorAlert('Error', 'Network error occurred while fetching library users')
    } finally {
      setLoading(false)
    }
  }

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.course?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.department?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = !statusFilter || 
      (statusFilter === 'ACTIVE' && user.status === 'ACTIVE') ||
      (statusFilter === 'INACTIVE' && user.status === 'INACTIVE') ||
      (statusFilter === 'ARCHIVED' && user.is_archived)

    const matchesUserType = !userTypeFilter || user.user_type === userTypeFilter

    return matchesSearch && matchesStatus && matchesUserType
  })

  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentUsers = filteredUsers.slice(startIndex, endIndex)

  useEffect(() => {
    setCurrentPage(1)
  }, [searchTerm, statusFilter, userTypeFilter])

  const getStatusBadgeColor = (user: LibraryUser) => {
    if (user.is_archived) return 'bg-gray-100 text-gray-800'
    return user.status === 'ACTIVE'
      ? 'bg-green-100 text-green-800' 
      : 'bg-red-100 text-red-800'
  }

  const getUserTypeBadgeColor = (userType: string) => {
    switch (userType) {
      case 'STUDENT':
        return 'bg-blue-100 text-blue-800'
      case 'EMPLOYEE':
        return 'bg-green-100 text-green-800'
      case 'ALUMNI':
        return 'bg-purple-100 text-purple-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const handleToggleStatus = async (userId: number, currentStatus: 'ACTIVE' | 'INACTIVE', isArchived: boolean) => {
    if (isArchived) {
      showErrorAlert('Cannot Modify', 'Archived users cannot be modified. Please unarchive first.')
      return
    }

    const action = currentStatus === 'ACTIVE' ? 'deactivate' : 'activate'
    const confirmed = await showConfirmDialog(
      `${action.charAt(0).toUpperCase() + action.slice(1)} User`,
      `Are you sure you want to ${action} this library user?`,
      `Yes, ${action} it!`
    )

    if (confirmed) {
      try {
        const response = await fetch(`/api/library-users/${userId}/toggle-status`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        })

        if (response.ok) {
          showSuccessAlert('Success', `Library user ${action}d successfully`)
          await fetchLibraryUsers()
        } else {
          showErrorAlert('Error', `Failed to ${action} library user`)
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
        console.error('Error toggling user status:', error)
      }
    }
  }

  const handleArchiveUser = async (userId: number, fullName: string, isArchived: boolean) => {
    const action = isArchived ? 'unarchive' : 'archive'
    const warningText = isArchived 
      ? 'This will restore the user\'s access and allow the record to be edited.'
      : 'This will lock the user record from edits and disable their access. This action should be used for users who are no longer active (graduated students, former employees).'
    
    const confirmed = await showConfirmDialog(
      `${action.charAt(0).toUpperCase() + action.slice(1)} User`,
      `Are you sure you want to ${action} "${fullName}"?\n\n${warningText}`,
      `Yes, ${action} it!`
    )

    if (confirmed) {
      try {
        const response = await fetch(`/api/library-users/${userId}/archive`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({ archive: !isArchived })
        })

        if (response.ok) {
          showSuccessAlert('Success', `Library user ${action}d successfully`)
          await fetchLibraryUsers()
        } else {
          showErrorAlert('Error', `Failed to ${action} library user`)
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
        console.error('Error archiving user:', error)
      }
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString()
  }

  if (!authReady) {
    return (
      <div className="px-6 py-4">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <div className="text-sm text-gray-600">Checking authentication...</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold text-gray-800">
              Library Users Management
            </h1>
            <Link 
              href="/users/register" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
            >
              Register New User
            </Link>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            Manage students, employees, and alumni with library access
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-4">
        {/* Search and Filters */}
        <div className="mb-6 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">User Type</label>
                <select
                  value={userTypeFilter}
                  onChange={(e) => setUserTypeFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Types</option>
                  <option value="STUDENT">Students</option>
                  <option value="EMPLOYEE">Employees</option>
                  <option value="ALUMNI">Alumni</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">All Status</option>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                  <option value="ARCHIVED">Archived</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Per Page</label>
                <select
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(Number(e.target.value))
                    setCurrentPage(1)
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value={15}>15 per page</option>
                  <option value={25}>25 per page</option>
                  <option value={50}>50 per page</option>
                  <option value={100}>100 per page</option>
                </select>
              </div>
            </div>

            <div className="lg:w-80">
              <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
              <input
                type="text"
                placeholder="Search by name, email, course, or department..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Library Users Table */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          {loading ? (
            <div className="p-8 text-center">
              <div className="text-gray-500">Loading library users...</div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Library User
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Details
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Registered
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {currentUsers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                        {searchTerm || statusFilter || userTypeFilter ? 'No library users found matching your filters.' : 'No library users found.'}
                      </td>
                    </tr>
                  ) : (
                    currentUsers.map((user) => (
                      <tr key={user.id} className={`hover:bg-gray-50 ${user.is_archived ? 'opacity-60' : ''}`}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <div className={`h-10 w-10 rounded-full ${user.is_archived ? 'bg-gray-400' : 'bg-indigo-500'} flex items-center justify-center`}>
                                <span className="text-sm font-medium text-white">
                                  {user.full_name ? user.full_name.charAt(0).toUpperCase() : '?'}
                                </span>
                              </div>
                            </div>
                            <div className="ml-4">
                              <div className={`text-sm font-medium ${user.is_archived ? 'text-gray-600' : 'text-gray-900'}`}>
                                {user.full_name || 'N/A'}
                                {user.is_archived && (
                                  <span className="ml-2 text-xs text-red-600 font-medium">(ARCHIVED)</span>
                                )}
                              </div>
                              {user.email && (
                                <div className="text-sm text-gray-500">{user.email}</div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getUserTypeBadgeColor(user.user_type)}`}>
                            {user.user_type.charAt(0) + user.user_type.slice(1).toLowerCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {user.user_type === 'STUDENT' && (
                            <div>
                              {user.course && <div className="font-medium">{user.course}</div>}
                              {user.year_level && <div className="text-xs text-gray-500">{user.year_level}</div>}
                            </div>
                          )}
                          {user.user_type === 'EMPLOYEE' && user.department && (
                            <div className="font-medium">{user.department}</div>
                          )}
                          {user.user_type === 'ALUMNI' && user.course && (
                            <div>
                              <div className="font-medium">Alumni</div>
                              <div className="text-xs text-gray-500">{user.course}</div>
                            </div>
                          )}
                          {!user.course && !user.department && (
                            <span className="text-gray-500">No details</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadgeColor(user)}`}>
                            {user.is_archived ? 'Archived' : (user.status === 'ACTIVE' ? 'Active' : 'Inactive')}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {formatDate(user.created_at)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex gap-1">
                            <Link
                              href={`/users/${user.id}`}
                              className="text-gray-600 hover:text-gray-900 px-2 py-1 text-sm border border-gray-600 hover:bg-gray-50 rounded transition-colors"
                              title="View Details"
                            >
                              <i className="fas fa-eye"></i>
                            </Link>
                            
                            <Link
                              href={user.is_archived ? '#' : `/users/${user.id}/edit`}
                              className={`px-2 py-1 text-sm border rounded transition-colors ${
                                user.is_archived 
                                  ? 'text-gray-400 border-gray-300 cursor-not-allowed'
                                  : 'text-blue-600 hover:text-blue-900 border-blue-600 hover:bg-blue-50'
                              }`}
                              title={user.is_archived ? 'Cannot edit archived users' : 'Edit User'}
                              onClick={user.is_archived ? (e) => e.preventDefault() : undefined}
                            >
                              <i className="fas fa-edit"></i>
                            </Link>
                            
                            <button
                              onClick={() => {
                                if (!user.is_archived && (user.status === 'ACTIVE' || user.status === 'INACTIVE')) {
                                  handleToggleStatus(user.id, user.status, user.is_archived)
                                }
                              }}
                              disabled={user.is_archived || user.status === 'ARCHIVED'}
                              className={`px-2 py-1 text-sm border rounded transition-colors ${
                                user.is_archived || user.status === 'ARCHIVED'
                                  ? 'text-gray-400 border-gray-300 cursor-not-allowed'
                                  : user.status === 'ACTIVE'
                                    ? 'text-orange-600 hover:text-orange-900 border-orange-600 hover:bg-orange-50' 
                                    : 'text-green-600 hover:text-green-900 border-green-600 hover:bg-green-50'
                              }`}
                              title={user.is_archived || user.status === 'ARCHIVED' ? 'Cannot modify archived users' : (user.status === 'ACTIVE' ? 'Deactivate User' : 'Activate User')}
                            >
                              <i className={`fas ${user.status === 'ACTIVE' ? 'fa-user-slash' : 'fa-user-check'}`}></i>
                            </button>
                            
                            <button
                              onClick={() => handleArchiveUser(user.id, user.full_name, user.is_archived)}
                              className={`px-2 py-1 text-sm border rounded transition-colors ${
                                user.is_archived
                                  ? 'text-blue-600 hover:text-blue-900 border-blue-600 hover:bg-blue-50'
                                  : 'text-red-600 hover:text-red-900 border-red-600 hover:bg-red-50'
                              }`}
                              title={user.is_archived ? 'Unarchive User' : 'Archive User'}
                            >
                              <i className={`fas ${user.is_archived ? 'fa-box-open' : 'fa-archive'}`}></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Pagination */}
        {!loading && filteredUsers.length > 0 && totalPages > 1 && (
          <div className="mt-4 flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Showing {startIndex + 1} to {Math.min(endIndex, filteredUsers.length)} of {filteredUsers.length} library users
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>

              <div className="flex space-x-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNumber;
                  if (totalPages <= 5) {
                    pageNumber = i + 1;
                  } else if (currentPage <= 3) {
                    pageNumber = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    pageNumber = totalPages - 4 + i;
                  } else {
                    pageNumber = currentPage - 2 + i;
                  }

                  return (
                    <button
                      key={pageNumber}
                      onClick={() => setCurrentPage(pageNumber)}
                      className={`px-3 py-1 text-sm border rounded-md ${
                        currentPage === pageNumber
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {pageNumber}
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        )}

        {/* Summary */}
        {!loading && (
          <div className="mt-4 text-sm text-gray-600">
            {totalPages <= 1 && `Showing ${filteredUsers.length} library users`}
          </div>
        )}
      </div>
    </>
  )
}
