'use client'

import React, { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import OverdueBooksTable from '@/components/overdue/OverdueBooksTable'
import OverdueLockerTable from '@/components/overdue/OverdueLockerTable'
import {
  showErrorAlert,
  showSuccessAlert
} from '@/app/utils/sweetalerts'

interface OverdueBook {
  transaction_id: number
  borrow_date: string
  due_date: string
  penalty: number
  days_overdue: number
  calculated_penalty: number
  book: {
    title: string
    book_author: string
    category: string
  }
  user: {
    full_name: string
    email: string
    user_type: string
    course?: string
    department?: string
    contact_number?: string
    account_id: string
  }
}

interface OverdueLocker {
  transaction_id: number
  borrow_time: string
  penalty: number
  hours_used: number
  days_used: number
  calculated_penalty: number
  locker: {
    locker_number: string
    status: string
  }
  user: {
    full_name: string
    email: string
    user_type: string
    course?: string
    department?: string
    contact_number?: string
    account_id: string
  }
}

interface OverdueData {
  overdue_books?: OverdueBook[]
  overdue_lockers?: OverdueLocker[]
  summary: {
    total_overdue_books: number
    total_overdue_lockers: number
    total_book_penalties: number
    total_locker_penalties: number
  }
}

export default function OverdueManagementPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [overdueData, setOverdueData] = useState<OverdueData | null>(null)
  const [loading, setLoading] = useState(true)
  const [authReady, setAuthReady] = useState(false)
  const [activeTab, setActiveTab] = useState<'books' | 'lockers'>('books')
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState('all')

  useEffect(() => {
    const checkAuth = async () => {
      if (status === 'loading') {
        return
      }

      if (status === 'authenticated' && session?.user) {
        console.log('NextAuth session ready for overdue management')
        setAuthReady(true)
      } else {
        try {
          const response = await fetch('/api/users/profile', {
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json',
            },
          })
          
          if (response.ok) {
            console.log('JWT token authentication ready for overdue management')
            setAuthReady(true)
          } else {
            console.warn('No valid authentication found, redirecting to login')
            router.push('/login')
            return
          }
        } catch (error) {
          console.warn('Auth check failed, redirecting to login:', error)
          router.push('/login')
          return
        }
      }
    }

    checkAuth()
  }, [session, status, router])

  const fetchOverdueData = useCallback(async (type: 'all' | 'books' | 'lockers' = 'all') => {
    try {
      setLoading(true)
      console.log('Fetching overdue data...', type)
      
      const response = await fetch(`/api/overdue?type=${type}`, {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
      })
      
      console.log('Overdue API response status:', response.status)
      
      if (response.ok) {
        const data = await response.json()
        console.log('Fetched overdue data:', data)
        setOverdueData(data)
      } else {
        const errorData = await response.text()
        console.error('Failed to fetch overdue data:', response.status, errorData)
        
        if (response.status === 403) {
          router.push('/dashboard')
        } else if (response.status === 401) {
          router.push('/login')
        } else {
          showErrorAlert('Error', 'Failed to fetch overdue data')
        }
      }
    } catch (error) {
      console.error('Error fetching overdue data:', error)
      showErrorAlert('Error', 'Network error occurred while fetching overdue data')
    } finally {
      setLoading(false)
    }
  }, [router])

  useEffect(() => {
    if (authReady) {
      fetchOverdueData()
    }
  }, [authReady, fetchOverdueData])

  const handleRefresh = () => {
    fetchOverdueData()
  }

  const filteredBooks = overdueData?.overdue_books?.filter(book => {
    const matchesSearch = 
      book.book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.user.account_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.book.book_author.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesFilter = 
      filterType === 'all' ||
      (filterType === 'student' && book.user.user_type === 'STUDENT') ||
      (filterType === 'employee' && book.user.user_type === 'EMPLOYEE') ||
      (filterType === 'critical' && book.days_overdue > 30)

    return matchesSearch && matchesFilter
  }) || []

  const filteredLockers = overdueData?.overdue_lockers?.filter(locker => {
    const matchesSearch = 
      locker.locker.locker_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      locker.user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      locker.user.account_id.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesFilter = 
      filterType === 'all' ||
      (filterType === 'student' && locker.user.user_type === 'STUDENT') ||
      (filterType === 'employee' && locker.user.user_type === 'EMPLOYEE') ||
      (filterType === 'critical' && locker.days_used > 7)

    return matchesSearch && matchesFilter
  }) || []

  if (!authReady) {
    return (
      <div className="px-6 py-4">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <div className="text-sm text-gray-600">Checking authentication...</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-gray-800">
                Overdue Management
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                Monitor and manage overdue books and locker usage
              </p>
            </div>
            <button
              onClick={handleRefresh}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors disabled:opacity-50"
            >
              {loading ? 'Refreshing...' : 'Refresh Data'}
            </button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      {overdueData && (
        <div className="px-6 py-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white p-4 rounded-lg shadow-sm border">
              <div className="text-2xl font-bold text-red-600">
                {overdueData.summary.total_overdue_books}
              </div>
              <div className="text-sm text-gray-600">Overdue Books</div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border">
              <div className="text-2xl font-bold text-orange-600">
                {overdueData.summary.total_overdue_lockers}
              </div>
              <div className="text-sm text-gray-600">Overdue Lockers</div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border">
              <div className="text-2xl font-bold text-red-600">
                ₱{overdueData.summary.total_book_penalties.toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Book Penalties</div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border">
              <div className="text-2xl font-bold text-orange-600">
                ₱{overdueData.summary.total_locker_penalties.toFixed(2)}
              </div>
              <div className="text-sm text-gray-600">Locker Penalties</div>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <div className="px-6 py-4">
        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('books')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'books'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Overdue Books ({filteredBooks.length})
            </button>
            <button
              onClick={() => setActiveTab('lockers')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'lockers'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Overdue Lockers ({filteredLockers.length})
            </button>
          </nav>
        </div>

        {/* Filters and Search */}
        <div className="mb-6 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Filter by Type</label>
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Users</option>
                  <option value="student">Students</option>
                  <option value="employee">Employees</option>
                  <option value="critical">Critical (Books: 30+ days, Lockers: 7+ days)</option>
                </select>
              </div>
            </div>

            <div className="lg:w-80">
              <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
              <input
                type="text"
                placeholder="Search by name, ID, book title, locker number..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Content based on active tab */}
        {loading ? (
          <div className="p-8 text-center">
            <div className="text-gray-500">Loading overdue data...</div>
          </div>
        ) : (
          <>
            {activeTab === 'books' && (
              <OverdueBooksTable 
                books={filteredBooks}
                onRefresh={handleRefresh}
              />
            )}
            {activeTab === 'lockers' && (
              <OverdueLockerTable 
                lockers={filteredLockers}
                onRefresh={handleRefresh}
              />
            )}
          </>
        )}
      </div>
    </>
  )
}
