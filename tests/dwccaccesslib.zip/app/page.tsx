'use client'

import React, { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('')
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchTerm.trim()) {
      router.push(`/browse?search=${encodeURIComponent(searchTerm.trim())}`)
    } else {
      router.push('/browse')
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left side - Title and Browse Books */}
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-bold text-gray-900">
                DWCC AccessLib
              </h1>
              <Link
                href="/browse"
                className="text-gray-700 hover:text-green-600 font-medium transition-colors"
              >
                Browse Books
              </Link>
            </div>
            
            {/* Right side - Login Button */}
            <div>
              <Link
                href="/login"
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors inline-flex items-center"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Staff Login
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content - Centered Search */}
      <main className="flex-1 flex items-center justify-center py-32">
        <div className="max-w-2xl w-full px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Welcome to DWCC AccessLib
            </h2>

          </div>
          
          {/* Search Form */}
          <form onSubmit={handleSearch} className="mb-8">
            <div className="flex gap-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Search by title, author, or keyword..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-6 py-4 text-lg border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent shadow-sm"
                />
              </div>
              <button
                type="submit"
                className="px-8 py-4 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors shadow-sm"
              >
                <i className="fas fa-search text-xl"></i>
              </button>
            </div>
          </form>
          
          {/* Quick Actions */}
          <div className="text-center">

            <Link
              href="/browse"
              className="inline-flex items-center px-6 py-3 border border-green-600 text-green-600 rounded-lg hover:bg-green-50 transition-colors font-medium"
            >
              <i className="fas fa-book mr-2"></i>
              Browse All Books
            </Link>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              DWCC AccessLib
            </h3>
            <p className="text-gray-600 mb-6">
              Digital library access management system providing easy access to our comprehensive book collection.
            </p>
            
            {/* Centered Links */}
            <div className="flex justify-center space-x-8 mb-8">
              <Link
                href="/about"
                className="text-green-600 hover:text-green-800 transition-colors font-medium"
              >
                About AccessLib
              </Link>
              <Link
                href="/contact"
                className="text-green-600 hover:text-green-800 transition-colors font-medium"
              >
                Contact Us
              </Link>
            </div>
            
            {/* Copyright */}
            <div className="pt-6 border-t border-gray-200">
              <p className="text-gray-500 text-sm mb-2">
                &copy; 2024 DWCC AccessLib. All rights reserved.
              </p>
              
              {/* Credits */}
              <div className="text-xs text-gray-400">
                <p>Developed with ❤️ for Digital Library Management</p>
                <p className="mt-1">Powered by Next.js, TypeScript & Tailwind CSS</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
