'use client'

import React, { useState, useEffect, Suspense } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'

interface Book {
  book_id: number
  title: string
  book_author: string
  category: string
  status: string
}

interface BooksResponse {
  success: boolean
  books: Book[]
  categories: string[]
  pagination: {
    page: number
    limit: number
    totalCount: number
    totalPages: number
    hasMore: boolean
  }
}

function BrowseContent() {
  const searchParams = useSearchParams()
  const [books, setBooks] = useState<Book[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState(searchParams?.get('search') || '')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [totalCount, setTotalCount] = useState(0)
  const [totalPages, setTotalPages] = useState(1)
  const [selectedBook, setSelectedBook] = useState<Book | null>(null)
  const [showBookModal, setShowBookModal] = useState(false)
  const itemsPerPage = 12

  useEffect(() => {
    fetchBooks()
  }, [searchTerm, selectedCategory, currentPage])

  const fetchBooks = async () => {
    try {
      setLoading(true)
      
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: itemsPerPage.toString()
      })
      
      if (searchTerm) params.append('search', searchTerm)
      if (selectedCategory) params.append('category', selectedCategory)
      
      const response = await fetch(`/api/public/books?${params.toString()}`)
      
      if (response.ok) {
        const data: BooksResponse = await response.json()
        setBooks(data.books)
        setCategories(data.categories)
        setTotalCount(data.pagination.totalCount)
        setTotalPages(data.pagination.totalPages)
      } else {
        console.error('Failed to fetch books:', response.status)
      }
    } catch (error) {
      console.error('Error fetching books:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setCurrentPage(1)
    fetchBooks()
  }

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category)
    setCurrentPage(1)
  }

  const handleBookClick = (book: Book) => {
    setSelectedBook(book)
    setShowBookModal(true)
  }

  const closeModal = () => {
    setShowBookModal(false)
    setSelectedBook(null)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Left side - Title and Home link */}
            <div className="flex items-center space-x-8">
              <Link href="/" className="text-2xl font-bold text-gray-900 hover:text-green-600 transition-colors">
                DWCC AccessLib
              </Link>
              <span className="text-gray-500">|</span>
              <span className="text-gray-700 font-medium">Browse Books</span>
            </div>
            
            {/* Right side - Login Button */}
            <div>
              <Link
                href="/login"
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors inline-flex items-center"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Staff Login
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Search Section */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
            <div className="flex gap-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Search by title, author, or keyword..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <button
                type="submit"
                className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors"
              >
                <i className="fas fa-search"></i>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Category Filter Bar */}
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm p-4">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 text-center">
              Browse by Category
            </h3>
            <div className="flex flex-wrap justify-center gap-2">
              <button
                onClick={() => handleCategoryChange('')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === ''
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-green-100 hover:text-green-800'
                }`}
              >
                All Categories ({totalCount})
              </button>
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => handleCategoryChange(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    selectedCategory === category
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-green-100 hover:text-green-800'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Books Grid */}
        <div>
          {/* Results Summary */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <p className="text-gray-600">
                {loading ? 'Loading...' : `Showing ${books.length} of ${totalCount} available books`}
                {searchTerm && ` for "${searchTerm}"`}
                {selectedCategory && ` in "${selectedCategory}"`}
              </p>
              
              {/* Clear Filters */}
              {(searchTerm || selectedCategory) && (
                <button
                  onClick={() => {
                    setSearchTerm('')
                    setSelectedCategory('')
                    setCurrentPage(1)
                  }}
                  className="text-sm text-green-600 hover:text-green-800 transition-colors"
                >
                  Clear Filters
                </button>
              )}
            </div>
          </div>

          {/* Loading State */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-sm p-4 animate-pulse">
                  <div className="h-32 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </div>
              ))}
            </div>
          ) : books.length === 0 ? (
            <div className="text-center py-12">
              <i className="fas fa-book-open text-4xl text-gray-300 mb-4"></i>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No books found
              </h3>
              <p className="text-gray-600">
                {searchTerm || selectedCategory
                  ? 'Try adjusting your search or filters'
                  : 'No books are currently available in the library'}
              </p>
            </div>
          ) : (
            <>
              {/* Books Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {books.map((book) => (
                  <div
                    key={book.book_id}
                    onClick={() => handleBookClick(book)}
                    className="bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer transform hover:-translate-y-1"
                  >
                    <div className="p-4">
                      {/* Book Icon */}
                      <div className="h-32 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center mb-4">
                        <i className="fas fa-book text-white text-3xl"></i>
                      </div>
                      
                      {/* Book Details */}
                      <h3 className="text-sm font-semibold text-gray-900 mb-2 line-clamp-2 h-10">
                        {book.title}
                      </h3>
                      <p className="text-sm text-gray-600 mb-2">
                        by {book.book_author}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="inline-flex px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                          {book.category}
                        </span>
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                          <i className="fas fa-check-circle mr-1"></i>
                          Available
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="mt-8 flex items-center justify-center space-x-2">
                  <button
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <i className="fas fa-chevron-left"></i>
                  </button>
                  
                  {/* Page Numbers */}
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNumber;
                    if (totalPages <= 5) {
                      pageNumber = i + 1;
                    } else if (currentPage <= 3) {
                      pageNumber = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNumber = totalPages - 4 + i;
                    } else {
                      pageNumber = currentPage - 2 + i;
                    }

                    return (
                      <button
                        key={pageNumber}
                        onClick={() => setCurrentPage(pageNumber)}
                        className={`px-3 py-2 text-sm border rounded-md transition-colors ${
                          currentPage === pageNumber
                            ? 'bg-green-600 text-white border-green-600'
                            : 'border-gray-300 hover:bg-gray-50'
                        }`}
                      >
                        {pageNumber}
                      </button>
                    );
                  })}
                  
                  <button
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <i className="fas fa-chevron-right"></i>
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </main>

      {/* Book Details Modal */}
      {showBookModal && selectedBook && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">
                  Book Details
                </h2>
                <button
                  onClick={closeModal}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>
              
              <div className="space-y-4">
                {/* Book Icon */}
                <div className="h-40 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center">
                  <i className="fas fa-book text-white text-4xl"></i>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {selectedBook?.title || 'Unknown Title'}
                  </h3>
                  <p className="text-gray-600 mb-2">
                    <strong>Author:</strong> {selectedBook?.book_author || 'Unknown Author'}
                  </p>
                  <p className="text-gray-600 mb-2">
                    <strong>Category:</strong> {selectedBook?.category || 'Unknown Category'}
                  </p>
                  <p className="text-gray-600 mb-4">
                    <strong>Status:</strong>
                    <span className="inline-flex items-center ml-2 px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                      <i className="fas fa-check-circle mr-1"></i>
                      Available
                    </span>
                  </p>
                  <p className="text-gray-600 text-sm">
                    <strong>Book ID:</strong> {selectedBook?.book_id || 'N/A'}
                  </p>
                </div>
                
                <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                  <div className="flex items-start">
                    <i className="fas fa-info-circle text-blue-600 mt-1 mr-3"></i>
                    <div className="text-sm text-blue-800">
                      <p className="font-medium mb-1">How to borrow this book:</p>
                      <p>Contact the library staff or visit the circulation desk to request this book for borrowing.</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button
                  onClick={closeModal}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              DWCC AccessLib
            </h3>
            <p className="text-gray-600 mb-6">
              Digital library access management system providing easy access to our comprehensive book collection.
            </p>
            
            {/* Centered Links */}
            <div className="flex justify-center space-x-8 mb-8">
              <Link
                href="/about"
                className="text-green-600 hover:text-green-800 transition-colors font-medium"
              >
                About AccessLib
              </Link>
              <Link
                href="/contact"
                className="text-green-600 hover:text-green-800 transition-colors font-medium"
              >
                Contact Us
              </Link>
            </div>
            
            {/* Copyright */}
            <div className="pt-6 border-t border-gray-200">
              <p className="text-gray-500 text-sm mb-2">
                &copy; 2025 DWCC AccessLib. All rights reserved.
              </p>
              
              {/* Credits */}
              <div className="text-xs text-gray-400">
                <p>Developed with ❤️ for Digital Library Management</p>
                <p className="mt-1">Powered by Next.js, TypeScript & Tailwind CSS</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

function LoadingFallback() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Loading book catalog...</p>
      </div>
    </div>
  )
}

export default function Browse() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <BrowseContent />
    </Suspense>
  )
}
