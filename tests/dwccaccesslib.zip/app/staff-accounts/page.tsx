'use client'

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  showConfirmDialog,
  showSuccessAlert,
  showErrorAlert,
  showLoadingAlert,
  showPasswordResetSuccess,
  showPasswordResetDialog
} from '@/app/utils/sweetalerts'
import { useProtectedAction } from '@/hooks/useUserStatus'

interface User {
  id: number
  username: string
  role: string
  is_active: boolean
  user: {
    full_name: string
    user_type: string
    email?: string
    course?: string
    year_level?: string
    department?: string
  }
}

function StaffAccounts() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [authReady, setAuthReady] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(10)
  const executeProtectedAction = useProtectedAction()

  useEffect(() => {
    const checkAuth = async () => {
      if (status === 'loading') {
        return
      }

      if (status === 'authenticated' && session?.user) {
        console.log('NextAuth session ready for staff accounts')
        setAuthReady(true)
      } else {
        try {
          const response = await fetch('/api/users/profile', {
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json',
            },
          })
          
          if (response.ok) {
            console.log('JWT token authentication ready for staff accounts')
            setAuthReady(true)
          } else {
            console.warn('No valid authentication found, redirecting to login')
            router.push('/login')
            return
          }
        } catch (error) {
          console.warn('Auth check failed, redirecting to login:', error)
          router.push('/login')
          return
        }
      }
    }

    checkAuth()
  }, [session, status, router])

  useEffect(() => {
    if (authReady) {
      fetchStaffUsers()
    }
  }, [authReady])

  const fetchStaffUsers = async () => {
    try {
      setLoading(true)
      console.log('Fetching staff users...')
      
      const response = await fetch('/api/users/by-role/staff', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
      })
      
      console.log('Staff users API response status:', response.status)
      
      if (response.ok) {
        const data = await response.json()
        console.log('Fetched staff users:', data)
        setUsers(data)
      } else {
        const errorData = await response.text()
        console.error('Failed to fetch staff users:', response.status, errorData)
        
        if (response.status === 403) {
          router.push('/dashboard')
        } else if (response.status === 401) {
          router.push('/login')
        } else {
          showErrorAlert('Error', 'Failed to fetch staff users')
        }
      }
    } catch (error) {
      console.error('Error fetching staff users:', error)
      showErrorAlert('Error', 'Network error occurred while fetching staff users')
    } finally {
      setLoading(false)
    }
  }

  const refreshData = () => {
    fetchStaffUsers()
  }

  useEffect(() => {
    window.refreshStaffAccounts = refreshData
    return () => {
      delete window.refreshStaffAccounts
    }
  }, [])

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.user?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.user?.email?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = !statusFilter || 
      (statusFilter === 'ACTIVE' && user.is_active === true) ||
      (statusFilter === 'INACTIVE' && user.is_active === false)

    return matchesSearch && matchesStatus
  })

  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentUsers = filteredUsers.slice(startIndex, endIndex)

  useEffect(() => {
    setCurrentPage(1)
  }, [searchTerm, statusFilter])

  const getStatusBadgeColor = (is_active: boolean) => {
    return is_active
      ? 'bg-green-100 text-green-800' 
      : 'bg-red-100 text-red-800'
  }

  const handleToggleStatus = async (userId: number, currentStatus: boolean) => {
    await executeProtectedAction(async () => {
      const action = currentStatus ? 'deactivate' : 'activate'
      const confirmed = await showConfirmDialog(
        `${action.charAt(0).toUpperCase() + action.slice(1)} Staff`,
        `Are you sure you want to ${action} this staff account?`,
        `Yes, ${action} it!`
      )

      if (confirmed) {
        try {
          const response = await fetch(`/api/users/${userId}/toggle-status`, {
            method: 'PATCH',
            headers: {
              'Content-Type': 'application/json',
            },
            credentials: 'include',
          })

          if (response.ok) {
            showSuccessAlert('Success', `Staff account ${action}d successfully`)
            
            await fetchStaffUsers()
            
            if (window.refreshAdminAccounts) {
              window.refreshAdminAccounts()
            }
            
            if (window.refreshDashboard) {
              window.refreshDashboard()
            }
          } else {
            showErrorAlert('Error', `Failed to ${action} staff account`)
          }
        } catch (error) {
          showErrorAlert('Error', 'Network error occurred')
          console.error('Error toggling staff status:', error)
        }
      }
    })
  }

  const handleResetPassword = async (userId: number, fullName: string) => {
    await executeProtectedAction(async () => {
      const result = await showPasswordResetDialog(
        'Reset Password',
        `Enter a new temporary password for staff "${fullName}"`
      )

      if (result.isConfirmed && result.value) {
        showLoadingAlert('Resetting password...')
        
        try {
          const response = await fetch(`/api/users/${userId}/reset-password`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify({ newPassword: result.value })
          })

          if (response.ok) {
            showSuccessAlert('Success', 'Password reset successfully')
          } else {
            const errorData = await response.json()
            showErrorAlert('Error', errorData.error || 'Failed to reset password')
          }
        } catch (error) {
          showErrorAlert('Error', 'Network error occurred')
          console.error('Error resetting password:', error)
        }
      }
    })
  }

  if (!authReady) {
    return (
      <div className="px-6 py-4">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <div className="text-sm text-gray-600">Checking authentication...</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold text-gray-800">
              Staff Accounts
            </h1>
            <Link 
              href="/users/register" 
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
            >
              Add New Staff
            </Link>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-4">
        {/* Search and Filters */}
        <div className="mb-6 space-y-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">All Status</option>
                  <option value="ACTIVE">Active</option>
                  <option value="INACTIVE">Inactive</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Per Page</label>
                <select
                  value={itemsPerPage}
                  onChange={(e) => {
                    setItemsPerPage(Number(e.target.value))
                    setCurrentPage(1)
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value={5}>5 per page</option>
                  <option value={10}>10 per page</option>
                  <option value={25}>25 per page</option>
                  <option value={50}>50 per page</option>
                  <option value={100}>100 per page</option>
                </select>
              </div>
            </div>

            <div className="lg:w-80">
              <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
              <input
                type="text"
                placeholder="Search staff by name, id, or email..."
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Staff Users Table */}
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          {loading ? (
            <div className="p-8 text-center">
              <div className="text-gray-500">Loading staff accounts...</div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Staff User
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      User Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Role
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {currentUsers.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                        {searchTerm || statusFilter ? 'No staff accounts found matching your filters.' : 'No staff accounts found.'}
                      </td>
                    </tr>
                  ) : (
                    currentUsers.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              <div className="h-10 w-10 rounded-full bg-green-500 flex items-center justify-center">
                                <span className="text-sm font-medium text-white">
                                  {user.user.full_name ? user.user.full_name.charAt(0).toUpperCase() : 'S'}
                                </span>
                              </div>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm text-gray-500">
                                {user.username}
                              </div>
                              <div className="text-sm font-medium text-gray-900">
                                {user.user.full_name || 'N/A'}
                              </div>
                              {user.user.email && (
                                <div className="text-sm text-gray-500">
                                  {user.user.email}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {user.user.user_type}
                          {user.user.user_type === 'STUDENT' && user.user.course && (
                            <div className="text-xs text-gray-500">
                              {user.user.course}
                              {user.user.year_level && ` - ${user.user.year_level}`}
                            </div>
                          )}
                          {user.user.user_type === 'EMPLOYEE' && user.user.department && (
                            <div className="text-xs text-gray-500">
                              {user.user.department}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                            {user.role}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadgeColor(user.is_active)}`}>
                            {user.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex gap-1">
                            <Link
                              href={`/users/${user.id}`}
                              className="text-gray-600 hover:text-gray-900 px-2 py-1 text-sm border border-gray-600 hover:bg-gray-50 rounded transition-colors"
                              title="View Details"
                            >
                              <i className="fas fa-eye"></i>
                            </Link>
                            
                            <Link
                              href={`/users/${user.id}/edit`}
                              className="text-blue-600 hover:text-blue-900 px-2 py-1 text-sm border border-blue-600 hover:bg-blue-50 rounded transition-colors"
                              title="Edit Staff"
                            >
                              <i className="fas fa-edit"></i>
                            </Link>
                            
                            <button
                              onClick={() => handleToggleStatus(user.id, user.is_active)}
                              className={`px-2 py-1 text-sm border rounded transition-colors ${
                                user.is_active
                                  ? 'text-orange-600 hover:text-orange-900 border-orange-600 hover:bg-orange-50' 
                                  : 'text-green-600 hover:text-green-900 border-green-600 hover:bg-green-50'
                              }`}
                              title={user.is_active ? 'Deactivate Staff' : 'Activate Staff'}
                            >
                              <i className={`fas ${user.is_active ? 'fa-user-slash' : 'fa-user-check'}`}></i>
                            </button>
                            
                            <button
                              onClick={() => handleResetPassword(user.id, user.user.full_name || 'Staff')}
                              className="text-purple-600 hover:text-purple-900 px-2 py-1 text-sm border border-purple-600 hover:bg-purple-50 rounded transition-colors"
                              title="Reset Password"
                            >
                              <i className="fas fa-key"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Pagination */}
        {!loading && filteredUsers.length > 0 && totalPages > 1 && (
          <div className="mt-4 flex items-center justify-between">
            <div className="text-sm text-gray-600">
              Showing {startIndex + 1} to {Math.min(endIndex, filteredUsers.length)} of {filteredUsers.length} staff accounts
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>

              <div className="flex space-x-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNumber;
                  if (totalPages <= 5) {
                    pageNumber = i + 1;
                  } else if (currentPage <= 3) {
                    pageNumber = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    pageNumber = totalPages - 4 + i;
                  } else {
                    pageNumber = currentPage - 2 + i;
                  }

                  return (
                    <button
                      key={pageNumber}
                      onClick={() => setCurrentPage(pageNumber)}
                      className={`px-3 py-1 text-sm border rounded-md ${
                        currentPage === pageNumber
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      {pageNumber}
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        )}

        {!loading && (
          <div className="mt-4 text-sm text-gray-600">
            {totalPages <= 1 && `Showing ${filteredUsers.length} staff accounts`}
          </div>
        )}
      </div>
    </>
  )
}

export default StaffAccounts
