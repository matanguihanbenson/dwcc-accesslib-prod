'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { 
  showErrorAlert, 
  showSuccessAlert, 
  showLoadingAlert 
} from '@/app/utils/sweetalerts'

interface LibraryUser {
  user_id: number
  account_id: string
  full_name: string
  user_type: string
  email?: string
  course?: string
  year_level?: string
  department?: string
}

function AddStaffPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  
  const [libraryUsers, setLibraryUsers] = useState<LibraryUser[]>([])
  const [filteredUsers, setFilteredUsers] = useState<LibraryUser[]>([])
  const [loading, setLoading] = useState(true)
  const [authReady, setAuthReady] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedUser, setSelectedUser] = useState<LibraryUser | null>(null)
  const [showDropdown, setShowDropdown] = useState(false)
  const [isSearchFocused, setIsSearchFocused] = useState(false)
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [role, setRole] = useState('STAFF')
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const checkAuth = async () => {
      if (status === 'loading') {
        return
      }

      if (status === 'authenticated' && session?.user) {
        setAuthReady(true)
      } else {
        try {
          const response = await fetch('/api/users/profile', {
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json',
            },
          })
          
          if (response.ok) {
            setAuthReady(true)
          } else {
            router.push('/login')
            return
          }
        } catch (error) {
          router.push('/login')
          return
        }
      }
    }

    checkAuth()
  }, [session, status, router])

  useEffect(() => {
    if (authReady) {
      fetchLibraryUsers()
    }
  }, [authReady])

  useEffect(() => {
    if (searchTerm.trim()) {
      const filtered = libraryUsers.filter(user =>
        user.account_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email?.toLowerCase().includes(searchTerm.toLowerCase())
      )
      setFilteredUsers(filtered)
      setShowDropdown(true)
    } else {
      setFilteredUsers([])
      setShowDropdown(false)
    }
  }, [searchTerm, libraryUsers])

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element
      if (!target.closest('.user-search-container')) {
        setShowDropdown(false)
        setIsSearchFocused(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])

  const fetchLibraryUsers = async () => {
    try {
      setLoading(true)
      
      const response = await fetch('/api/library-users/available-for-staff', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      
      if (response.ok) {
        const data = await response.json()
        console.log('Fetched library users:', data)
        setLibraryUsers(data)
      } else {
        console.error('Failed to fetch library users:', response.status, response.statusText)
        try {
          const errorData = await response.json()
          console.error('Error details:', errorData)
          showErrorAlert('Error', errorData.error || 'Failed to fetch library users')
        } catch (parseError) {
          const errorText = await response.text()
          console.error('Error response text:', errorText)
          showErrorAlert('Error', 'Failed to fetch library users: ' + response.statusText)
        }
      }
    } catch (error) {
      console.error('Error fetching library users:', error)
      showErrorAlert('Error', 'Network error occurred')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedUser) {
      showErrorAlert('Error', 'Please select a user')
      return
    }

    if (!password || password.length < 4) {
      showErrorAlert('Error', 'Password must be at least 4 characters long')
      return
    }

    if (password !== confirmPassword) {
      showErrorAlert('Error', 'Passwords do not match')
      return
    }

    setSubmitting(true)
    showLoadingAlert('Creating staff account...')

    try {
      const response = await fetch('/api/users/promote-to-staff', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          userId: selectedUser.user_id,
          password: password,
          role: role
        })
      })

      if (response.ok) {
        showSuccessAlert('Success', 'Staff account created successfully')
        router.push('/staff-accounts')
      } else {
        const errorData = await response.json()
        showErrorAlert('Error', errorData.error || 'Failed to create staff account')
      }
    } catch (error) {
      console.error('Error creating staff account:', error)
      showErrorAlert('Error', 'Network error occurred')
    } finally {
      setSubmitting(false)
    }
  }

  if (!authReady) {
    return (
      <div className="px-6 py-4">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <div className="text-sm text-gray-600">Checking authentication...</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => router.back()}
                className="text-gray-600 hover:text-gray-900 transition-colors"
              >
                <i className="fas fa-arrow-left text-lg"></i>
              </button>
              <h1 className="text-xl font-semibold text-gray-800">
                Add New Staff
              </h1>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">
                Promote Library User to Staff
              </h2>
              <p className="text-sm text-gray-600 mt-1">
                Select a library user and create their staff account with login credentials.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="px-6 py-4 space-y-6">
              {/* User Selection */}
              <div className="user-search-container relative">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Library User
                </label>
                
                {/* Selected User Display */}
                {selectedUser && (
                  <div className="mb-3 p-3 bg-blue-50 border border-blue-200 rounded-md">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-gray-900">{selectedUser.full_name}</div>
                        <div className="text-sm text-gray-600">ID: {selectedUser.account_id}</div>
                        {selectedUser.email && (
                          <div className="text-sm text-gray-600">{selectedUser.email}</div>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedUser(null)
                          setSearchTerm('')
                        }}
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        Change
                      </button>
                    </div>
                  </div>
                )}
                
                {/* Search Input */}
                <div className="relative">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder={selectedUser ? 'Search to change user...' : 'Search by account ID, name, or email...'}
                      className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      onFocus={() => {
                        setIsSearchFocused(true)
                        if (searchTerm.trim()) {
                          setShowDropdown(true)
                        }
                      }}
                      disabled={loading}
                    />
                    {loading ? (
                      <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                      </div>
                    ) : (
                      searchTerm && (
                        <button
                          type="button"
                          onClick={() => {
                            setSearchTerm('')
                            setShowDropdown(false)
                          }}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                        >
                          <i className="fas fa-times"></i>
                        </button>
                      )
                    )}
                  </div>

                  {/* Dropdown */}
                  {showDropdown && searchTerm.trim() && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto">
                      {filteredUsers.length === 0 ? (
                        <div className="p-3 text-center text-gray-500 text-sm">
                          No users found matching "{searchTerm}"
                        </div>
                      ) : (
                        <div className="divide-y divide-gray-100">
                          {filteredUsers.map((user) => (
                            <div
                              key={user.user_id}
                              className="p-3 cursor-pointer hover:bg-gray-50 transition-colors duration-150"
                              onClick={() => {
                                setSelectedUser(user)
                                setSearchTerm('')
                                setShowDropdown(false)
                                setIsSearchFocused(false)
                              }}
                            >
                              <div className="flex items-start">
                                <div className="flex-shrink-0 h-8 w-8">
                                  <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                                    <span className="text-xs font-medium text-blue-600">
                                      {user.full_name.charAt(0).toUpperCase()}
                                    </span>
                                  </div>
                                </div>
                                <div className="ml-3 flex-1 min-w-0">
                                  <div className="font-medium text-gray-900 truncate">{user.full_name}</div>
                                  <div className="text-sm text-gray-600">ID: {user.account_id}</div>
                                  {user.email && (
                                    <div className="text-sm text-gray-500 truncate">{user.email}</div>
                                  )}
                                  <div className="text-xs text-gray-400 mt-1">
                                    {user.user_type}
                                    {user.course && ` • ${user.course}`}
                                    {user.year_level && ` • ${user.year_level}`}
                                    {user.department && ` • ${user.department}`}
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Show total available users */}
                {!loading && libraryUsers.length > 0 && !searchTerm && !selectedUser && (
                  <div className="mt-2 text-sm text-gray-500">
                    {libraryUsers.length} library users available for staff promotion
                  </div>
                )}
                
                {!loading && libraryUsers.length === 0 && (
                  <div className="mt-2 text-sm text-gray-500">
                    No library users available for staff promotion
                  </div>
                )}
              </div>

              {/* Role Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Staff Role
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="STAFF">Staff</option>
                  {/* Only SUPER_ADMIN can create other roles */}
                  {(session?.user as any)?.role === 'SUPER_ADMIN' && (
                    <option value="ADMIN">Admin</option>
                  )}
                </select>
              </div>

              {/* Password Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter password (min 4 characters)"
                      required
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'} text-gray-400 hover:text-gray-600`}></i>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Confirm password"
                      required
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      <i className={`fas ${showConfirmPassword ? 'fa-eye-slash' : 'fa-eye'} text-gray-400 hover:text-gray-600`}></i>
                    </button>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => router.back()}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting || !selectedUser}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? 'Creating...' : 'Create Staff Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default AddStaffPage
