"use client"

import { useState, useEffect } from "react"
import { signIn, useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { showErrorAlert, showWarningAlert } from "@/app/utils/sweetalerts"

export default function Login() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const { data: session, status } = useSession()
  const router = useRouter()

  useEffect(() => {
    if (status === "authenticated") {
      router.push("/dashboard")
    }
  }, [status, router])

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-green-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-4"></div>
          <div className="text-gray-600">Loading...</div>
        </div>
      </div>
    )
  }

  if (status === "authenticated") {
    return null
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      // First, check login credentials with our custom API to get specific error info
      const customLoginResponse = await fetch('/api/auth/custom-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password })
      })

      const customLoginData = await customLoginResponse.json()

      // Handle specific error cases
      if (!customLoginResponse.ok) {
        switch (customLoginData.error) {
          case 'ACCOUNT_DEACTIVATED':
            // Show SweetAlert for deactivated account
            await showWarningAlert(
              'Account Deactivated',
              `Hello ${customLoginData.fullName || username},\n\n${customLoginData.message}`
            )
            setError('Account deactivated')
            return
          
          case 'USER_NOT_FOUND':
          case 'INVALID_PASSWORD':
            setError('Invalid username or password')
            return
          
          case 'MISSING_CREDENTIALS':
            setError('Username and password are required')
            return
          
          default:
            setError('An error occurred during login')
            return
        }
      }

      // If custom login succeeded, proceed with NextAuth
      const result = await signIn("credentials", {
        username,
        password,
        redirect: false
      })

      if (result?.error) {
        // This shouldn't happen if our custom login succeeded, but handle it
        await showErrorAlert(
          'Login Error', 
          'An unexpected error occurred during authentication. Please try again.'
        )
        setError("Authentication failed")
      } else {
        // Success - redirect to dashboard
        router.push("/dashboard")
        router.refresh()
      }
    } catch (error) {
      console.error('Login error:', error)
      await showErrorAlert(
        'Connection Error',
        'Unable to connect to the authentication server. Please check your internet connection and try again.'
      )
      setError("Connection error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        {/* System Logo/Icon */}
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mb-6 shadow-lg">
            <i className="fas fa-book-open text-white text-2xl"></i>
          </div>
        </div>
        
        {/* System Title and Subtext */}
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            DWCC AccessLib
          </h1>
          <p className="text-lg text-gray-600 mb-2">
            Log in
          </p>
        </div>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-6 shadow-xl rounded-xl sm:px-10 border border-gray-100">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <i className="fas fa-user text-gray-400"></i>
                </div>
                <input
                  id="username"
                  name="username"
                  type="text"
                  required
                  disabled={loading}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <i className="fas fa-lock text-gray-400"></i>
                </div>
                <input
                  id="password"
                  name="password"
                  type="password"
                  required
                  disabled={loading}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-center">
                  <i className="fas fa-exclamation-triangle text-red-600 mr-3"></i>
                  <span className="text-red-800 text-sm">{error}</span>
                </div>
              </div>
            )}

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-lg text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
              >
                {loading ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Signing in...
                  </>
                ) : (
                  <>
                    <i className="fas fa-sign-in-alt mr-2"></i>
                    Sign in
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Additional Links */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="text-center">
              <p className="text-sm text-gray-600 mb-4">
                Need help accessing your account?
              </p>
              <div className="space-y-2">
                <a 
                  href="#" 
                  className="text-sm text-green-600 hover:text-green-800 transition-colors block"
                >
                  Contact System Administrator
                </a>
                <Link 
                  href="/"
                  className="text-sm text-gray-500 hover:text-gray-700 transition-colors block"
                >
                  ← Back to Library Catalog
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Information */}
        <div className="mt-8 text-center">
          <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-100">

            <p className="text-xs text-gray-500 mt-2">
              © 2025 DWCC AccessLib. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
