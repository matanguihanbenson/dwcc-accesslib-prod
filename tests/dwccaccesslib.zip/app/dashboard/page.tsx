import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { SignOutButton, SuperAdminView, AdminView } from "@/components";

export default async function Dashboard() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect("/login");
  }

  const isSuperAdmin = session.user.role === 'SUPER_ADMIN';
  const isAdmin = session.user.role === 'ADMIN';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <h1 className="text-3xl font-bold text-gray-900">
              {isSuperAdmin ? 'Super Admin Dashboard' : isAdmin ? 'Admin Dashboard' : 'Dashboard'}
            </h1>
            <SignOutButton />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {isSuperAdmin ? (
          <SuperAdminView />
        ) : isAdmin ? (
          <AdminView />
        ) : (
          <div className="border-4 border-dashed border-gray-200 rounded-lg p-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">
              Welcome, {session.user.name}! 🚀
            </h2>
            
            {/* User Information */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-2">User Information</h3>
              <dl className="space-y-2">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Email:</dt>
                  <dd className="text-sm text-gray-900">{session.user.email}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Username:</dt>
                  <dd className="text-sm text-gray-900">{session.user.username}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Role:</dt>
                  <dd className="text-sm text-gray-900">{session.user.role}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">User Type:</dt>
                  <dd className="text-sm text-gray-900">{session.user.userType}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Account ID:</dt>
                  <dd className="text-sm text-gray-900">{session.user.accountId}</dd>
                </div>
              </dl>
            </div>

            {/* Quick Stats */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Stats</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Total Books</span>
                  <span className="text-sm font-medium">1,247</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Active Users</span>
                  <span className="text-sm font-medium">89</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Available Lockers</span>
                  <span className="text-sm font-medium">156</span>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
              <div className="space-y-3">
                <div className="text-sm">
                  <span className="text-gray-500">2 hours ago:</span>
                  <span className="ml-1">New book added</span>
                </div>
                <div className="text-sm">
                  <span className="text-gray-500">4 hours ago:</span>
                  <span className="ml-1">User registered</span>
                </div>
                <div className="text-sm">
                  <span className="text-gray-500">6 hours ago:</span>
                  <span className="ml-1">Locker assigned</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Dashboard Refresh Script */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
            window.refreshDashboard = function() {
              window.location.reload();
            };
          `,
        }}
      />
    </div>
  );
}


