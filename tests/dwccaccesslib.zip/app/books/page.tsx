'use client'

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import {
  showConfirmDialog,
  showSuccessAlert,
  showErrorAlert,
  showInputDialog
} from '@/app/utils/sweetalerts'

interface Book {
  book_id: number
  title: string
  book_author: string
  category: string
  status: 'AVAILABLE' | 'BORROWED' | 'MISSING' | 'DAMAGED'
  created_at?: string
  updated_at?: string
}

interface BorrowTransaction {
  transaction_id: number
  borrow_date: string
  return_date?: string
  due_date: string
  penalty: number
  book: Book
  user: {
    full_name: string
    account_id: string
    user_type: string
  }
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'RETURNED' | 'OVERDUE'
}

export default function BooksPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [books, setBooks] = useState<Book[]>([])
  const [pendingTransactions, setPendingTransactions] = useState<BorrowTransaction[]>([])
  const [loading, setLoading] = useState(true)
  const [authReady, setAuthReady] = useState(false)
  const [activeTab, setActiveTab] = useState<'books' | 'transactions'>('books')
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(20)
  const [showAddBookModal, setShowAddBookModal] = useState(false)
  const [showEditBookModal, setShowEditBookModal] = useState(false)
  const [selectedBookForEdit, setSelectedBookForEdit] = useState<Book | null>(null)
  const [editForm, setEditForm] = useState({
    title: '',
    book_author: '',
    category: '',
    isbn: '',
    publisher: '',
    publication_year: '',
    edition: '',
    pages: '',
    language: 'English',
    description: ''
  })
  const [isUpdating, setIsUpdating] = useState(false)

  useEffect(() => {
    const checkAuth = async () => {
      if (status === 'loading') {
        return
      }

      if (status === 'authenticated' && session?.user) {
        if (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN') {
          console.warn('Access denied: User does not have ADMIN privileges')
          const lastLocation = localStorage.getItem('lastLocation') || '/dashboard'
          router.push(lastLocation)
          return
        }
        console.log('NextAuth session ready for books management')
        setAuthReady(true)
      } else {
        try {
          const response = await fetch('/api/users/profile', {
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json',
            },
          })
          
          if (response.ok) {
            const userData = await response.json()
            if (userData.role !== 'ADMIN' && userData.role !== 'SUPER_ADMIN') {
              console.warn('Access denied: User does not have ADMIN privileges')
              const lastLocation = localStorage.getItem('lastLocation') || '/dashboard'
              router.push(lastLocation)
              return
            }
            console.log('JWT token authentication ready for books management')
            setAuthReady(true)
          } else {
            console.warn('No valid authentication found, redirecting to login')
            router.push('/login')
            return
          }
        } catch (error) {
          console.warn('Auth check failed, redirecting to login:', error)
          router.push('/login')
          return
        }
      }
    }

    checkAuth()
  }, [session, status, router])

  useEffect(() => {
    if (authReady) {
      fetchBooks()
      fetchPendingTransactions()
    }
  }, [authReady])

  useEffect(() => {
    localStorage.setItem('lastLocation', '/books')
  }, [])

  const fetchBooks = async () => {
    try {
      setLoading(true)
      console.log('Fetching books...')
      
      const response = await fetch('/api/books', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        },
      })
      
      console.log('Response status:', response.status)
      console.log('Response ok:', response.ok)
      
      if (response.ok) {
        const data = await response.json()
        console.log('Response data:', data)
        console.log('Books array:', data.books)
        console.log('Books count:', data.books?.length || 0)
        
        if (data.success && data.books) {
          setBooks(data.books)
          console.log('Books set successfully:', data.books.length)
        } else {
          console.warn('Unexpected response format:', data)
          setBooks([])
        }
      } else {
        const errorData = await response.text()
        console.error('Failed to fetch books:', response.status, errorData)
        
        if (response.status === 403) {
          const lastLocation = localStorage.getItem('lastLocation') || '/dashboard'
          router.push(lastLocation)
        } else if (response.status === 401) {
          router.push('/login')
        } else {
          showErrorAlert('Error', `Failed to fetch books: ${response.status}`)
        }
      }
    } catch (error) {
      console.error('Error fetching books:', error)
      showErrorAlert('Error', 'Network error occurred while fetching books')
    } finally {
      setLoading(false)
    }
  }

  const fetchPendingTransactions = async () => {
    try {
      const response = await fetch('/api/books/transactions/pending', {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      })
      
      if (response.ok) {
        const data = await response.json()
        setPendingTransactions(data.transactions || [])
      }
    } catch (error) {
      console.error('Error fetching pending transactions:', error)
    }
  }

  const handleAddBook = async () => {
    const titleResult = await showInputDialog(
      'Add New Book',
      'Enter the book title:',
      'Book title...',
      'text'
    )
    
    if (!titleResult.isConfirmed || !titleResult.value) {
      return
    }
    const title = titleResult.value

    const authorResult = await showInputDialog(
      'Add New Book',
      'Enter the book author:',
      'Author name...',
      'text'
    )
    
    if (!authorResult.isConfirmed || !authorResult.value) {
      return
    }
    const author = authorResult.value

    const categoryResult = await showInputDialog(
      'Add New Book',
      'Enter the book category:',
      'Category...',
      'text'
    )
    
    if (!categoryResult.isConfirmed || !categoryResult.value) {
      return
    }
    const category = categoryResult.value

    try {
      const response = await fetch('/api/books', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          title: title.trim(),
          book_author: author.trim(),
          category: category.trim()
        })
      })

      if (response.ok) {
        showSuccessAlert('Success', 'Book added successfully')
        await fetchBooks()
      } else {
        const errorData = await response.json()
        showErrorAlert('Error', errorData.error || 'Failed to add book')
      }
    } catch (error) {
      showErrorAlert('Error', 'Network error occurred')
      console.error('Error adding book:', error)
    }
  }

  const handleUpdateBookStatus = async (bookId: number, currentStatus: string, bookTitle: string) => {
    const confirmed = await showConfirmDialog(
      `Update Status for "${bookTitle}"`,
      `Current status is ${currentStatus}. Choose a new status from the options that will appear next.`,
      'Continue'
    )

    if (!confirmed) {
      return
    }

    let newStatus = ''
    
    if (currentStatus !== 'AVAILABLE') {
      const makeAvailable = await showConfirmDialog(
        'Set to Available',
        'Mark this book as AVAILABLE?',
        'Yes, Available'
      )
      if (makeAvailable) {
        newStatus = 'AVAILABLE'
      }
    }

    if (!newStatus && currentStatus !== 'BORROWED') {
      const makeBorrowed = await showConfirmDialog(
        'Set to Borrowed', 
        'Mark this book as BORROWED?',
        'Yes, Borrowed'
      )
      if (makeBorrowed) {
        newStatus = 'BORROWED'
      }
    }

    if (!newStatus && currentStatus !== 'MISSING') {
      const makeMissing = await showConfirmDialog(
        'Set to Missing',
        'Mark this book as MISSING?',
        'Yes, Missing'
      )
      if (makeMissing) {
        newStatus = 'MISSING'
      }
    }

    if (!newStatus && currentStatus !== 'DAMAGED') {
      const makeDamaged = await showConfirmDialog(
        'Set to Damaged',
        'Mark this book as DAMAGED?',
        'Yes, Damaged'
      )
      if (makeDamaged) {
        newStatus = 'DAMAGED'
      }
    }

    if (newStatus && newStatus !== currentStatus) {
      try {
        const response = await fetch(`/api/books/${bookId}/status`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({ status: newStatus })
        })

        if (response.ok) {
          showSuccessAlert('Success', 'Book status updated successfully')
          await fetchBooks()
        } else {
          const errorData = await response.json()
          showErrorAlert('Error', errorData.error || 'Failed to update book status')
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
        console.error('Error updating book status:', error)
      }
    }
  }

  const handleApproveTransaction = async (transactionId: number, action: 'approve' | 'reject') => {
    const confirmed = await showConfirmDialog(
      `${action.charAt(0).toUpperCase() + action.slice(1)} Transaction`,
      `Are you sure you want to ${action} this borrowing request?`,
      `Yes, ${action} it!`
    )

    if (confirmed) {
      try {
        const response = await fetch(`/api/books/transactions/${transactionId}/${action}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        })

        if (response.ok) {
          showSuccessAlert('Success', `Transaction ${action}d successfully`)
          await fetchPendingTransactions()
          await fetchBooks()
        } else {
          showErrorAlert('Error', `Failed to ${action} transaction`)
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
        console.error(`Error ${action}ing transaction:`, error)
      }
    }
  }

  const handleApproveReturn = async (transactionId: number) => {
    const confirmed = await showConfirmDialog(
      'Approve Return',
      'Are you sure you want to approve this book return?',
      'Yes, approve it!'
    )

    if (confirmed) {
      try {
        const response = await fetch(`/api/books/transactions/${transactionId}/return`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        })

        if (response.ok) {
          showSuccessAlert('Success', 'Return approved successfully')
          await fetchPendingTransactions()
          await fetchBooks()
        } else {
          showErrorAlert('Error', 'Failed to approve return')
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
        console.error('Error approving return:', error)
      }
    }
  }

  const handleEditBook = (book: Book) => {
    setSelectedBookForEdit(book)
    setEditForm({
      title: book.title || '',
      book_author: book.book_author || '',
      category: book.category || '',
      isbn: '',
      publisher: '',
      publication_year: '',
      edition: '',
      pages: '',
      language: 'English',
      description: ''
    })
    setShowEditBookModal(true)
  }

  const handleUpdateBook = async () => {
    if (!selectedBookForEdit) return
    
    if (!editForm.title.trim() || !editForm.book_author.trim() || !editForm.category.trim()) {
      showErrorAlert('Validation Error', 'Title, Author, and Category are required fields')
      return
    }

    setIsUpdating(true)

    try {
      const updateData = {
        title: editForm.title.trim(),
        book_author: editForm.book_author.trim(),
        category: editForm.category.trim(),
        ...(editForm.isbn.trim() && { isbn: editForm.isbn.trim() }),
        ...(editForm.publisher.trim() && { publisher: editForm.publisher.trim() }),
        ...(editForm.publication_year && { publication_year: parseInt(editForm.publication_year) }),
        ...(editForm.edition.trim() && { edition: editForm.edition.trim() }),
        ...(editForm.pages && { pages: parseInt(editForm.pages) }),
        ...(editForm.language && { language: editForm.language }),
        ...(editForm.description.trim() && { description: editForm.description.trim() })
      }

      const response = await fetch(`/api/books/${selectedBookForEdit.book_id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(updateData)
      })

      if (response.ok) {
        showSuccessAlert('Success', 'Book updated successfully')
        setShowEditBookModal(false)
        setSelectedBookForEdit(null)
        await fetchBooks()
      } else {
        const errorData = await response.json()
        showErrorAlert('Error', errorData.error || 'Failed to update book')
      }
    } catch (error) {
      showErrorAlert('Error', 'Network error occurred')
      console.error('Error updating book:', error)
    } finally {
      setIsUpdating(false)
    }
  }

  const filteredBooks = books.filter(book => {
    const matchesSearch = book.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.book_author?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.category?.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = !statusFilter || book.status === statusFilter
    const matchesCategory = !categoryFilter || book.category?.toLowerCase().includes(categoryFilter.toLowerCase())

    return matchesSearch && matchesStatus && matchesCategory
  })

  const totalPages = Math.ceil(filteredBooks.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentBooks = filteredBooks.slice(startIndex, endIndex)

  useEffect(() => {
    setCurrentPage(1)
  }, [searchTerm, statusFilter, categoryFilter])

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'AVAILABLE':
        return 'bg-green-100 text-green-800'
      case 'BORROWED':
        return 'bg-blue-100 text-blue-800'
      case 'MISSING':
        return 'bg-red-100 text-red-800'
      case 'DAMAGED':
        return 'bg-orange-100 text-orange-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'AVAILABLE':
        return 'fa-check-circle text-green-600'
      case 'BORROWED':
        return 'fa-book-reader text-blue-600'
      case 'MISSING':
        return 'fa-exclamation-triangle text-red-600'
      case 'DAMAGED':
        return 'fa-tools text-orange-600'
      default:
        return 'fa-question-circle text-gray-600'
    }
  }

  if (!authReady) {
    return (
      <div className="px-6 py-4">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
            <div className="text-sm text-gray-600">Checking authentication...</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold text-gray-800">
              Book Management System
            </h1>
            <div className="flex gap-2">
              {pendingTransactions.length > 0 && (
                <div className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                  {pendingTransactions.length} Pending Transaction{pendingTransactions.length !== 1 ? 's' : ''}
                </div>
              )}
              <Link 
                href="/books/add"
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors inline-flex items-center"
              >
                <i className="fas fa-plus mr-2"></i>
                Add New Book
              </Link>
            </div>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            Manage book inventory, approve transactions, and track book status
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b">
        <div className="px-6">
          <div className="flex space-x-8">
            <button
              onClick={() => setActiveTab('books')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'books'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fas fa-book mr-2"></i>
              Books ({filteredBooks.length})
            </button>
            <button
              onClick={() => setActiveTab('transactions')}
              className={`py-4 px-1 border-b-2 font-medium text-sm relative ${
                activeTab === 'transactions'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fas fa-exchange-alt mr-2"></i>
              Pending Transactions ({pendingTransactions.length})
              {pendingTransactions.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {pendingTransactions.length}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-4">
        {activeTab === 'books' ? (
          <>
            {/* Search and Filters */}
            <div className="mb-6 space-y-4">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">All Status</option>
                      <option value="AVAILABLE">Available</option>
                      <option value="BORROWED">Borrowed</option>
                      <option value="MISSING">Missing</option>
                      <option value="DAMAGED">Damaged</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <input
                      type="text"
                      placeholder="Filter by category..."
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Per Page</label>
                    <select
                      value={itemsPerPage}
                      onChange={(e) => {
                        setItemsPerPage(Number(e.target.value))
                        setCurrentPage(1)
                      }}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value={20}>20 per page</option>
                      <option value={50}>50 per page</option>
                      <option value={100}>100 per page</option>
                    </select>
                  </div>
                </div>

                <div className="lg:w-80">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
                  <input
                    type="text"
                    placeholder="Search by title, author, or category..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Books Table */}
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              {loading ? (
                <div className="p-8 text-center">
                  <div className="text-gray-500">Loading books...</div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Book Details
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Author
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Category
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {currentBooks.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                            {searchTerm || statusFilter || categoryFilter ? 'No books found matching your filters.' : 'No books found.'}
                          </td>
                        </tr>
                      ) : (
                        currentBooks.map((book) => (
                          <tr key={book.book_id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="flex-shrink-0 h-10 w-10">
                                  <div className="h-10 w-10 rounded bg-blue-500 flex items-center justify-center">
                                    <i className="fas fa-book text-white text-sm"></i>
                                  </div>
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">
                                    {book.title}
                                  </div>
                                  <div className="text-sm text-gray-500">
                                    ID: {book.book_id}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {book.book_author}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                                {book.category}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <i className={`fas ${getStatusIcon(book.status)} mr-2`}></i>
                                <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadgeColor(book.status)}`}>
                                  {book.status.charAt(0) + book.status.slice(1).toLowerCase()}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                              <div className="flex gap-1">
                                <button
                                  onClick={() => handleEditBook(book)}
                                  className="text-blue-600 hover:text-blue-900 px-2 py-1 text-sm border border-blue-600 hover:bg-blue-50 rounded transition-colors"
                                  title="Edit Book"
                                >
                                  <i className="fas fa-edit"></i>
                                </button>
                                
                                <button
                                  onClick={() => handleUpdateBookStatus(book.book_id, book.status, book.title)}
                                  className="text-orange-600 hover:text-orange-900 px-2 py-1 text-sm border border-orange-600 hover:bg-orange-50 rounded transition-colors"
                                  title="Update Status"
                                >
                                  <i className="fas fa-sync-alt"></i>
                                </button>
                                
                                <Link
                                  href={`/books/${book.book_id}`}
                                  className="text-gray-600 hover:text-gray-900 px-2 py-1 text-sm border border-gray-600 hover:bg-gray-50 rounded transition-colors"
                                  title="View Details"
                                >
                                  <i className="fas fa-eye"></i>
                                </Link>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Pagination */}
            {!loading && filteredBooks.length > 0 && totalPages > 1 && (
              <div className="mt-4 flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  Showing {startIndex + 1} to {Math.min(endIndex, filteredBooks.length)} of {filteredBooks.length} books
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Previous
                  </button>

                  <div className="flex space-x-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNumber;
                      if (totalPages <= 5) {
                        pageNumber = i + 1;
                      } else if (currentPage <= 3) {
                        pageNumber = i + 1;
                      } else if (currentPage >= totalPages - 2) {
                        pageNumber = totalPages - 4 + i;
                      } else {
                        pageNumber = currentPage - 2 + i;
                      }

                      return (
                        <button
                          key={pageNumber}
                          onClick={() => setCurrentPage(pageNumber)}
                          className={`px-3 py-1 text-sm border rounded-md ${
                            currentPage === pageNumber
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          {pageNumber}
                        </button>
                      );
                    })}
                  </div>

                  <button
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    className="px-3 py-1 text-sm border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </>
        ) : (
          <>
            {/* Pending Transactions */}
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
              <div className="px-6 py-4 bg-gray-50 border-b">
                <h3 className="text-lg font-medium text-gray-900">Pending Transactions</h3>
                <p className="text-sm text-gray-600 mt-1">Review and approve borrowing and return requests</p>
              </div>
              
              {pendingTransactions.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <i className="fas fa-clipboard-check text-4xl mb-4 text-gray-300"></i>
                  <div>No pending transactions</div>
                  <div className="text-sm mt-1">All transactions have been processed</div>
                </div>
              ) : (
                <div className="divide-y divide-gray-200">
                  {pendingTransactions.map((transaction) => (
                    <div key={transaction.transaction_id} className="p-6 hover:bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center mb-2">
                            <div className="flex-shrink-0 h-12 w-12">
                              <div className="h-12 w-12 rounded bg-blue-500 flex items-center justify-center">
                                <i className="fas fa-book text-white"></i>
                              </div>
                            </div>
                            <div className="ml-4">
                              <div className="text-lg font-medium text-gray-900">
                                {transaction.book.title}
                              </div>
                              <div className="text-sm text-gray-600">
                                by {transaction.book.book_author} • {transaction.book.category}
                              </div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Borrower:</span>
                              <div className="font-medium">{transaction.user.full_name}</div>
                              <div className="text-gray-500">{transaction.user.account_id} • {transaction.user.user_type}</div>
                            </div>
                            <div>
                              <span className="text-gray-600">Dates:</span>
                              <div className="font-medium">Borrow: {new Date(transaction.borrow_date).toLocaleDateString()}</div>
                              <div className="text-gray-500">Due: {new Date(transaction.due_date).toLocaleDateString()}</div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex flex-col gap-2 ml-6">
                          {transaction.status === 'PENDING_APPROVAL' && (
                            <>
                              <button
                                onClick={() => handleApproveTransaction(transaction.transaction_id, 'approve')}
                                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                              >
                                <i className="fas fa-check mr-2"></i>
                                Approve Borrow
                              </button>
                              <button
                                onClick={() => handleApproveTransaction(transaction.transaction_id, 'reject')}
                                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                              >
                                <i className="fas fa-times mr-2"></i>
                                Reject
                              </button>
                            </>
                          )}
                          {transaction.return_date && !transaction.status.includes('RETURNED') && (
                            <button
                              onClick={() => handleApproveReturn(transaction.transaction_id)}
                              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                            >
                              <i className="fas fa-undo mr-2"></i>
                              Approve Return
                            </button>
                          )}
                        </div>
                      </div>
                      
                      {transaction.penalty > 0 && (
                        <div className="mt-3 p-3 bg-orange-50 border border-orange-200 rounded-md">
                          <div className="text-sm">
                            <i className="fas fa-exclamation-triangle text-orange-600 mr-2"></i>
                            <span className="text-orange-800">Penalty: ${transaction.penalty.toFixed(2)}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Edit Book Modal */}
      {showEditBookModal && selectedBookForEdit && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 flex items-center justify-center">
          <div className="relative bg-white rounded-lg shadow-xl max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 flex items-center">
                <i className="fas fa-edit mr-2 text-blue-600"></i>
                Edit Book
              </h3>
              <p className="text-sm text-gray-600 mt-1">Update book information</p>
            </div>

            <div className="px-6 py-4">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                  <input
                    type="text"
                    value={editForm.title}
                    onChange={(e) => setEditForm({...editForm, title: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Book title"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Author *</label>
                  <input
                    type="text"
                    value={editForm.book_author}
                    onChange={(e) => setEditForm({...editForm, book_author: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Author name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category *</label>
                  <input
                    type="text"
                    value={editForm.category}
                    onChange={(e) => setEditForm({...editForm, category: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Book category"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">ISBN</label>
                    <input
                      type="text"
                      value={editForm.isbn}
                      onChange={(e) => setEditForm({...editForm, isbn: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="ISBN"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Language</label>
                    <select
                      value={editForm.language}
                      onChange={(e) => setEditForm({...editForm, language: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="English">English</option>
                      <option value="Filipino">Filipino</option>
                      <option value="Spanish">Spanish</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Publisher</label>
                  <input
                    type="text"
                    value={editForm.publisher}
                    onChange={(e) => setEditForm({...editForm, publisher: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Publisher name"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Publication Year</label>
                    <input
                      type="number"
                      value={editForm.publication_year}
                      onChange={(e) => setEditForm({...editForm, publication_year: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Year"
                      min="1900"
                      max={new Date().getFullYear()}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Pages</label>
                    <input
                      type="number"
                      value={editForm.pages}
                      onChange={(e) => setEditForm({...editForm, pages: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Number of pages"
                      min="1"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Edition</label>
                  <input
                    type="text"
                    value={editForm.edition}
                    onChange={(e) => setEditForm({...editForm, edition: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Edition (e.g., 1st, 2nd, Revised)"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    value={editForm.description}
                    onChange={(e) => setEditForm({...editForm, description: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Book description (optional)"
                    rows={3}
                  />
                </div>
              </div>
            </div>

            <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowEditBookModal(false)
                  setSelectedBookForEdit(null)
                }}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={isUpdating}
              >
                Cancel
              </button>
              <button
                onClick={handleUpdateBook}
                disabled={isUpdating || !editForm.title.trim() || !editForm.book_author.trim() || !editForm.category.trim()}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isUpdating ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Updating...
                  </>
                ) : (
                  <>
                    <i className="fas fa-save mr-2"></i>
                    Update Book
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
