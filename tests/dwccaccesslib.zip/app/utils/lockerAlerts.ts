import Swal from 'sweetalert2'

export const showLockerAssignedSuccess = async (lockerNumber: string, userName: string) => {
  return await Swal.fire({
    icon: 'success',
    title: 'Locker Assigned Successfully!',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-lock text-green-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Assignment Complete</h3>
        </div>
        <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Locker:</span>
              <span class="font-semibold text-green-700">${lockerNumber}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">Assigned to:</span>
              <span class="font-semibold text-green-700">${userName}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">Time Limit:</span>
              <span class="font-semibold text-green-700">2 Hours</span>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">The user can now access their assigned locker.</p>
      </div>
    `,
    confirmButtonText: 'Continue',
    confirmButtonColor: '#059669',
    showCloseButton: true,
    customClass: {
      popup: 'swal2-popup-large'
    }
  })
}

export const showLockerAssignmentError = (message: string) => {
  return Swal.fire({
    icon: 'error',
    title: 'Assignment Failed',
    text: message,
    confirmButtonText: 'Try Again',
    confirmButtonColor: '#dc2626',
    showCloseButton: true
  })
}

export const showNoAvailableLockersWarning = () => {
  return Swal.fire({
    icon: 'warning',
    title: 'No Available Lockers',
    text: 'All lockers are currently occupied. Please try again later.',
    confirmButtonText: 'Understood',
    confirmButtonColor: '#ea580c',
    showCloseButton: true
  })
}

export const showUserNotFoundWarning = () => {
  return Swal.fire({
    icon: 'warning',
    title: 'User Not Found',
    text: 'Please scan a valid user ID or RFID card first.',
    confirmButtonText: 'Try Again',
    confirmButtonColor: '#ea580c',
    showCloseButton: true
  })
}

export const showAssigningLockerLoading = () => {
  return Swal.fire({
    title: 'Assigning Locker...',
    html: `
      <div class="text-center">
        <i class="fas fa-spinner fa-spin text-blue-600 text-3xl mb-4"></i>
        <p class="text-gray-600">Processing locker assignment</p>
        <div class="mt-4">
          <div class="inline-flex items-center px-3 py-1 rounded-full text-xs bg-blue-100 text-blue-700">
            <i class="fas fa-clock mr-1"></i>
            Please wait...
          </div>
        </div>
      </div>
    `,
    allowOutsideClick: false,
    allowEscapeKey: false,
    showConfirmButton: false,
    showCloseButton: false,
    customClass: {
      popup: 'swal2-popup-loading'
    }
  })
}

export const closeLockerLoading = () => {
  Swal.close()
}

export const showLockerExtensionSuccess = (lockerNumber: string, additionalHours: number = 2) => {
  return Swal.fire({
    icon: 'success',
    title: 'Time Extended Successfully!',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-clock text-orange-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Extension Complete</h3>
        </div>
        <div class="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Locker:</span>
              <span class="font-semibold text-orange-700">${lockerNumber}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">Additional Time:</span>
              <span class="font-semibold text-orange-700">+${additionalHours} Hours</span>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">The locker time has been successfully extended.</p>
      </div>
    `,
    confirmButtonText: 'Continue',
    confirmButtonColor: '#ea580c',
    showCloseButton: true
  })
}

export const showLockerReturnSuccess = (lockerNumber: string, userName?: string) => {
  return Swal.fire({
    icon: 'success',
    title: 'Locker Returned Successfully!',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-unlock text-green-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Return Complete</h3>
        </div>
        <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Locker:</span>
              <span class="font-semibold text-green-700">${lockerNumber}</span>
            </div>
            ${userName ? `
            <div class="flex justify-between">
              <span class="text-gray-600">Returned by:</span>
              <span class="font-semibold text-green-700">${userName}</span>
            </div>
            ` : ''}
            <div class="flex justify-between">
              <span class="text-gray-600">Status:</span>
              <span class="font-semibold text-green-700">Available</span>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">The locker is now available for new assignments.</p>
      </div>
    `,
    confirmButtonText: 'Continue',
    confirmButtonColor: '#059669',
    showCloseButton: true
  })
}

export const showInvalidKeyError = (action: 'extension' | 'return' | 'access' = 'access') => {
  const actionMessages = {
    extension: 'extend the time for',
    return: 'return',
    access: 'access'
  }

  return Swal.fire({
    icon: 'error',
    title: 'Invalid Key',
    text: `The scanned key is invalid or cannot be used to ${actionMessages[action]} this locker.`,
    confirmButtonText: 'Try Again',
    confirmButtonColor: '#dc2626',
    showCloseButton: true
  })
}

export const showLockerNotFoundError = () => {
  return Swal.fire({
    icon: 'error',
    title: 'Locker Not Found',
    text: 'The specified locker could not be found or is not currently occupied.',
    confirmButtonText: 'Try Again',
    confirmButtonColor: '#dc2626',
    showCloseButton: true
  })
}
