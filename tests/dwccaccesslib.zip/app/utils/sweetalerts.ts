import Swal from 'sweetalert2'

export const showConfirmDialog = async (
  title: string,
  text: string,
  confirmButtonText: string = 'Yes',
  cancelButtonText: string = 'Cancel'
) => {
  const result = await Swal.fire({
    title,
    text,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText,
    cancelButtonText
  })
  return result.isConfirmed
}

export const showSuccessAlert = async (
  title: string,
  text?: string,
  confirmButtonText: string = 'OK'
) => {
  return await Swal.fire({
    title,
    text,
    icon: 'success',
    confirmButtonColor: '#3085d6',
    confirmButtonText
  })
}

export const showErrorAlert = async (
  title: string,
  text: string,
  confirmButtonText: string = 'OK'
) => {
  return await Swal.fire({
    title,
    text,
    icon: 'error',
    confirmButtonColor: '#3085d6',
    confirmButtonText
  })
}

export const showLoadingAlert = (title: string = 'Loading...') => {
  Swal.fire({
    title,
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading()
    }
  })
}

export const showPasswordResetSuccess = async (newPassword: string) => {
  return await Swal.fire({
    title: 'Success!',
    html: `Password reset successfully.<br><br><strong>New password:</strong> <code style="background-color: #f3f4f6; padding: 2px 4px; border-radius: 4px; font-family: monospace;">${newPassword}</code>`,
    icon: 'success',
    confirmButtonColor: '#3085d6',
    confirmButtonText: 'Got it!'
  })
}

export const showInfoAlert = async (
  title: string,
  text: string,
  confirmButtonText: string = 'OK'
) => {
  return await Swal.fire({
    title,
    text,
    icon: 'info',
    confirmButtonColor: '#3085d6',
    confirmButtonText
  })
}

export const showWarningAlert = async (
  title: string,
  text: string,
  confirmButtonText: string = 'OK'
) => {
  return await Swal.fire({
    title,
    text,
    icon: 'warning',
    confirmButtonColor: '#3085d6',
    confirmButtonText
  })
}

export const showInputDialog = async (
  title: string,
  text: string,
  inputPlaceholder: string = '',
  inputType: 'text' | 'email' | 'password' | 'number' | 'textarea' = 'text',
  confirmButtonText: string = 'Submit',
  cancelButtonText: string = 'Cancel'
) => {
  const result = await Swal.fire({
    title,
    text,
    input: inputType,
    inputPlaceholder,
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText,
    cancelButtonText,
    inputValidator: (value) => {
      if (!value) {
        return 'This field is required!'
      }
    }
  })
  
  return {
    isConfirmed: result.isConfirmed,
    value: result.value
  }
}

export const showPasswordResetDialog = async (
  title: string,
  text: string,
  confirmButtonText: string = 'Reset Password',
  cancelButtonText: string = 'Cancel'
) => {
  const result = await Swal.fire({
    title,
    text,
    html: `
      <div style="margin: 20px 0;">
        <div style="position: relative; margin-bottom: 10px;">
          <input 
            type="password" 
            id="swal-password-input" 
            class="swal2-input" 
            placeholder="Enter temporary password"
            style="padding-right: 45px; margin: 0;"
          />
          <button 
            type="button" 
            id="swal-toggle-password" 
            style="
              position: absolute;
              right: 12px;
              top: 50%;
              transform: translateY(-50%);
              background: none;
              border: none;
              cursor: pointer;
              color: #6b7280;
              font-size: 16px;
            "
            title="Toggle password visibility"
          >
            <i class="fas fa-eye"></i>
          </button>
        </div>
        <div style="font-size: 12px; color: #6b7280; text-align: left;">
          Password must be at least 4 characters long
        </div>
      </div>
    `,
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText,
    cancelButtonText,
    didOpen: () => {
      const passwordInput = document.getElementById('swal-password-input') as HTMLInputElement
      const toggleButton = document.getElementById('swal-toggle-password') as HTMLButtonElement
      const eyeIcon = toggleButton.querySelector('i')
      
      passwordInput?.focus()
      
      toggleButton?.addEventListener('click', () => {
        if (passwordInput.type === 'password') {
          passwordInput.type = 'text'
          eyeIcon?.classList.remove('fa-eye')
          eyeIcon?.classList.add('fa-eye-slash')
          toggleButton.title = 'Hide password'
        } else {
          passwordInput.type = 'password'
          eyeIcon?.classList.remove('fa-eye-slash')
          eyeIcon?.classList.add('fa-eye')
          toggleButton.title = 'Show password'
        }
      })
    },
    preConfirm: () => {
      const passwordInput = document.getElementById('swal-password-input') as HTMLInputElement
      const password = passwordInput?.value
      
      if (!password) {
        Swal.showValidationMessage('Password is required')
        return false
      }
      
      if (password.length < 4) {
        Swal.showValidationMessage('Password must be at least 4 characters long')
        return false
      }
      
      return password
    }
  })
  
  return {
    isConfirmed: result.isConfirmed,
    value: result.value
  }
}

// Locker Management Alerts
export const showLockerAddedSuccess = (lockerNumber: string) => {
  return Swal.fire({
    icon: 'success',
    title: 'Locker Added Successfully!',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-plus-circle text-green-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">New Locker Created</h3>
        </div>
        <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Locker Number:</span>
              <span class="font-semibold text-green-700">${lockerNumber}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">Status:</span>
              <span class="font-semibold text-green-700">Available</span>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">The locker has been added to the system and is ready for use.</p>
      </div>
    `,
    confirmButtonText: 'Continue',
    confirmButtonColor: '#059669',
    timer: 3000,
    timerProgressBar: true
  })
}

export const showLockerUpdatedSuccess = (lockerNumber: string) => {
  return Swal.fire({
    icon: 'success',
    title: 'Locker Updated Successfully!',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-edit text-blue-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Locker Information Updated</h3>
        </div>
        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Locker Number:</span>
              <span class="font-semibold text-blue-700">${lockerNumber}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">Action:</span>
              <span class="font-semibold text-blue-700">Updated</span>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">The locker information has been successfully updated.</p>
      </div>
    `,
    confirmButtonText: 'Continue',
    confirmButtonColor: '#2563eb',
    timer: 3000,
    timerProgressBar: true
  })
}

export const showLockerDeleteConfirm = (lockerNumber: string) => {
  return Swal.fire({
    icon: 'warning',
    title: 'Delete Locker?',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-trash-alt text-red-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Confirm Deletion</h3>
        </div>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Locker to Delete:</span>
              <span class="font-semibold text-red-700">${lockerNumber}</span>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">This action cannot be undone. Are you sure you want to delete this locker?</p>
      </div>
    `,
    showCancelButton: true,
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#dc2626',
    cancelButtonColor: '#6b7280',
    reverseButtons: true
  })
}

export const showLockerManagementError = (action: string, error?: string) => {
  return Swal.fire({
    icon: 'error',
    title: 'Locker Management Error',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-exclamation-triangle text-red-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Action Failed</h3>
        </div>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Failed Action:</span>
              <span class="font-semibold text-red-700">${action}</span>
            </div>
            ${error ? `
            <div class="mt-2">
              <span class="text-gray-600">Error:</span>
              <p class="text-red-700 text-xs mt-1">${error}</p>
            </div>
            ` : ''}
          </div>
        </div>
        <p class="text-sm text-gray-600">Please try again or contact system administrator if the problem persists.</p>
      </div>
    `,
    confirmButtonText: 'Try Again',
    confirmButtonColor: '#dc2626',
    showCloseButton: true
  })
}

export const showRfidScanningAlert = () => {
  return Swal.fire({
    title: 'Scanning RFID...',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-wifi text-blue-600 text-4xl mb-2 animate-pulse"></i>
          <h3 class="text-lg font-semibold text-gray-800">RFID Scanner Active</h3>
        </div>
        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <p class="text-sm text-blue-700">Hold your RFID card/key near the scanner</p>
        </div>
        <div class="flex justify-center">
          <div class="inline-flex items-center px-3 py-1 rounded-full text-xs bg-blue-100 text-blue-700">
            <i class="fas fa-spinner fa-spin mr-2"></i>
            Scanning...
          </div>
        </div>
      </div>
    `,
    allowOutsideClick: false,
    allowEscapeKey: true,
    showConfirmButton: false,
    showCloseButton: true,
    customClass: {
      popup: 'swal2-popup-scanning'
    }
  })
}

export const showLockerValidationError = (field: string, message: string) => {
  return Swal.fire({
    icon: 'warning',
    title: 'Validation Error',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-exclamation-circle text-yellow-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Invalid Input</h3>
        </div>
        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="flex justify-between">
              <span class="text-gray-600">Field:</span>
              <span class="font-semibold text-yellow-700">${field}</span>
            </div>
            <div class="mt-2">
              <span class="text-gray-600">Issue:</span>
              <p class="text-yellow-700 text-xs mt-1">${message}</p>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">Please correct the error and try again.</p>
      </div>
    `,
    confirmButtonText: 'Fix Input',
    confirmButtonColor: '#d97706',
    showCloseButton: true
  })
}

// Book Browsing Alerts
export const showBookDetailsDialog = async (book: any) => {
  return await Swal.fire({
    title: 'Book Details',
    html: `
      <div class="text-left">
        <div class="mb-4 text-center">
          <div class="w-24 h-32 bg-gradient-to-br from-green-400 to-green-600 rounded-lg flex items-center justify-center mx-auto mb-4">
            <i class="fas fa-book text-white text-3xl"></i>
          </div>
        </div>
        <div class="space-y-3">
          <div>
            <span class="font-semibold text-gray-700">Title:</span>
            <p class="text-gray-900 mt-1">${book.title}</p>
          </div>
          <div>
            <span class="font-semibold text-gray-700">Author:</span>
            <p class="text-gray-900 mt-1">${book.book_author}</p>
          </div>
          <div>
            <span class="font-semibold text-gray-700">Category:</span>
            <p class="text-gray-900 mt-1">${book.category}</p>
          </div>
          <div>
            <span class="font-semibold text-gray-700">Status:</span>
            <p class="text-green-600 mt-1 font-medium">
              <i class="fas fa-check-circle mr-1"></i>Available
            </p>
          </div>
          <div>
            <span class="font-semibold text-gray-700">Book ID:</span>
            <p class="text-gray-900 mt-1">${book.book_id}</p>
          </div>
        </div>
        <div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
          <div class="flex items-start">
            <i class="fas fa-info-circle text-blue-600 mt-1 mr-2"></i>
            <div class="text-sm text-blue-800">
              <p class="font-medium mb-1">How to borrow:</p>
              <p>Contact library staff or visit the circulation desk to request this book.</p>
            </div>
          </div>
        </div>
      </div>
    `,
    width: '500px',
    confirmButtonText: 'Close',
    confirmButtonColor: '#059669',
    showCloseButton: true,
    customClass: {
      popup: 'swal2-popup-book-details'
    }
  })
}

export const showNoSearchResultsAlert = async (searchTerm?: string, category?: string) => {
  const message = 'No books found'
  let detailMessage = 'No books are currently available'
  
  if (searchTerm && category) {
    detailMessage = `No books found for "${searchTerm}" in category "${category}"`
  } else if (searchTerm) {
    detailMessage = `No books found for "${searchTerm}"`
  } else if (category) {
    detailMessage = `No books found in category "${category}"`
  }

  return await Swal.fire({
    icon: 'info',
    title: message,
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-book-open text-gray-300 text-4xl mb-4"></i>
        </div>
        <p class="text-gray-600 mb-4">${detailMessage}</p>
        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div class="text-sm text-blue-700">
            <p class="font-medium mb-2">Suggestions:</p>
            <ul class="text-left space-y-1">
              <li>• Try different keywords or spelling</li>
              <li>• Browse different categories</li>
              <li>• Clear all filters to see all books</li>
              <li>• Contact library staff for assistance</li>
            </ul>
          </div>
        </div>
      </div>
    `,
    confirmButtonText: 'Browse All Books',
    confirmButtonColor: '#059669',
    showCloseButton: true
  })
}

export const showBooksLoadingError = async (retry?: () => void) => {
  const result = await Swal.fire({
    icon: 'error',
    title: 'Failed to Load Books',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-exclamation-triangle text-red-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Connection Error</h3>
        </div>
        <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <div class="text-red-700">
              <p class="font-medium">Unable to load books from the library database.</p>
              <p class="mt-2">This could be due to:</p>
              <ul class="text-left mt-2 space-y-1">
                <li>• Network connectivity issues</li>
                <li>• Server maintenance</li>
                <li>• Temporary database unavailability</li>
              </ul>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">Please try again or contact library staff if the problem persists.</p>
      </div>
    `,
    showCancelButton: retry ? true : false,
    confirmButtonText: retry ? 'Try Again' : 'OK',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#dc2626',
    cancelButtonColor: '#6b7280'
  })

  if (result.isConfirmed && retry) {
    retry()
  }

  return result
}

export const showSearchHelp = async () => {
  return await Swal.fire({
    title: 'Search Help',
    html: `
      <div class="text-left">
        <div class="mb-4 text-center">
          <i class="fas fa-search text-green-600 text-3xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">How to Search</h3>
        </div>
        <div class="space-y-4">
          <div class="bg-green-50 border border-green-200 rounded-lg p-4">
            <h4 class="font-semibold text-green-800 mb-2">Search Tips:</h4>
            <ul class="text-sm text-green-700 space-y-1">
              <li>• Search by book title, author name, or keywords</li>
              <li>• Use specific terms for better results</li>
              <li>• Try partial matches if exact titles don't work</li>
              <li>• Combine with category filters for precise results</li>
            </ul>
          </div>
          <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 class="font-semibold text-blue-800 mb-2">Filter Options:</h4>
            <ul class="text-sm text-blue-700 space-y-1">
              <li>• Select specific categories to narrow results</li>
              <li>• Use "All Categories" to see everything</li>
              <li>• Clear filters to reset your search</li>
            </ul>
          </div>
          <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 class="font-semibold text-yellow-800 mb-2">Example Searches:</h4>
            <ul class="text-sm text-yellow-700 space-y-1">
              <li>• "Harry Potter" - finds books with this in title</li>
              <li>• "Shakespeare" - finds books by this author</li>
              <li>• "programming" - finds programming-related books</li>
            </ul>
          </div>
        </div>
      </div>
    `,
    width: '600px',
    confirmButtonText: 'Got it!',
    confirmButtonColor: '#059669',
    showCloseButton: true
  })
}

export const showBookUnavailableAlert = async (bookTitle: string) => {
  return await Swal.fire({
    icon: 'warning',
    title: 'Book Unavailable',
    html: `
      <div class="text-center">
        <div class="mb-4">
          <i class="fas fa-book-reader text-orange-600 text-4xl mb-2"></i>
          <h3 class="text-lg font-semibold text-gray-800">Currently Borrowed</h3>
        </div>
        <div class="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
          <div class="text-sm space-y-2">
            <p class="text-orange-700 font-medium">"${bookTitle}" is currently checked out.</p>
            <div class="mt-3 text-orange-600">
              <p class="font-medium mb-2">What you can do:</p>
              <ul class="text-left space-y-1">
                <li>• Place a hold/reservation with library staff</li>
                <li>• Check for other copies or editions</li>
                <li>• Browse similar books in the same category</li>
                <li>• Ask staff for recommended alternatives</li>
              </ul>
            </div>
          </div>
        </div>
        <p class="text-sm text-gray-600">Contact library staff for assistance or to place a hold.</p>
      </div>
    `,
    confirmButtonText: 'Contact Staff',
    confirmButtonColor: '#ea580c',
    showCloseButton: true
  })
}

export const showClearFiltersConfirm = async () => {
  return await Swal.fire({
    title: 'Clear All Filters?',
    text: 'This will reset your search term and category filter.',
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'Yes, Clear',
    cancelButtonText: 'Cancel',
    confirmButtonColor: '#059669',
    cancelButtonColor: '#6b7280'
  })
}
