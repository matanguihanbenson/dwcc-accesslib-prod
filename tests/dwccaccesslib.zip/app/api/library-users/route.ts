import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { UserRole } from "@/types"

export async function GET(request: NextRequest) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only SUPER_ADMIN can access library users management
    if (session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Get query parameters for filtering
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search") || ""
    const userType = searchParams.get("userType") || ""
    const status = searchParams.get("status") || ""
    const limit = parseInt(searchParams.get("limit") || "1000", 10) // Default to large limit to get all users
    const page = parseInt(searchParams.get("page") || "1", 10)

    // Build where conditions
    const whereConditions: any = {}

    // User type filter
    if (userType) {
      whereConditions.user_type = userType
    }

    // Status filter
    if (status) {
      if (status === "ARCHIVED") {
        // For archived status, we'll need to handle this differently since there's no is_archived field
        // We'll filter this in the application layer
        whereConditions.status = "ARCHIVED"
      } else {
        whereConditions.status = status
      }
    }

    // Search functionality
    if (search) {
      whereConditions.OR = [
        {
          full_name: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          email: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          account_id: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          course: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          department: {
            contains: search,
            mode: 'insensitive'
          }
        }
      ]
    }

    // Calculate skip for pagination
    const skip = (page - 1) * limit

    // Fetch users from the user table
    const users = await prisma.user.findMany({
      where: whereConditions,
      select: {
        user_id: true,
        account_id: true,
        full_name: true,
        user_type: true,
        course: true,
        department: true,
        year_level: true,
        email: true,
        rfid_code: true,
        purpose: true,
        contact_number: true,
        status: true
      },
      orderBy: [
        {
          status: 'asc' // Active first, then inactive, then archived
        },
        {
          full_name: 'asc'
        }
      ],
      skip: skip,
      take: limit
    })

    // Get total count for pagination
    const totalCount = await prisma.user.count({
      where: whereConditions
    })

    // Transform data to match the frontend interface
    const formattedUsers = users.map(user => ({
      id: user.user_id,
      full_name: user.full_name,
      user_type: user.user_type,
      email: user.email,
      course: user.course,
      department: user.department,
      year_level: user.year_level,
      account_id: user.account_id,
      rfid_code: user.rfid_code,
      purpose: user.purpose,
      contact_number: user.contact_number,
      status: user.status,
      is_archived: user.status === "ARCHIVED", // Assuming ARCHIVED status means archived
      created_at: new Date().toISOString(), // Placeholder since field doesn't exist
      updated_at: new Date().toISOString(), // Placeholder since field doesn't exist
      last_activity: null // This would need to be calculated from entry logs or book transactions if needed
    }))

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limit)
    const hasMore = page < totalPages

    return NextResponse.json({
      success: true,
      users: formattedUsers,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore
      }
    })

  } catch (error) {
    console.error("Error fetching library users:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
