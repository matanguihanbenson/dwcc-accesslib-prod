import { NextRequest, NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'
import { verifyJWTAuth } from '@/lib/auth-utils'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  try {
    let currentUserRole = null

    const token = await getToken({ req })
    if (token?.role) {
      currentUserRole = token.role
    } else {
      const jwtAuth = await verifyJWTAuth(req)
      if (jwtAuth) {
        currentUserRole = jwtAuth.role
      }
    }

    if (!currentUserRole) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    if (currentUserRole !== 'SUPER_ADMIN' && currentUserRole !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      )
    }

    // Get all users who don't have staff accounts yet
    // First get all user IDs that already have staff accounts
    const existingStaffUserIds = await prisma.userAccount.findMany({
      select: { user_id: true }
    })
    const existingUserIds = existingStaffUserIds.map(ua => ua.user_id)
    
    // Then get all users who are NOT in the existing staff accounts
    // Handle case where no existing users (empty notIn would cause error)
    const whereClause = existingUserIds.length > 0 
      ? { user_id: { notIn: existingUserIds } }
      : {} // If no existing staff accounts, show all users
    
    const libraryUsers = await prisma.user.findMany({
      where: whereClause,
      select: {
        user_id: true,
        account_id: true,
        full_name: true,
        user_type: true,
        email: true,
        course: true,
        year_level: true,
        department: true
      },
      orderBy: {
        full_name: 'asc'
      }
    })

    return NextResponse.json(libraryUsers)

  } catch (error) {
    console.error('Error fetching library users for staff promotion:', error)
    
    // More detailed error logging
    if (error instanceof Error) {
      console.error('Error message:', error.message)
      console.error('Error stack:', error.stack)
    }
    
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
