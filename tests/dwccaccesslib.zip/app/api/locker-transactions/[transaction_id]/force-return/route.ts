import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { AuditService } from '@/lib/services/audit.service'
import { UserRole } from '@/types'

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ transaction_id: string }> }
) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Only ADMIN and SUPER_ADMIN can force return lockers
    if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role)) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    const resolvedParams = await params
    const transactionId = parseInt(resolvedParams.transaction_id)

    // Get the transaction with related data
    const transaction = await prisma.lockerTransaction.findUnique({
      where: { transaction_id: transactionId },
      include: {
        locker: true,
        user: true
      }
    })

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    if (transaction.return_time) {
      return NextResponse.json({ 
        error: 'Locker has already been returned' 
      }, { status: 400 })
    }

    const returnTime = new Date()
    
    // Calculate maximum penalty for force return
    const hoursUsed = Math.floor(
      (returnTime.getTime() - transaction.borrow_time.getTime()) / (1000 * 60 * 60)
    )
    const daysUsed = Math.floor(hoursUsed / 24)
    
    // Force return applies higher penalty (10 pesos per day instead of 5)
    const forcePenalty = Math.max(daysUsed * 10, 50) as any // Minimum 50 pesos for force return

    // Update the transaction and locker status
    const updatedTransaction = await prisma.$transaction(async (tx) => {
      // Update the locker transaction
      const updated = await tx.lockerTransaction.update({
        where: { transaction_id: transactionId },
        data: {
          return_time: returnTime,
          penalty: forcePenalty
        },
        include: {
          locker: true,
          user: true
        }
      })

      // Update locker status to AVAILABLE
      await tx.locker.update({
        where: { locker_id: transaction.locker_id },
        data: { status: 'AVAILABLE' }
      })

      return updated
    })

    // Log the audit activity
    const currentUserAccount = await prisma.userAccount.findUnique({
      where: { username: session.user.username },
      include: { user: true }
    })

    if (currentUserAccount?.user) {
      await AuditService.logActivity({
        userId: currentUserAccount.user.user_id,
        role: currentUserAccount.role as UserRole,
        description: `FORCE RETURNED locker: Locker ${transaction.locker.locker_number} forcibly returned from ${transaction.user.full_name} (${transaction.user.email}) - Penalty: ₱${forcePenalty} - Duration: ${daysUsed} days`
      })
    }

    return NextResponse.json({
      success: true,
      message: 'Locker force return processed successfully',
      transaction: updatedTransaction,
      penalty_applied: true,
      penalty_amount: forcePenalty
    })

  } catch (error) {
    console.error('Error processing locker force return:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
