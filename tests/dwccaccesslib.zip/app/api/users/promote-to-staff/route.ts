import { NextRequest, NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'
import { verifyJWTAuth } from '@/lib/auth-utils'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'

export async function POST(req: NextRequest) {
  try {
    let currentUserRole = null

    const token = await getToken({ req })
    if (token?.role) {
      currentUserRole = token.role
    } else {
      const jwtAuth = await verifyJWTAuth(req)
      if (jwtAuth) {
        currentUserRole = jwtAuth.role
      }
    }

    if (!currentUserRole) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    if (currentUserRole !== 'SUPER_ADMIN' && currentUserRole !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      )
    }

    const { userId, password, role } = await req.json()

    if (!userId || !password || !role) {
      return NextResponse.json(
        { error: 'User ID, password, and role are required' },
        { status: 400 }
      )
    }

    if (password.length < 4) {
      return NextResponse.json(
        { error: 'Password must be at least 4 characters long' },
        { status: 400 }
      )
    }

    // Check if ADMIN is trying to create non-STAFF role
    if (currentUserRole === 'ADMIN' && role !== 'STAFF') {
      return NextResponse.json(
        { error: 'Admin can only create STAFF accounts' },
        { status: 403 }
      )
    }

    // Validate role
    const validRoles = ['STAFF', 'ADMIN']
    if (!validRoles.includes(role)) {
      return NextResponse.json(
        { error: 'Invalid role' },
        { status: 400 }
      )
    }

    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { user_id: userId }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Check if user already has a staff account
    const existingAccount = await prisma.userAccount.findUnique({
      where: { user_id: userId }
    })

    if (existingAccount) {
      return NextResponse.json(
        { error: 'User already has a staff account' },
        { status: 400 }
      )
    }

    // Generate username from account_id or use account_id as username
    const username = user.account_id

    // Check if username already exists in userAccounts
    const existingUsername = await prisma.userAccount.findUnique({
      where: { username: username }
    })

    if (existingUsername) {
      return NextResponse.json(
        { error: 'Username already exists in staff accounts' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12)

    // Create staff account
    const staffAccount = await prisma.userAccount.create({
      data: {
        user_id: userId,
        username: username,
        password_hash: hashedPassword,
        role: role,
        is_active: true,
        created_at: new Date(),
        last_login: null
      },
      include: {
        user: {
          select: {
            full_name: true,
            user_type: true,
            email: true,
            course: true,
            year_level: true,
            department: true
          }
        }
      }
    })

    return NextResponse.json({
      message: 'Staff account created successfully',
      account: staffAccount
    })

  } catch (error) {
    console.error('Error promoting user to staff:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
