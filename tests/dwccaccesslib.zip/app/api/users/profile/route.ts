import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import jwt from 'jsonwebtoken'
import { JWTPayload } from '@/types'
import { ApiResponseHelper } from '@/lib/services/base.service'
import logger from '@/lib/logger'

export async function GET(request: NextRequest) {
  try {
    logger.apiRequest('GET', '/api/users/profile')
    
    // Try to get session first (NextAuth)
    const session = await getServerSession(authOptions)
    
    if (session?.user?.username) {
      try {
        // Use session-based lookup
        const userAccount = await prisma.userAccount.findUnique({
          where: {
            username: session.user.username,
            is_active: true
          },
          include: {
            user: {
              select: {
                full_name: true,
                email: true,
                user_type: true,
              }
            }
          }
        })

        if (userAccount) {
          const userData = {
            id: userAccount.username,
            name: userAccount.user.full_name,
            email: userAccount.user.email,
            role: userAccount.role,
            avatar: null,
          }
          
          logger.info('Profile fetched successfully via session', { username: userAccount.username })
          return NextResponse.json(ApiResponseHelper.success(userData))
        }
      } catch (dbError) {
        logger.error('Database error during session lookup', dbError instanceof Error ? dbError : new Error(String(dbError)))
      }
    }

    // If no session, try JWT token from cookies
    const token = request.cookies.get('token')?.value
    
    if (!token) {
      logger.warn('No authentication found for profile request')
      return NextResponse.json(ApiResponseHelper.error('No authentication found'), { status: 401 })
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as JWTPayload
      const userId = decoded.userId

      // Fetch user data from database using JWT
      const userAccount = await prisma.userAccount.findUnique({
        where: { id: userId, is_active: true },
        include: {
          user: {
            select: {
              full_name: true,
              email: true,
              user_type: true,
            }
          }
        }
      })

      if (!userAccount) {
        logger.warn('User not found for profile request', { userId: userId.toString() })
        return NextResponse.json(ApiResponseHelper.error('User not found'), { status: 404 })
      }

      const userData = {
        id: userAccount.username,
        name: userAccount.user.full_name,
        email: userAccount.user.email,
        role: userAccount.role,
        avatar: null,
      }
      
      logger.info('Profile fetched successfully via JWT', { username: userAccount.username })
      return NextResponse.json(ApiResponseHelper.success(userData))
      
    } catch (jwtError) {
      logger.warn('JWT verification failed for profile request', { error: jwtError instanceof Error ? jwtError.message : String(jwtError) })
      return NextResponse.json(ApiResponseHelper.error('Invalid authentication token'), { status: 401 })
    }
  } catch (error) {
    logger.error('Profile fetch error', error instanceof Error ? error : new Error(String(error)))
    return NextResponse.json(ApiResponseHelper.error('Internal server error'), { status: 500 })
  }
}
