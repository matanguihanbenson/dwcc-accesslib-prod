import { NextRequest, NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'
import { verifyJWTAuth } from '@/lib/auth-utils'
import { prisma } from '@/lib/prisma'

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    let currentUserRole = null

    const token = await getToken({ req })
    if (token?.role) {
      currentUserRole = token.role
    } else {
      const jwtAuth = await verifyJWTAuth(req)
      if (jwtAuth) {
        currentUserRole = jwtAuth.role
      }
    }

    if (!currentUserRole) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    if (currentUserRole !== 'SUPER_ADMIN' && currentUserRole !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      )
    }

    const resolvedParams = await params
    const userId = parseInt(resolvedParams.id)
    if (isNaN(userId)) {
      return NextResponse.json(
        { error: 'Invalid user ID' },
        { status: 400 }
      )
    }

    const userAccount = await prisma.userAccount.findUnique({
      where: { id: userId },
      include: {
        user: true
      }
    })

    if (!userAccount) {
      return NextResponse.json(
        { error: 'User account not found' },
        { status: 404 }
      )
    }

    if (currentUserRole === 'ADMIN' && userAccount.role !== 'STAFF') {
      return NextResponse.json(
        { error: 'Admin can only toggle staff account status' },
        { status: 403 }
      )
    }

    const newStatus = userAccount.is_active ? false : true

    const updatedAccount = await prisma.userAccount.update({
      where: { id: userId },
      data: { is_active: newStatus },
      include: {
        user: true
      }
    })

    return NextResponse.json({
      message: `User account ${newStatus ? 'activated' : 'deactivated'} successfully`,
      account: updatedAccount
    })

  } catch (error) {
    console.error('Error toggling user status:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
