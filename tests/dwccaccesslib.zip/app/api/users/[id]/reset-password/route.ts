import { NextRequest, NextResponse } from 'next/server'
import { getToken } from 'next-auth/jwt'
import { verifyJWTAuth } from '@/lib/auth-utils'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    let currentUserRole = null

    const token = await getToken({ req })
    if (token?.role) {
      currentUserRole = token.role
    } else {
      const jwtAuth = await verifyJWTAuth(req)
      if (jwtAuth) {
        currentUserRole = jwtAuth.role
      }
    }

    if (!currentUserRole) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      )
    }

    if (currentUserRole !== 'SUPER_ADMIN' && currentUserRole !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      )
    }

    const resolvedParams = await params
    const userId = parseInt(resolvedParams.id)
    if (isNaN(userId)) {
      return NextResponse.json(
        { error: 'Invalid user ID' },
        { status: 400 }
      )
    }

    const { newPassword } = await req.json()

    if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 4) {
      return NextResponse.json(
        { error: 'New password must be at least 4 characters long' },
        { status: 400 }
      )
    }

    const userAccount = await prisma.userAccount.findUnique({
      where: { id: userId },
      include: {
        user: true
      }
    })

    if (!userAccount) {
      return NextResponse.json(
        { error: 'User account not found' },
        { status: 404 }
      )
    }

    if (currentUserRole === 'ADMIN' && userAccount.role !== 'STAFF') {
      return NextResponse.json(
        { error: 'Admin can only reset staff account passwords' },
        { status: 403 }
      )
    }

    const hashedPassword = await bcrypt.hash(newPassword, 12)

    const updatedAccount = await prisma.userAccount.update({
      where: { id: userId },
      data: { password_hash: hashedPassword },
      include: {
        user: true
      }
    })

    return NextResponse.json({
      message: 'Password reset successfully',
      account: {
        id: updatedAccount.id,
        username: updatedAccount.username,
        role: updatedAccount.role,
        is_active: updatedAccount.is_active
      }
    })

  } catch (error) {
    console.error('Error resetting password:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
