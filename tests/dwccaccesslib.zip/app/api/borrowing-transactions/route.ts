import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export async function GET(request: NextRequest) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only ADMIN and SUPER_ADMIN can access borrowing transactions
    if (session.user.role !== "ADMIN" && session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || "" // OVERDUE, ACTIVE, or empty for all
    const limit = parseInt(searchParams.get("limit") || "100", 10)
    const page = parseInt(searchParams.get("page") || "1", 10)

    // Build where conditions
    const whereConditions: any = {}

    // Filter by transaction type if specified
    if (type === "OVERDUE") {
      whereConditions.AND = [
        { return_date: null }, // Not yet returned
        { due_date: { lt: new Date() } } // Past due date
      ]
    } else if (type === "ACTIVE") {
      whereConditions.return_date = null // Currently borrowed (not returned)
    }

    // Calculate skip for pagination
    const skip = (page - 1) * limit

    // Fetch book transactions with related book and user data
    const transactions = await prisma.bookTransaction.findMany({
      where: whereConditions,
      include: {
        book: {
          select: {
            book_id: true,
            title: true,
            book_author: true,
            category: true,
            status: true
          }
        },
        user: {
          select: {
            user_id: true,
            full_name: true,
            email: true,
            user_type: true,
            department: true
          }
        }
      },
      orderBy: [
        {
          borrow_date: 'desc' // Most recent first
        }
      ],
      skip: skip,
      take: limit
    })

    // Get total count for pagination
    const totalCount = await prisma.bookTransaction.count({
      where: whereConditions
    })

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limit)
    const hasMore = page < totalPages

    // Transform the data to include computed fields
    const transformedTransactions = transactions.map(transaction => {
      const isOverdue = !transaction.return_date && transaction.due_date < new Date()
      const daysBorrowed = Math.floor(
        (Date.now() - new Date(transaction.borrow_date).getTime()) / (1000 * 60 * 60 * 24)
      )
      
      return {
        transaction_id: transaction.transaction_id,
        book: transaction.book,
        user: transaction.user,
        borrow_date: transaction.borrow_date,
        due_date: transaction.due_date,
        return_date: transaction.return_date,
        penalty: transaction.penalty,
        status: transaction.return_date ? "RETURNED" : (isOverdue ? "OVERDUE" : "ACTIVE"),
        days_borrowed: daysBorrowed,
        is_overdue: isOverdue
      }
    })

    return NextResponse.json({
      success: true,
      transactions: transformedTransactions,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore
      }
    })

  } catch (error) {
    console.error("Error fetching book transactions:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
