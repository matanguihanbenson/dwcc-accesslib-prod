import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { AuditService } from "@/lib/services/audit.service"
import { UserRole } from "@/types"

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ transaction_id: string }> }
) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only ADMIN and SUPER_ADMIN can process returns
    if (session.user.role !== "ADMIN" && session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const resolvedParams = await params
    const transactionId = parseInt(resolvedParams.transaction_id)

    // Get the transaction with related data
    const transaction = await prisma.bookTransaction.findUnique({
      where: { transaction_id: transactionId },
      include: {
        book: true,
        user: true
      }
    })

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 })
    }

    if (transaction.return_date) {
      return NextResponse.json({ 
        error: "Book has already been returned" 
      }, { status: 400 })
    }

    const returnDate = new Date()
    
    // Calculate penalty if overdue
    let penalty = transaction.penalty
    if (returnDate > transaction.due_date) {
      const overdueDays = Math.floor(
        (returnDate.getTime() - transaction.due_date.getTime()) / (1000 * 60 * 60 * 24)
      )
      // Add penalty of 10 pesos per day overdue
      const newPenaltyAmount = Number(penalty) + (overdueDays * 10)
      penalty = newPenaltyAmount as any
    }

    // Update the transaction and book status
    const updatedTransaction = await prisma.$transaction(async (tx) => {
      // Update the book transaction
      const updated = await tx.bookTransaction.update({
        where: { transaction_id: transactionId },
        data: {
          return_date: returnDate,
          penalty: penalty
        },
        include: {
          book: true,
          user: true
        }
      })

      // Update book status to AVAILABLE
      await tx.book.update({
        where: { book_id: transaction.book_id },
        data: { status: "AVAILABLE" }
      })

      return updated
    })

    // Log the audit activity
    const currentUserAccount = await prisma.userAccount.findUnique({
      where: { username: session.user.username },
      include: { user: true }
    })

    if (currentUserAccount?.user) {
      await AuditService.logActivity({
        userId: currentUserAccount.user.user_id,
        role: currentUserAccount.role as UserRole,
        description: `Processed book return: "${transaction.book.title}" from user ${transaction.user.full_name} (${transaction.user.email})${penalty > transaction.penalty ? ` with penalty of ₱${penalty}` : ""}`
      })
    }

    return NextResponse.json({
      success: true,
      message: "Book return processed successfully",
      transaction: updatedTransaction,
      penalty_applied: Number(penalty) > Number(transaction.penalty)
    })

  } catch (error) {
    console.error("Error processing book return:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
