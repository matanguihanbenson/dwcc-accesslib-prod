import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { AuditService } from "@/lib/services/audit.service"
import { UserRole } from "@/types"

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ transaction_id: string }> }
) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only ADMIN and SUPER_ADMIN can approve transactions
    if (session.user.role !== "ADMIN" && session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const resolvedParams = await params
    const transactionId = parseInt(resolvedParams.transaction_id)

    // Get the transaction with related data
    const transaction = await prisma.bookTransaction.findUnique({
      where: { transaction_id: transactionId },
      include: {
        book: true,
        user: true
      }
    })

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 })
    }

    // Check if this transaction is already processed
    if (transaction.return_date) {
      return NextResponse.json({ 
        error: "Transaction has already been returned" 
      }, { status: 400 })
    }

    let updatedTransaction
    let auditDescription = ""

    // Determine if this is a borrow or return request
    if (!transaction.borrow_date) {
      // This is a borrow request
      const dueDate = new Date()
      dueDate.setDate(dueDate.getDate() + 14) // 14 days from now

      updatedTransaction = await prisma.$transaction(async (tx) => {
        // Update the borrowing transaction
        const updated = await tx.bookTransaction.update({
          where: { transaction_id: transactionId },
          data: {
            borrow_date: new Date(),
            due_date: dueDate
          },
          include: {
            book: true,
            user: true
          }
        })

        // Update book status to BORROWED
        await tx.book.update({
          where: { book_id: transaction.book_id },
          data: { status: "BORROWED" }
        })

        return updated
      })

      auditDescription = `Approved borrow request: "${transaction.book.title}" for user ${transaction.user.full_name} (${transaction.user.email})`

    } else {
      // This is a return request
      updatedTransaction = await prisma.$transaction(async (tx) => {
        // Update the borrowing transaction
        const updated = await tx.bookTransaction.update({
          where: { transaction_id: transactionId },
          data: {
            return_date: new Date()
          },
          include: {
            book: true,
            user: true
          }
        })

        // Update book status to AVAILABLE
        await tx.book.update({
          where: { book_id: transaction.book_id },
          data: { status: "AVAILABLE" }
        })

        return updated
      })

      auditDescription = `Approved return request: "${transaction.book.title}" from user ${transaction.user.full_name} (${transaction.user.email})`
    }

    // Log the audit activity
    const currentUserAccount = await prisma.userAccount.findUnique({
      where: { username: session.user.username },
      include: { user: true }
    })

    if (currentUserAccount?.user) {
      await AuditService.logActivity({
        userId: currentUserAccount.user.user_id,
        role: currentUserAccount.role as UserRole,
        description: auditDescription
      })
    }

    return NextResponse.json({
      success: true,
      message: "Transaction approved successfully",
      transaction: updatedTransaction
    })

  } catch (error) {
    console.error("Error approving transaction:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
