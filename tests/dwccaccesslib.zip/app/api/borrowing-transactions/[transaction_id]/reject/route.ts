import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { AuditService } from "@/lib/services/audit.service"
import { UserRole } from "@/types"

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ transaction_id: string }> }
) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only ADMIN and SUPER_ADMIN can reject transactions
    if (session.user.role !== "ADMIN" && session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const resolvedParams = await params
    const transactionId = parseInt(resolvedParams.transaction_id)
    const body = await request.json()
    const { reason } = body

    // Get the transaction with related data
    const transaction = await prisma.bookTransaction.findUnique({
      where: { transaction_id: transactionId },
      include: {
        book: true,
        user: true
      }
    })

    if (!transaction) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 })
    }

    // Check if this transaction is already processed
    if (transaction.return_date) {
      return NextResponse.json({ 
        error: "Transaction has already been returned" 
      }, { status: 400 })
    }

    // Since we don't have a status field, we can delete the transaction to reject it
    // Or we could add a penalty or note field to indicate rejection
    // For now, let's just add a penalty to indicate rejection
    const updatedTransaction = await prisma.bookTransaction.update({
      where: { transaction_id: transactionId },
      data: {
        penalty: -1 // Use negative penalty to indicate rejection
      },
      include: {
        book: true,
        user: true
      }
    })

    // Determine the transaction type for audit log
    const transactionType = transaction.borrow_date ? "return" : "borrow"
    const auditDescription = `Rejected ${transactionType} request: "${transaction.book.title}" for user ${transaction.user.full_name} (${transaction.user.email})${reason ? ` - Reason: ${reason}` : ""}`

    // Log the audit activity
    const currentUserAccount = await prisma.userAccount.findUnique({
      where: { username: session.user.username },
      include: { user: true }
    })

    if (currentUserAccount?.user) {
      await AuditService.logActivity({
        userId: currentUserAccount.user.user_id,
        role: currentUserAccount.role as UserRole,
        description: auditDescription
      })
    }

    return NextResponse.json({
      success: true,
      message: "Transaction rejected successfully",
      transaction: updatedTransaction
    })

  } catch (error) {
    console.error("Error rejecting transaction:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
