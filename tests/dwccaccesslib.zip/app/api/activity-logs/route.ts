import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { UserRole } from "@/types"

export async function GET(request: NextRequest) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only SUPER_ADMIN can access activity logs
    if (session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get("page") || "1", 10)
    const limit = parseInt(searchParams.get("limit") || "25", 10)
    const search = searchParams.get("search") || ""
    const action = searchParams.get("action") || ""
    const userType = searchParams.get("userType") || ""
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")

    // Build where conditions
    const whereConditions: any = {}

    // Date range filter
    if (startDate || endDate) {
      whereConditions.date_time_log = {}
      if (startDate) {
        whereConditions.date_time_log.gte = new Date(startDate)
      }
      if (endDate) {
        const endDateTime = new Date(endDate)
        endDateTime.setHours(23, 59, 59, 999) // End of day
        whereConditions.date_time_log.lte = endDateTime
      }
    }

    // User type filter
    if (userType) {
      whereConditions.user = {
        user_type: userType
      }
    }

    // Search functionality (search in description and user name)
    if (search) {
      whereConditions.OR = [
        {
          description: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          user: {
            full_name: {
              contains: search,
              mode: 'insensitive'
            }
          }
        },
        {
          user: {
            account_id: {
              contains: search,
              mode: 'insensitive'
            }
          }
        }
      ]
    }

    // Calculate skip for pagination
    const skip = (page - 1) * limit

    // Fetch audit logs with user information
    const auditLogs = await prisma.auditLog.findMany({
      where: whereConditions,
      include: {
        user: {
          select: {
            full_name: true,
            account_id: true,
            user_type: true,
            email: true,
            status: true
          }
        }
      },
      orderBy: {
        date_time_log: 'desc'
      },
      skip: skip,
      take: limit
    })

    // Get total count for pagination
    const totalCount = await prisma.auditLog.count({
      where: whereConditions
    })

    // Transform data to match the frontend interface
    const formattedLogs = auditLogs.map(log => ({
      id: log.event_id,
      user_id: log.user_id,
      action: log.description, // Using description as action
      details: log.description,
      created_at: log.date_time_log.toISOString(),
      user: log.user ? {
        full_name: log.user.full_name,
        account_id: log.user.account_id,
        role: log.role, // Role from audit log
        user_type: log.user.user_type,
        email: log.user.email,
        status: log.user.status
      } : null,
      ip_address: null, 
      user_agent: null  
    }))

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limit)
    const hasMore = page < totalPages

    return NextResponse.json({
      success: true,
      logs: formattedLogs,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore
      }
    })

  } catch (error) {
    console.error("Error fetching activity logs:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
