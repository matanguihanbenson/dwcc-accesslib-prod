import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET(request: NextRequest) {
  try {
    // Get query parameters for filtering
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search") || ""
    const category = searchParams.get("category") || ""
    const limit = parseInt(searchParams.get("limit") || "50", 10)
    const page = parseInt(searchParams.get("page") || "1", 10)

    // Build where conditions - only show AVAILABLE books for public access
    const whereConditions: any = {
      status: 'AVAILABLE'
    }

    // Category filter
    if (category) {
      whereConditions.category = {
        contains: category,
        mode: 'insensitive'
      }
    }

    // Search functionality
    if (search) {
      whereConditions.OR = [
        {
          title: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          book_author: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          category: {
            contains: search,
            mode: 'insensitive'
          }
        }
      ]
    }

    // Calculate skip for pagination
    const skip = (page - 1) * limit

    // Fetch available books from the book table
    const books = await prisma.book.findMany({
      where: whereConditions,
      select: {
        book_id: true,
        title: true,
        book_author: true,
        category: true,
        status: true
      },
      orderBy: [
        {
          title: 'asc'
        }
      ],
      skip: skip,
      take: limit
    })

    // Get total count for pagination
    const totalCount = await prisma.book.count({
      where: whereConditions
    })

    // Get available categories for filtering
    const categories = await prisma.book.findMany({
      where: {
        status: 'AVAILABLE'
      },
      select: {
        category: true
      },
      distinct: ['category'],
      orderBy: {
        category: 'asc'
      }
    })

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limit)
    const hasMore = page < totalPages

    return NextResponse.json({
      success: true,
      books: books,
      categories: categories.map(c => c.category),
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore
      }
    })

  } catch (error) {
    console.error("Error fetching public books:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
