import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import jwt from 'jsonwebtoken'

export async function GET(request: NextRequest) {
  try {
    let currentUserRole: string | null = null
    let isAuthenticated = false

    // Try NextAuth session first
    const session = await getServerSession(authOptions)
    
    if (session?.user?.username) {
      try {
        const userAccount = await prisma.userAccount.findUnique({
          where: {
            username: session.user.username,
            is_active: true
          }
        })
        
        if (userAccount) {
          currentUserRole = userAccount.role
          isAuthenticated = true
        }
      } catch (dbError) {
        console.error('Database error during session lookup:', dbError)
      }
    }

    // If no session, try JWT token from cookies
    if (!isAuthenticated) {
      const token = request.cookies.get('token')?.value
      
      if (token) {
        try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
          const userId = decoded.userId

          const userAccount = await prisma.userAccount.findUnique({
            where: { id: userId, is_active: true }
          })

          if (userAccount) {
            currentUserRole = userAccount.role
            isAuthenticated = true
          }
        } catch (jwtError) {
          console.warn('JWT verification failed:', jwtError)
        }
      }
    }

    if (!isAuthenticated || !currentUserRole) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 })
    }

    // Check permissions - Only ADMIN and STAFF can view overdue items
    if (!['ADMIN', 'STAFF', 'SUPER_ADMIN'].includes(currentUserRole)) {
      return NextResponse.json({ error: 'Insufficient permissions' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'all' // 'books', 'lockers', or 'all'

    const currentDate = new Date()
    const response: any = {}

    // Fetch overdue books
    if (type === 'books' || type === 'all') {
      const overdueBooks = await prisma.bookTransaction.findMany({
        where: {
          due_date: {
            lt: currentDate
          },
          return_date: null // Only unreturned books
        },
        include: {
          book: {
            select: {
              title: true,
              book_author: true,
              category: true
            }
          },
          user: {
            select: {
              full_name: true,
              email: true,
              user_type: true,
              course: true,
              department: true,
              contact_number: true,
              account_id: true
            }
          }
        },
        orderBy: {
          due_date: 'asc' // Oldest overdue first
        }
      })

      // Calculate days overdue and penalty for each book
      const overdueBooksWithCalculations = overdueBooks.map(transaction => {
        const daysOverdue = Math.floor(
          (currentDate.getTime() - transaction.due_date.getTime()) / (1000 * 60 * 60 * 24)
        )
        const calculatedPenalty = Math.max(Number(transaction.penalty), daysOverdue * 10) // 10 pesos per day
        
        return {
          ...transaction,
          days_overdue: daysOverdue,
          calculated_penalty: calculatedPenalty
        }
      })

      response.overdue_books = overdueBooksWithCalculations
    }

    // Fetch overdue lockers
    if (type === 'lockers' || type === 'all') {
      const overdueLockers = await prisma.lockerTransaction.findMany({
        where: {
          return_time: null, // Only unreturned lockers
          borrow_time: {
            lt: new Date(currentDate.getTime() - 24 * 60 * 60 * 1000) // More than 24 hours ago
          }
        },
        include: {
          locker: {
            select: {
              locker_number: true,
              status: true
            }
          },
          user: {
            select: {
              full_name: true,
              email: true,
              user_type: true,
              course: true,
              department: true,
              contact_number: true,
              account_id: true
            }
          }
        },
        orderBy: {
          borrow_time: 'asc' // Oldest usage first
        }
      })

      // Calculate hours/days overdue and penalty for each locker
      const overdueLockerWithCalculations = overdueLockers.map(transaction => {
        const hoursUsed = Math.floor(
          (currentDate.getTime() - transaction.borrow_time.getTime()) / (1000 * 60 * 60)
        )
        const daysUsed = Math.floor(hoursUsed / 24)
        const calculatedPenalty = Math.max(Number(transaction.penalty), daysUsed * 5) // 5 pesos per day overdue
        
        return {
          ...transaction,
          hours_used: hoursUsed,
          days_used: daysUsed,
          calculated_penalty: calculatedPenalty
        }
      })

      response.overdue_lockers = overdueLockerWithCalculations
    }

    // Add summary statistics
    response.summary = {
      total_overdue_books: response.overdue_books?.length || 0,
      total_overdue_lockers: response.overdue_lockers?.length || 0,
      total_book_penalties: response.overdue_books?.reduce((sum: number, book: any) => sum + book.calculated_penalty, 0) || 0,
      total_locker_penalties: response.overdue_lockers?.reduce((sum: number, locker: any) => sum + locker.calculated_penalty, 0) || 0
    }

    // Add cache control headers
    const responseObj = NextResponse.json(response)
    responseObj.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate')
    responseObj.headers.set('Pragma', 'no-cache')
    responseObj.headers.set('Expires', '0')

    return responseObj
    
  } catch (error) {
    console.error('Error fetching overdue items:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
