import { NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function POST(request: NextRequest) {
  try {
    console.log('Starting to fix invalid book status values...')
    
    // First, let's see what's in the database by using raw query
    const rawBooks = await prisma.$queryRaw`
      SELECT book_id, title, book_author, category, status 
      FROM book 
      WHERE status NOT IN ('AVAILABLE', 'BORROWED', 'MISSING', 'DAMAGED') 
         OR status IS NULL 
         OR status = ''
      LIMIT 10
    `
    
    console.log('Books with invalid status:', rawBooks)
    
    // Update all books with empty or invalid status to AVAILABLE
    const updateResult = await prisma.$executeRaw`
      UPDATE book 
      SET status = 'AVAILABLE' 
      WHERE status NOT IN ('AVAILABLE', 'BORROWED', 'MISSING', 'DAMAGED') 
         OR status IS NULL 
         OR status = ''
    `
    
    console.log(`Updated ${updateResult} books with invalid status`)
    
    // Verify the fix by counting total books
    const totalBooks = await prisma.book.count()
    console.log(`Total books in database: ${totalBooks}`)
    
    // Now try to fetch some books using Prisma
    const validBooks = await prisma.book.findMany({
      take: 5,
      orderBy: {
        book_id: 'desc'
      }
    })
    
    console.log(`Successfully fetched ${validBooks.length} books with Prisma`)
    
    return NextResponse.json({
      success: true,
      message: `Fixed ${updateResult} books with invalid status`,
      invalidBooks: rawBooks,
      validBooksCount: validBooks.length,
      totalBooks: totalBooks,
      sampleBooks: validBooks
    })

  } catch (error) {
    console.error("Error fixing book status:", error)
    return NextResponse.json(
      { 
        error: "Database error", 
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
