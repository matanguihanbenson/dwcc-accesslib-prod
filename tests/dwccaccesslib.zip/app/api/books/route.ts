import { NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { AuditService } from "@/lib/services/audit.service"
import { UserRole } from "@/types"

export async function GET(request: NextRequest) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only ADMIN and SUPER_ADMIN can access books management
    if (session.user.role !== "ADMIN" && session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    // Get query parameters for filtering
    const { searchParams } = new URL(request.url)
    const search = searchParams.get("search") || ""
    const status = searchParams.get("status") || ""
    const category = searchParams.get("category") || ""
    const limit = parseInt(searchParams.get("limit") || "1000", 10)
    const page = parseInt(searchParams.get("page") || "1", 10)

    // Build where conditions
    const whereConditions: any = {}

    // Status filter - only add if status is a valid enum value
    if (status && ['AVAILABLE', 'BORROWED', 'MISSING', 'DAMAGED'].includes(status)) {
      whereConditions.status = status
    }

    // Category filter
    if (category) {
      whereConditions.category = {
        contains: category,
        mode: 'insensitive'
      }
    }

    // Search functionality
    if (search) {
      whereConditions.OR = [
        {
          title: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          book_author: {
            contains: search,
            mode: 'insensitive'
          }
        },
        {
          category: {
            contains: search,
            mode: 'insensitive'
          }
        }
      ]
    }

    // Calculate skip for pagination
    const skip = (page - 1) * limit

    // Fetch books from the book table
    const books = await prisma.book.findMany({
      where: whereConditions,
      orderBy: [
        {
          status: 'asc' // Available first
        },
        {
          title: 'asc'
        }
      ],
      skip: skip,
      take: limit
    })

    // Get total count for pagination
    const totalCount = await prisma.book.count({
      where: whereConditions
    })

    // Calculate pagination info
    const totalPages = Math.ceil(totalCount / limit)
    const hasMore = page < totalPages

    return NextResponse.json({
      success: true,
      books: books,
      pagination: {
        page,
        limit,
        totalCount,
        totalPages,
        hasMore
      }
    })

  } catch (error) {
    console.error("Error fetching books:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    // Check authentication and authorization
    const session = await getServerSession(authOptions)
    
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only ADMIN and SUPER_ADMIN can add books
    if (session.user.role !== "ADMIN" && session.user.role !== "SUPER_ADMIN") {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    const body = await request.json()
    const { 
      title, 
      book_author, 
      category
    } = body

    // Validate required fields
    if (!title || !book_author || !category) {
      return NextResponse.json({ error: "Missing required fields: title, author, and category are required" }, { status: 400 })
    }

    // Build book data object - only include fields that exist in the schema
    const bookData = {
      title: title.trim(),
      book_author: book_author.trim(),
      category: category.trim(),
      status: "AVAILABLE" as const
    }

    // Create new book
    const newBook = await prisma.book.create({
      data: bookData
    })

    // Log the audit activity
    const currentUserAccount = await prisma.userAccount.findUnique({
      where: { username: session.user.username },
      include: { user: true }
    })

    if (currentUserAccount?.user) {
      await AuditService.logActivity({
        userId: currentUserAccount.user.user_id,
        role: currentUserAccount.role as UserRole,
        description: `Added new book: "${title}" by ${book_author}`
      })
    }

    return NextResponse.json({
      success: true,
      message: "Book added successfully",
      book: newBook
    })

  } catch (error) {
    console.error("Error adding book:", error)
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    )
  }
}
