"use client";
import React, { useState, useEffect } from 'react'

type Occupant = {
  id: string;
  name: string;
  rentedDate: string;
  expiryDate: string;
  startTime: Date;
  currentExtensions: number;
  lastExtended: Date;
};

type Locker = {
  id: string;
  number: string;
  isAvailable: boolean;
  occupant: Occupant | null;
};

type StudentData = {
  id: string;
  name: string;
  role: string;
  department: string;
  yearLevel: string;
};

type LockerStatus = {
  timeUsedHours: string;
  allowedHours: number;
  exceededHours: string;
  fine: number;
  isOvertime: boolean;
};

interface StaffViewProps {
  lockers: Locker[]
  statusFilter: string
  setStatusFilter: (filter: string) => void
  availableCount: number
  occupiedCount: number
  onAssignLocker: () => void
  onExtendRequest: (locker: Locker) => void
  onReturnLocker: () => void
  scannerInput: string
  setScannerInput: (input: string) => void
  isScanning: boolean
  setIsScanning: (scanning: boolean) => void
  userData: StudentData
  setUserData: (data: StudentData) => void
  showAssignModal: boolean
  setShowAssignModal: (show: boolean) => void
  showExtensionModal: boolean
  setShowExtensionModal: (show: boolean) => void
  showReturnModal: boolean
  setShowReturnModal: (show: boolean) => void
  selectedLocker: Locker | null
  setSelectedLocker: (locker: Locker | null) => void
  handleScanSubmit: (e: React.FormEvent) => void
  handleUserScan: (e: React.FormEvent) => void
  handleAssignSubmit: () => void
  handleExtensionSubmit: (e: React.FormEvent) => void
  handleReturnSubmit: (e: React.FormEvent) => void
}

function StaffView({ 
  lockers, 
  statusFilter, 
  setStatusFilter, 
  availableCount, 
  occupiedCount,
  onExtendRequest
}: StaffViewProps): React.ReactElement {
  
  const [isClient, setIsClient] = useState<boolean>(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  // Calculate time used and fines
  const calculateLockerStatus = (locker: Locker): LockerStatus | null => {
    if (!locker.occupant || !isClient) return null;
    
    const now = new Date();
    const startTime = new Date(locker.occupant.startTime);
    const timeUsedMs = now.getTime() - startTime.getTime();
    const timeUsedHours = timeUsedMs / (1000 * 60 * 60);
    const allowedHours = 2 + (locker.occupant.currentExtensions * 2);
    const exceededHours = Math.max(0, timeUsedHours - allowedHours);
    const fine = exceededHours > 0 ? Math.ceil(exceededHours) * 20 : 0;
    
    return {
      timeUsedHours: timeUsedHours.toFixed(1),
      allowedHours,
      exceededHours: exceededHours.toFixed(1),
      fine,
      isOvertime: exceededHours > 0
    };
  };

  return (
    <div className='px-4 py-4'>
      {/* Compact Status Summary */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-white rounded-lg shadow-sm border p-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-xs">Total</p>
              <p className="text-lg font-bold text-gray-800">{availableCount + occupiedCount}</p>
            </div>
            <i className="fas fa-archive text-blue-600 text-lg"></i>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-xs">Available</p>
              <p className="text-lg font-bold text-green-600">{availableCount}</p>
            </div>
            <i className="fas fa-check-circle text-green-500 text-lg"></i>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border p-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-600 text-xs">Occupied</p>
              <p className="text-lg font-bold text-red-600">{occupiedCount}</p>
            </div>
            <i className="fas fa-lock text-red-500 text-lg"></i>
          </div>
        </div>
      </div>

      {/* Compact Legend and Filters */}
      <div className="flex items-center justify-between mb-4">
        <div className='flex gap-4 items-center text-xs'>
          <div className='flex items-center gap-1'>
            <i className="fas fa-circle text-green-500 text-xs"></i>
            <span className="text-gray-700">Available</span>
          </div>
          <div className='flex items-center gap-1'>
            <i className="fas fa-circle text-red-500 text-xs"></i>
            <span className="text-gray-700">Occupied</span>
          </div>
          <div className='flex items-center gap-1'>
            <i className="fas fa-circle text-orange-500 text-xs"></i>
            <span className="text-gray-700">Overtime</span>
          </div>
        </div>
        
        <select 
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-2 py-1 border border-gray-200 rounded text-xs focus:ring-1 focus:ring-blue-500 focus:border-transparent outline-none"
        >
          <option>All Status</option>
          <option>Available</option>
          <option>Occupied</option>
        </select>
      </div>

      {/* Compact Lockers Grid */}
      <div className="bg-white rounded-lg shadow-sm border p-3">
        <div className="grid grid-cols-8 gap-2 max-h-[calc(100vh-350px)] overflow-y-auto">
          {lockers.map((locker: Locker) => {
            const status = calculateLockerStatus(locker);
            
            return (
              <div
                key={locker.id}
                className={`relative p-2 rounded border cursor-pointer transition-all hover:shadow-sm group ${
                  locker.isAvailable 
                    ? 'border-green-200 bg-green-50 hover:border-green-300' 
                    : status?.isOvertime 
                      ? 'border-orange-200 bg-orange-50 hover:border-orange-300'
                      : 'border-red-200 bg-red-50 hover:border-red-300'
                }`}
                title={locker.isAvailable ? `Locker ${locker.number} - Available` : `Locker ${locker.number} - ${locker.occupant?.name}`}
              >
                {/* Compact Locker Number */}
                <div className="text-center">
                  <div className={`w-8 h-8 mx-auto rounded flex items-center justify-center text-xs font-bold mb-1 ${
                    locker.isAvailable ? 'bg-green-600 text-white' 
                      : status?.isOvertime ? 'bg-orange-500 text-white'
                      : 'bg-red-500 text-white'
                  }`}>
                    {locker.number}
                  </div>
                  
                  {/* Compact time indicator */}
                  {!locker.isAvailable && status && isClient && (
                    <div className="text-xs text-gray-600">
                      <div>{status.timeUsedHours}h</div>
                      {status.isOvertime && (
                        <div className="text-orange-600 font-medium text-xs">₱{status.fine}</div>
                      )}
                    </div>
                  )}
                </div>

                {/* Status Icon */}
                <i className={`absolute top-1 right-1 text-xs ${
                  locker.isAvailable ? 'fas fa-circle text-green-500' 
                    : status?.isOvertime ? 'fas fa-circle text-orange-500'
                    : 'fas fa-circle text-red-500'
                }`}></i>

                {/* Compact Hover Details */}
                {!locker.isAvailable && locker.occupant && isClient && (
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 opacity-0 group-hover:opacity-100 transition-opacity bg-gray-800 text-white text-xs rounded p-2 whitespace-nowrap z-10 pointer-events-none">
                    <div className="space-y-1">
                      <div className="font-medium">{locker.occupant.name}</div>
                      <div>ID: {locker.occupant.id}</div>
                      <div>Used: {status?.timeUsedHours}h / {status?.allowedHours}h</div>
                      {status?.isOvertime && (
                        <div className="text-orange-300">Fine: ₱{status.fine}</div>
                      )}
                    </div>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-2 border-transparent border-t-gray-800"></div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  )
}

export default StaffView