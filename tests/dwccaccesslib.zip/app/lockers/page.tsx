"use client";
import React, { useState, useMemo } from 'react'
import AdminView from './AdminView'
import StaffView from './StaffView'
import Swal from 'sweetalert2'
import { 
  showLockerAssignedSuccess, 
  showLockerAssignmentError, 
  showNoAvailableLockersWarning,
  showUserNotFoundWarning,
  showAssigningLockerLoading,
  closeLockerLoading
} from '../utils/lockerAlerts'

/* Type definitions added */
type Occupant = {
	id: string;
	name: string;
	rentedDate: string;
	expiryDate: string;
	startTime: Date;
	currentExtensions: number;
	lastExtended: Date;
};

type Locker = {
	id: string;
	number: string;
	isAvailable: boolean;
	occupant: Occupant | null;
};

type StudentData = {
	id: string;
	name: string;
	role: string;
	department: string;
	yearLevel: string;
};

// type LockerStatus = {
// 	timeUsedHours: string;
// 	allowedHours: number;
// 	exceededHours: string;
// 	fine: number;
// 	isOvertime: boolean;
// };

function Lockers(): React.ReactElement {
  // User type state - in real app, this would come from auth context
  const [userType, setUserType] = useState<'admin' | 'staff'>('staff'); // Default to staff for demo
  const [statusFilter, setStatusFilter] = useState<string>('All Status');
  const [showExtensionModal, setShowExtensionModal] = useState<boolean>(false);
  const [showAssignModal, setShowAssignModal] = useState<boolean>(false);
  const [selectedLocker, setSelectedLocker] = useState<Locker | null>(null);
  const [scannerInput, setScannerInput] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [studentData, setStudentData] = useState<StudentData>({
    id: '',
    name: '',
    role: '',
    department: '',
    yearLevel: ''
  });
  const [selectedAvailableLocker, setSelectedAvailableLocker] = useState<string>('');
  const [rfidKeyInput, setRfidKeyInput] = useState<string>('');
  const [showReturnModal, setShowReturnModal] = useState<boolean>(false);


  const studentDatabase: Record<string, StudentData> = {
    "2021-001234": {
      id: "2021-001234",
      name: "John Doe",
      role: "Student",
      department: "Computer Science",
      yearLevel: "3rd Year"
    },
    "2020-005678": {
      id: "2020-005678",
      name: "Jane Smith",
      role: "Student",
      department: "Information Technology",
      yearLevel: "4th Year"
    },
    "FACULTY-001": {
      id: "FACULTY-001",
      name: "Dr. Maria Santos",
      role: "Faculty",
      department: "Computer Science",
      yearLevel: "N/A"
    }
  };

  /* typed lockers array */
  const lockers: Locker[] = Array.from({ length: 50 }, (_, i) => {
    const lockerNumber = `L-${(i + 1).toString().padStart(2, '0')}`;
    const isOccupied = i === 0; // Only first locker is occupied
    
    return {
      id: lockerNumber,
      number: lockerNumber,
      isAvailable: !isOccupied,
      occupant: isOccupied ? {
        name: 'John Doe',
        id: '2021-1234',
        rentedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toLocaleDateString(),
        expiryDate: new Date(Date.now() + 23 * 24 * 60 * 60 * 1000).toLocaleDateString(),
        startTime: new Date(Date.now() - 150 * 60 * 1000), // 2.5 hours ago
        currentExtensions: 1,
        lastExtended: new Date(Date.now() - 30 * 60 * 1000)
      } : null,
    };
  });


  // const calculateLockerStatus = (locker: Locker): LockerStatus | null => {
  //   if (!locker.occupant) return null;
    
  //   const now = new Date();
  //   const startTime = locker.occupant.startTime;
  //   const timeUsedMs = now.getTime() - startTime.getTime();
  //   const timeUsedHours = timeUsedMs / (1000 * 60 * 60);
  //   const allowedHours = 2 + (locker.occupant.currentExtensions * 2);
  //   const exceededHours = Math.max(0, timeUsedHours - allowedHours);
  //   const fine = exceededHours > 0 ? Math.ceil(exceededHours) * 20 : 0;
    
  //   return {
  //     timeUsedHours: timeUsedHours.toFixed(1),
  //     allowedHours,
  //     exceededHours: exceededHours.toFixed(1),
  //     fine,
  //     isOvertime: exceededHours > 0
  //   };
  // };

  const handleExtendRequest = (locker: Locker) => {
    setSelectedLocker(locker);
    setShowExtensionModal(true);
    setScannerInput('');
  };

  const handleScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scannerInput.trim()) return;

    if (!selectedLocker) {
      Swal.fire({
        icon: 'error',
        title: 'No Locker Selected',
        text: 'No locker selected to extend.',
        confirmButtonColor: '#dc2626'
      });
      return;
    }

    setIsScanning(true);
    
    setTimeout(() => {
      const expectedKey = `KEY-${selectedLocker.number}`;
      
      if (scannerInput.trim() === expectedKey || scannerInput.trim() === selectedLocker.number) {
        Swal.fire({
          icon: 'success',
          title: 'Extension Successful!',
          text: `Locker ${selectedLocker.number} extended by 2 hours.`,
          confirmButtonColor: '#059669'
        });
        setShowExtensionModal(false);
        setSelectedLocker(null);
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Invalid Key',
          text: 'Invalid locker key! Please scan the correct key for this locker.',
          confirmButtonColor: '#dc2626'
        });
      }
      
      setIsScanning(false);
      setScannerInput('');
    }, 1000);
  };

  const handleAssignLocker = () => {
    setShowAssignModal(true);
    setScannerInput('');
    setStudentData({
      id: '',
      name: '',
      role: '',
      department: '',
      yearLevel: ''
    });
  };

  const handleUserScan = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!scannerInput.trim()) return

    setIsScanning(true)
    
    try {
      const response = await fetch('/api/users/lookup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ searchInput: scannerInput.trim() }),
        credentials: 'include'
      })

      if (response.ok) {
        const userData = await response.json()
        console.log('User lookup result:', userData)
        setStudentData(userData)
      } else {
        console.error('Failed to lookup user:', response.status)
        setStudentData({
          id: scannerInput,
          name: "User not found",
          role: '',
          department: '',
          yearLevel: ''
        })
      }
    } catch (error) {
      console.error('Error during user lookup:', error)
      setStudentData({
        id: scannerInput,
        name: "User not found", 
        role: '',
        department: '',
        yearLevel: ''
      })
    } finally {
      setIsScanning(false)
    }
  };

  const handleAssignSubmit = async () => {
    if (!studentData.name || studentData.name === "User not found") {
      showUserNotFoundWarning();
      return;
    }

    if (!rfidKeyInput.trim()) {
      showLockerAssignmentError('Please scan the locker key first.');
      return;
    }

    const keyMatch = rfidKeyInput.match(/L-\d+/);
    if (!keyMatch) {
      showLockerAssignmentError('Invalid key format. Please scan a valid locker key.');
      return;
    }

    const lockerNumber = keyMatch[0];
    const availableLocker = lockers.find(l => l.number === lockerNumber && l.isAvailable);
    if (!availableLocker) {
      showLockerAssignmentError(`Locker ${lockerNumber} is not available or already assigned.`);
      return;
    }

    showAssigningLockerLoading();

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
    
      closeLockerLoading();
      await showLockerAssignedSuccess(availableLocker.number, studentData.name);
      
      setShowAssignModal(false);
      setScannerInput('');
      setSelectedAvailableLocker('');
      setRfidKeyInput('');
      setStudentData({
        id: '',
        name: '',
        role: '',
        department: '',
        yearLevel: ''
      });
    } catch (error) {
      closeLockerLoading();
      showLockerAssignmentError('Failed to assign locker. Please try again.');
    }
  };

  const filteredLockers = useMemo(() => {
    if (statusFilter === 'Available') {
      return lockers.filter(locker => locker.isAvailable);
    } else if (statusFilter === 'Occupied') {
      return lockers.filter(locker => !locker.isAvailable);
    }
    return lockers;
  }, [statusFilter, lockers]);

  const availableCount = lockers.filter(l => l.isAvailable).length;
  const occupiedCount = lockers.length - availableCount;

  // Mock usage records for admin view
  const usageRecords = [
    {
      id: "2021-001234",
      fullName: "John Doe",
      role: "Student",
      programDepartment: "Computer Science",
      yearLevel: "3rd Year",
      lockerNo: "L-01",
      assignedDate: "2025-01-15",
      status: "Active"
    },
    {
      id: "2020-005678",
      fullName: "Jane Smith",
      role: "Student",
      programDepartment: "Information Technology",
      yearLevel: "4th Year",
      lockerNo: "L-15",
      assignedDate: "2025-01-10",
      status: "Expired"
    }
  ];

  const safeUserData = studentData || {
    id: '',
    name: '',
    role: '',
    department: '',
    yearLevel: ''
  }

  const handleReturnLocker = () => {
    setShowReturnModal(true);
    setScannerInput('');
  };

  const handleExtensionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scannerInput.trim()) return;

    setIsScanning(true);
    
    setTimeout(() => {
      const keyMatch = scannerInput.match(/L-\d+/);
      const lockerNumber = keyMatch ? keyMatch[0] : scannerInput;
      const foundLocker = lockers.find(l => l.number === lockerNumber && !l.isAvailable);
      
      if (foundLocker) {
        Swal.fire({
          icon: 'success',
          title: 'Extension Successful!',
          text: `Locker ${foundLocker.number} extended by 2 hours.`,
          confirmButtonColor: '#ea580c'
        });
        setShowExtensionModal(false);
        setSelectedLocker(null);
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Invalid Key',
          text: 'Key not found or locker is not currently occupied.',
          confirmButtonColor: '#dc2626'
        });
      }
      
      setIsScanning(false);
      setScannerInput('');
    }, 1000);
  };

  const handleReturnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scannerInput.trim()) return;

    setIsScanning(true);
    
    // Simulate scanning delay
    setTimeout(() => {
      // Find locker by key
      const keyMatch = scannerInput.match(/L-\d+/);
      const lockerNumber = keyMatch ? keyMatch[0] : scannerInput;
      const foundLocker = lockers.find(l => l.number === lockerNumber && !l.isAvailable);
      
      if (foundLocker) {
        Swal.fire({
          icon: 'success',
          title: 'Return Successful!',
          text: `Locker ${foundLocker.number} has been successfully returned.`,
          confirmButtonColor: '#059669'
        });
        setShowReturnModal(false);
        setSelectedLocker(null);
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Invalid Key',
          text: 'Key not found or locker is already available.',
          confirmButtonColor: '#dc2626'
        });
      }
      
      setIsScanning(false);
      setScannerInput('');
    }, 1000);
  };

  const handleExtendTime = () => {
    setShowExtensionModal(true);
    setSelectedLocker(null);
    setScannerInput('');
  };

  return (
    <>
      <div className="bg-gray-50 h-screen overflow-hidden">
        <div className="bg-white shadow-sm border-b">
          <div className="px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <h1 className="text-xl font-semibold text-gray-800">
                  {userType === 'admin' ? 'Locker Management' : 'Locker Status'}
                </h1>
                <select 
                  value={userType} 
                  onChange={(e) => setUserType(e.target.value as 'admin' | 'staff')}
                  className="text-sm border border-gray-300 rounded px-2 py-1"
                >
                  <option value="staff">Staff View</option>
                  <option value="admin">Admin View</option>
                </select>
              </div>
              
              {userType === 'staff' && (
                <div className="flex gap-3">
                  <button 
                    onClick={handleReturnLocker}
                    className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-sm flex items-center gap-2"
                  >
                    <i className="fas fa-undo"></i>
                    Return Locker
                  </button>
                  <button 
                    onClick={handleExtendTime}
                    className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-sm flex items-center gap-2"
                  >
                    <i className="fas fa-clock"></i>
                    Extend Time
                  </button>
                  <button 
                    onClick={handleAssignLocker}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-sm"
                  >
                    Assign Locker
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {userType === 'admin' ? (
          <AdminView usageRecords={usageRecords} />
        ) : (
          <StaffView 
            lockers={filteredLockers} 
            statusFilter={statusFilter} 
            setStatusFilter={setStatusFilter}
            availableCount={availableCount}
            occupiedCount={occupiedCount}
            onAssignLocker={handleAssignLocker}
            onExtendRequest={handleExtendRequest}
            onReturnLocker={handleReturnLocker}
            scannerInput={scannerInput}
            setScannerInput={setScannerInput}
            isScanning={isScanning}
            setIsScanning={setIsScanning}
            userData={studentData}
            setUserData={setStudentData}
            showAssignModal={showAssignModal}
            setShowAssignModal={setShowAssignModal}
            showExtensionModal={showExtensionModal}
            setShowExtensionModal={setShowExtensionModal}
            showReturnModal={showReturnModal}
            setShowReturnModal={setShowReturnModal}
            selectedLocker={selectedLocker}
            setSelectedLocker={setSelectedLocker}
            handleScanSubmit={handleScanSubmit}
            handleUserScan={handleUserScan}
            handleAssignSubmit={handleAssignSubmit}
            handleExtensionSubmit={handleExtensionSubmit}
            handleReturnSubmit={handleReturnSubmit}
          />
        )}

        {/* Assign Locker Modal with Workflow */}
        {showAssignModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-2xl p-6 max-w-4xl w-full mx-4">
              <div className="flex items-center gap-3 mb-6">
                <i className="fas fa-user-plus text-green-600 text-xl"></i>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800">Assign Locker</h3>
                  
                  {/* Step Progress Indicator */}
                  <div className="flex items-center gap-2 mt-2">
                    <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${safeUserData.id ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      <i className={`fas fa-id-card ${safeUserData.id ? 'text-green-600' : 'text-gray-400'}`}></i>
                      <span>1. Scan User ID</span>
                      {safeUserData.id && <i className="fas fa-check ml-1"></i>}
                    </div>
                    <i className="fas fa-arrow-right text-gray-400 text-xs"></i>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${rfidKeyInput ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      <i className={`fas fa-key ${rfidKeyInput ? 'text-green-600' : 'text-gray-400'}`}></i>
                      <span>2. Scan Locker Key</span>
                      {rfidKeyInput && <i className="fas fa-check ml-1"></i>}
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                {/* Step 1: User ID Scanner */}
                <div className="border-r border-gray-200 pr-6">
                  <div className="flex items-center gap-2 mb-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${safeUserData.id ? 'bg-green-600 text-white' : 'bg-gray-300 text-gray-600'}`}>
                      1
                    </div>
                    <h4 className="text-sm font-medium text-gray-700">Scan User ID</h4>
                  </div>
                  
                  <form onSubmit={handleUserScan} className="space-y-4">
                    <div>
                      <input
                        type="text"
                        value={scannerInput || ''}
                        onChange={(e) => setScannerInput(e.target.value)}
                        placeholder="Scan user ID or RFID..."
                        className="w-full px-3 py-2 border border-gray-200 rounded focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                        disabled={isScanning}
                        autoFocus
                      />
                      {isScanning && (
                        <div className="flex items-center justify-center mt-2">
                          <i className="fas fa-spinner fa-spin text-green-600 mr-2"></i>
                          <span className="text-sm text-gray-600">Scanning...</span>
                        </div>
                      )}
                    </div>
                    <button
                      type="submit"
                      disabled={isScanning || !scannerInput?.trim()}
                      className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded transition-colors text-sm"
                    >
                      {isScanning ? 'Scanning...' : 'Find User'}
                    </button>
                  </form>

                  {/* User Information Display */}
                  {safeUserData.id && (
                    <div className="mt-4 bg-gray-50 rounded-lg p-3">
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">ID:</span>
                          <span className="font-medium">{safeUserData.id}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Name:</span>
                          <span className={`font-medium ${safeUserData.name === "User not found" ? "text-red-600" : "text-green-600"}`}>
                            {safeUserData.name}
                          </span>
                        </div>
                        {safeUserData.role && safeUserData.name !== "User not found" && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Type:</span>
                              <span className="font-medium">{safeUserData.role}</span>
                            </div>
                            {safeUserData.department && (
                              <div className="flex justify-between">
                                <span className="text-gray-600">Dept:</span>
                                <span className="font-medium">{safeUserData.department}</span>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Step 2: RFID Key Scanner */}
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${rfidKeyInput ? 'bg-green-600 text-white' : safeUserData.name && safeUserData.name !== "User not found" ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'}`}>
                      2
                    </div>
                    <h4 className="text-sm font-medium text-gray-700">Scan Locker Key</h4>
                  </div>

                  {safeUserData.name && safeUserData.name !== "User not found" ? (
                    <div className="space-y-4">
                      <input
                        type="text"
                        value={rfidKeyInput}
                        onChange={(e) => setRfidKeyInput(e.target.value)}
                        placeholder="Scan the locker key you're giving to the user..."
                        className="w-full px-3 py-2 border border-gray-200 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none text-sm"
                      />

                      {rfidKeyInput && (
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <div className="text-xs text-blue-700 space-y-1">
                            <div className="font-medium">Key Scanned: {rfidKeyInput}</div>
                            <div>User: {safeUserData.name}</div>
                            <div>Type: {safeUserData.role}</div>
                          </div>
                        </div>
                      )}


                    </div>
                  ) : (
                    <div className="text-center text-gray-500 py-8">
                      <i className="fas fa-user-times text-2xl text-gray-400 mb-2"></i>
                      <p className="text-sm">Complete Step 1 first</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowAssignModal(false);
                    setScannerInput('');
                    setSelectedAvailableLocker('');
                    setRfidKeyInput('');
                    setStudentData({
                      id: '',
                      name: '',
                      role: '',
                      department: '',
                      yearLevel: ''
                    });
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                >
                  <i className="fas fa-times mr-2"></i>Cancel
                </button>
                <button
                  onClick={handleAssignSubmit}
                  disabled={!safeUserData.name || safeUserData.name === "User not found" || !rfidKeyInput.trim()}
                  className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded transition-colors"
                >
                  <i className="fas fa-plus mr-2"></i>Assign Locker
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Extension Modal */}
        {showExtensionModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-2xl p-6 max-w-md w-full mx-4">
              <div className="flex items-center gap-3 mb-6">
                <i className="fas fa-clock text-orange-600 text-xl"></i>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800">Extend Library Time</h3>
                  <p className="text-sm text-gray-600">
                    {selectedLocker 
                      ? `Scan RFID key for locker ${selectedLocker.number}`
                      : 'Scan any RFID key to identify and extend the locker time'
                    }
                  </p>
                </div>
              </div>

              <form onSubmit={handleExtensionSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <i className="fas fa-key mr-2"></i>RFID Key Scanner
                  </label>
                  <input
                    type="text"
                    value={scannerInput}
                    onChange={(e) => setScannerInput(e.target.value)}
                    placeholder="Scan RFID key..."
                    className="w-full px-3 py-2 border border-gray-200 rounded focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
                    disabled={isScanning}
                    autoFocus
                  />
                  {isScanning && (
                    <div className="flex items-center justify-center mt-2">
                      <i className="fas fa-spinner fa-spin text-orange-600 mr-2"></i>
                      <span className="text-sm text-gray-600">Processing...</span>
                    </div>
                  )}
                </div>

                {selectedLocker && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600 space-y-2">
                      <div className="flex justify-between">
                        <span>Locker:</span>
                        <span className="font-medium">#{selectedLocker.number}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>User:</span>
                        <span className="font-medium">{selectedLocker?.occupant?.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Extension:</span>
                        <span className="font-medium text-orange-600">+2 Hours</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Extensions:</span>
                        <span className="font-medium">{selectedLocker?.occupant?.currentExtensions || 0}</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-blue-700">
                    <i className="fas fa-info-circle"></i>
                    <span className="text-sm">Extension will add 2 hours to the current locker time limit</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowExtensionModal(false);
                      setSelectedLocker(null);
                      setScannerInput('');
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                    disabled={isScanning}
                  >
                    <i className="fas fa-times mr-2"></i>Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isScanning || !scannerInput.trim()}
                    className="flex-1 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 text-white px-4 py-2 rounded transition-colors"
                  >
                    <i className="fas fa-plus-circle mr-2"></i>
                    {isScanning ? 'Processing...' : 'Extend Time'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Return Locker Modal */}
        {showReturnModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-2xl p-6 max-w-md w-full mx-4">
              <div className="flex items-center gap-3 mb-6">
                <i className="fas fa-undo text-red-600 text-xl"></i>
                <div>
                  <h3 className="text-xl font-semibold text-gray-800">Return Locker Key</h3>
                  <p className="text-sm text-gray-600">Scan the RFID key to process return</p>
                </div>
              </div>

              <form onSubmit={handleReturnSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <i className="fas fa-key mr-2"></i>RFID Key Scanner
                  </label>
                  <input
                    type="text"
                    value={scannerInput}
                    onChange={(e) => setScannerInput(e.target.value)}
                    placeholder="Scan RFID key to return..."
                    className="w-full px-3 py-2 border border-gray-200 rounded focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                    disabled={isScanning}
                    autoFocus
                  />
                  {isScanning && (
                    <div className="flex items-center justify-center mt-2">
                      <i className="fas fa-spinner fa-spin text-red-600 mr-2"></i>
                      <span className="text-sm text-gray-600">Processing return...</span>
                    </div>
                  )}
                </div>

                {selectedLocker && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="text-sm text-gray-600 space-y-2">
                      <div className="flex justify-between">
                        <span>Locker:</span>
                        <span className="font-medium">#{selectedLocker.number}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>User:</span>
                        <span className="font-medium">{selectedLocker.occupant?.name}</span>
                      </div>
                    </div>
                  </div>
                )}


                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setShowReturnModal(false);
                      setSelectedLocker(null);
                      setScannerInput('');
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                    disabled={isScanning}
                  >
                    <i className="fas fa-times mr-2"></i>Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isScanning || !scannerInput.trim()}
                    className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white px-4 py-2 rounded transition-colors"
                  >
                    <i className="fas fa-check mr-2"></i>
                    {isScanning ? 'Processing...' : 'Process Return'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  )
}

export default Lockers
