"use client"
import React, { useState } from 'react'
import {
  showSuccessAlert,
  showErrorAlert,
  showConfirmDialog
} from '../utils/sweetalerts'

interface UsageRecord {
  id: string;
  fullName: string;
  role: string;
  programDepartment: string;
  yearLevel: string;
  lockerNo: string;
  assignedDate: string;
  status: string;
}

interface Locker {
  id: string;
  lockerNumber: string;
  status: 'AVAILABLE' | 'OCCUPIED' | 'DAMAGED' | 'MAINTENANCE';
  rfidCode?: string;
  assignedTo?: string;
  assignedDate?: string;
}

interface AdminViewProps {
  usageRecords: UsageRecord[]
}

function AdminView({ usageRecords }: AdminViewProps) {
  const [activeTab, setActiveTab] = useState('lockers');
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [programFilter, setProgramFilter] = useState("");
  const [yearLevelFilter, setYearLevelFilter] = useState("");
  
  // New state for locker management
  const [showAddLockerModal, setShowAddLockerModal] = useState(false);
  const [showUpdateLockerModal, setShowUpdateLockerModal] = useState(false);
  const [showRfidScanner, setShowRfidScanner] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scannerInput, setScannerInput] = useState('');
  const [selectedLocker, setSelectedLocker] = useState<Locker | null>(null);
  
  // Mock locker data - replace with actual API call
  const [lockers] = useState<Locker[]>([
    { id: '1', lockerNumber: 'L-001', status: 'AVAILABLE', rfidCode: 'RFID001' },
    { id: '2', lockerNumber: 'L-002', status: 'OCCUPIED', rfidCode: 'RFID002', assignedTo: 'John Doe', assignedDate: '2025-01-15' },
    { id: '3', lockerNumber: 'L-003', status: 'DAMAGED', rfidCode: 'RFID003' },
    { id: '4', lockerNumber: 'L-004', status: 'MAINTENANCE' },
  ]);
  
  // Form data
  const [newLockerData, setNewLockerData] = useState({
    lockerNumber: '',
    rfidCode: ''
  });

  const handleAddLocker = () => {
    setShowAddLockerModal(true);
    setNewLockerData({ lockerNumber: '', rfidCode: '' });
  };

  const handleUpdateLocker = (locker: Locker) => {
    setSelectedLocker(locker);
    setShowUpdateLockerModal(true);
    setNewLockerData({ 
      lockerNumber: locker?.lockerNumber || '', 
      rfidCode: locker?.rfidCode || '' 
    });
  };

  const handleRfidScan = () => {
    setShowRfidScanner(true);
    setScannerInput('');
  };

  const handleScanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!scannerInput.trim()) return;

    setIsScanning(true);
    
    // Simulate scanning delay
    setTimeout(() => {
      // Process the scanned RFID code
      setNewLockerData(prev => ({ ...prev, rfidCode: scannerInput.trim() }));
      setShowRfidScanner(false);
      setScannerInput('');
      setIsScanning(false);
    }, 1000);
  };

  const handleSubmitAddLocker = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLockerData.lockerNumber.trim()) {
      showErrorAlert('Error', 'Please enter a locker number');
      return;
    }

    try {
      // Simulate API call
      console.log('Adding locker:', newLockerData);
      showSuccessAlert('Success', `Locker ${newLockerData.lockerNumber} added successfully!`);
      
      setShowAddLockerModal(false);
      setNewLockerData({ lockerNumber: '', rfidCode: '' });
    } catch (error) {
      showErrorAlert('Error', 'Failed to add locker. Please try again.');
    }
  };

  const handleSubmitUpdateLocker = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLockerData.lockerNumber.trim()) {
      showErrorAlert('Error', 'Please enter a locker number');
      return;
    }

    const result = await showConfirmDialog(
      'Update Locker',
      `Are you sure you want to update this locker to "${newLockerData.lockerNumber}"?`,
      'Yes, update it!'
    );

    if (result) {
      try {
        // Simulate API call
        console.log('Updating locker:', selectedLocker, 'with data:', newLockerData);
        showSuccessAlert('Success', `Locker updated to ${newLockerData.lockerNumber} successfully!`);
        
        setShowUpdateLockerModal(false);
        setSelectedLocker(null);
        setNewLockerData({ lockerNumber: '', rfidCode: '' });
      } catch (error) {
        showErrorAlert('Error', 'Failed to update locker. Please try again.');
      }
    }
  };

  const renderTabs = () => (
    <div className="border-b border-gray-200 mb-4">
      <nav className="-mb-px flex space-x-8">
        <button
          onClick={() => setActiveTab('lockers')}
          className={`py-2 px-1 border-b-2 font-medium text-sm ${
            activeTab === 'lockers'
              ? 'border-blue-500 text-blue-600'
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
          }`}
        >
          All Lockers
        </button>
        <button
          onClick={() => setActiveTab('usage')}
          className={`py-2 px-1 border-b-2 font-medium text-sm ${
            activeTab === 'usage'
              ? 'border-blue-500 text-blue-600'
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
          }`}
        >
          Usage Records
        </button>
      </nav>
    </div>
  );

  const renderLockersTab = () => (
    <div className="space-y-4">
      {/* Header with Add Locker Button */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-medium text-gray-800">
          Locker Management
        </h2>
        <button
          onClick={handleAddLocker}
          className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded text-xs font-medium transition-colors flex items-center gap-1"
        >
          <i className="fas fa-plus"></i>
          Add Locker
        </button>
      </div>

      {/* Lockers Table */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-200">
          <h3 className="text-sm font-medium text-gray-800">
            All Lockers
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Locker Number
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  RFID Code
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Assigned To
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Assigned Date
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {lockers.map((locker) => (
                <tr key={locker.id}>
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                    {locker.lockerNumber}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      locker.status === 'AVAILABLE' ? 'bg-green-100 text-green-800' :
                      locker.status === 'OCCUPIED' ? 'bg-blue-100 text-blue-800' :
                      locker.status === 'DAMAGED' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {locker.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 font-mono">
                    {locker.rfidCode || '-'}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                    {locker.assignedTo || '-'}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                    {locker.assignedDate || '-'}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-xs font-medium">
                    <button
                      onClick={() => handleUpdateLocker(locker)}
                      className="text-blue-600 hover:text-blue-900 px-2 py-1 text-xs border border-blue-600 hover:bg-blue-50 rounded transition-colors"
                      title="Update Locker"
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderUsageTab = () => (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-sm font-medium text-gray-800 mb-3">
          Search Locker Usage Records
        </h2>

        <div className="flex gap-3 mb-3">
          <div className="flex-1">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
              placeholder="Search by ID, name, locker number..."
            />
          </div>
          <button className="bg-blue-600 text-white px-4 py-2 text-xs rounded-md hover:bg-blue-700 transition-colors">
            Search
          </button>
          <button className="bg-gray-300 text-gray-700 px-4 py-2 text-xs rounded-md hover:bg-gray-400 transition-colors">
            Clear
          </button>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Filter by Role
            </label>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Roles</option>
              <option value="student">Student</option>
              <option value="employee">Employee</option>
              <option value="guest">Guest</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Filter by Program
            </label>
            <select
              value={programFilter}
              onChange={(e) => setProgramFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Programs</option>
              <option value="computer-science">Computer Science</option>
              <option value="information-technology">Information Technology</option>
              <option value="business">Business</option>
              <option value="education">Education</option>
              <option value="engineering">Engineering</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">
              Filter by Year Level
            </label>
            <select
              value={yearLevelFilter}
              onChange={(e) => setYearLevelFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Year Levels</option>
              <option value="1">1st Year</option>
              <option value="2">2nd Year</option>
              <option value="3">3rd Year</option>
              <option value="4">4th Year</option>
            </select>
          </div>

          <div className="flex items-end">
            <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
              Apply Filters
            </button>
          </div>
        </div>
      </div>

      {/* Usage Records Table */}
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-200">
          <h3 className="text-sm font-medium text-gray-800">
            Locker Usage Records
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Full Name
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Role
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Program/Department
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Year Level
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Locker No.
                </th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {usageRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-6 text-center text-xs text-gray-500">
                    No usage records found. Data will be loaded from database.
                  </td>
                </tr>
              ) : (
                usageRecords.map((record, index) => (
                  <tr key={index}>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {record.id}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {record.fullName}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {record.role}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {record.programDepartment}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {record.yearLevel}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      {record.lockerNo}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        record.status === 'Active' ? 'bg-green-100 text-green-800' :
                        record.status === 'Expired' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {record.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  return (
    <div className="p-4">
      {renderTabs()}
      
      {activeTab === 'lockers' && renderLockersTab()}
      {activeTab === 'usage' && renderUsageTab()}

      {/* Add Locker Modal */}
      {showAddLockerModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-2xl p-4 max-w-md w-full mx-4">
            <div className="flex items-center gap-2 mb-4">
              <i className="fas fa-plus text-green-600"></i>
              <h3 className="text-lg font-semibold text-gray-800">Add New Locker</h3>
            </div>

            <form onSubmit={handleSubmitAddLocker} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Locker Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newLockerData.lockerNumber}
                  onChange={(e) => setNewLockerData(prev => ({ ...prev, lockerNumber: e.target.value }))
                  }
                  className="w-full px-2 py-2 text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-green-500"
                  placeholder="e.g., L-51"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  RFID Code
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newLockerData.rfidCode}
                    onChange={(e) => setNewLockerData(prev => ({ ...prev, rfidCode: e.target.value }))
                    }
                    className="flex-1 px-2 py-2 text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-green-500"
                    placeholder="Auto-generated or manual entry"
                  />
                  <button
                    type="button"
                    onClick={handleRfidScan}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-xs flex items-center gap-1"
                  >
                    <i className="fas fa-barcode"></i>
                    Scan
                  </button>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddLockerModal(false)}
                  className="flex-1 px-3 py-2 text-xs border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white px-3 py-2 text-xs rounded transition-colors"
                >
                  Add Locker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Update Locker Modal */}
      {showUpdateLockerModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-2xl p-4 max-w-md w-full mx-4">
            <div className="flex items-center gap-2 mb-4">
              <i className="fas fa-edit text-blue-600"></i>
              <h3 className="text-lg font-semibold text-gray-800">Update Locker</h3>
            </div>

            <form onSubmit={handleSubmitUpdateLocker} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Locker Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newLockerData.lockerNumber}
                  onChange={(e) => setNewLockerData(prev => ({ ...prev, lockerNumber: e.target.value }))
                  }
                  className="w-full px-2 py-2 text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="e.g., L-51"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  RFID Code <span className="text-xs text-gray-500">(Optional - bypass if key is lost)</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newLockerData.rfidCode}
                    onChange={(e) => setNewLockerData(prev => ({ ...prev, rfidCode: e.target.value }))
                    }
                    className="flex-1 px-2 py-2 text-xs border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="Leave empty if key is lost"
                  />
                  <button
                    type="button"
                    onClick={handleRfidScan}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-xs flex items-center gap-1"
                  >
                    <i className="fas fa-barcode"></i>
                    Scan
                  </button>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowUpdateLockerModal(false);
                    setSelectedLocker(null);
                  }}
                  className="flex-1 px-3 py-2 text-xs border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 text-xs rounded transition-colors"
                >
                  Update Locker
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RFID Scanner Modal */}
      {showRfidScanner && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-2xl p-4 max-w-sm w-full mx-4">
            <div className="text-center mb-4">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3 cursor-pointer hover:bg-blue-200 transition-colors">
                <i className="fas fa-barcode text-2xl text-blue-600"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-800">Scan RFID Code</h3>
              <p className="text-xs text-gray-600">Click the scanner icon or use the input below</p>
            </div>

            <form onSubmit={handleScanSubmit} className="space-y-3">
              <div>
                <input
                  type="text"
                  value={scannerInput}
                  onChange={(e) => setScannerInput(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="Scan or enter RFID code..."
                  disabled={isScanning}
                  autoFocus
                />
                {isScanning && (
                  <div className="flex items-center justify-center mt-2">
                    <i className="fas fa-spinner fa-spin text-blue-600 mr-2"></i>
                    <span className="text-xs text-gray-600">Processing...</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowRfidScanner(false);
                    setScannerInput('');
                  }}
                  className="flex-1 px-3 py-2 text-xs border border-gray-300 text-gray-700 rounded hover:bg-gray-50 transition-colors"
                  disabled={isScanning}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isScanning || !scannerInput.trim()}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-3 py-2 text-xs rounded transition-colors"
                >
                  {isScanning ? 'Processing...' : 'Confirm'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminView
