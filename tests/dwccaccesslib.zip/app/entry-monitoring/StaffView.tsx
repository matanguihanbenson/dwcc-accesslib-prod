"use client"
import React from 'react'
import Link from 'next/link'

interface Entry {
  id: string
  name: string
  department: string
  time: string
}

interface StaffViewProps {
  entries: Entry[]
}

function StaffView({ entries }: StaffViewProps) {
  return (
    <div className="p-4 min-h-screen bg-gray-50">
      {/* Header */}
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-lg font-bold text-gray-800">Entry Management</h1>
        <Link href="/entry/view-logs">
          <button className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded text-xs font-medium transition-colors shadow-sm">
            View All Logs
          </button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Entry Form - Takes 2 columns on large screens */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <h2 className="text-sm font-semibold text-gray-800 mb-3">
              Log New Entry
            </h2>

            <form className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    ID No.
                  </label>
                  <input
                    type="text"
                    className="w-full px-2 py-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-green-500 focus:border-transparent outline-none transition-all"
                    placeholder="Enter ID number"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    className="w-full px-2 py-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-green-500 focus:border-transparent outline-none transition-all"
                    placeholder="Enter full name"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Role
                  </label>
                  <select className="w-full px-2 py-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-green-500 focus:border-transparent outline-none transition-all">
                    <option value="">Select role</option>
                    <option value="student">Student</option>
                    <option value="employee">Employee</option>
                    <option value="guest">Guest</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">
                    Year Level
                  </label>
                  <select className="w-full px-2 py-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-green-500 focus:border-transparent outline-none transition-all">
                    <option value="">Select year level</option>
                    <option value="1">1st Year</option>
                    <option value="2">2nd Year</option>
                    <option value="3">3rd Year</option>
                    <option value="4">4th Year</option>
                    <option value="graduate">Graduate</option>
                    <option value="n/a">N/A</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">
                  Course/Department
                </label>
                <input
                  type="text"
                  className="w-full px-2 py-2 text-sm border border-gray-200 rounded-md focus:ring-1 focus:ring-green-500 focus:border-transparent outline-none transition-all"
                  placeholder="Enter course or department"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-md text-sm font-medium transition-colors shadow-sm"
                >
                  Log Entry
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Recent Entries - Takes 1 column */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border h-full flex flex-col">
            <div className="px-3 py-2 border-b border-gray-200">
              <h3 className="text-sm font-semibold text-gray-800">
                Recent Entries
              </h3>
            </div>

            <div className="flex-1 p-3 overflow-y-auto max-h-[500px]">
              <div className="space-y-2">
                {entries.length === 0 ? (
                  <>
                    <div className="bg-gray-50 rounded p-2 border border-gray-100">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-gray-800 text-xs">John Doe</span>
                        <span className="px-1 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          Entry
                        </span>
                      </div>
                      <div className="text-xs text-gray-600 space-y-0.5">
                        <p>ID: 50423</p>
                        <p>Information Technology</p>
                        <p className="text-gray-500">10:30 AM</p>
                      </div>
                    </div>

                    <div className="bg-gray-50 rounded p-2 border border-gray-100">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-gray-800 text-xs">Jane Smith</span>
                        <span className="px-1 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          Entry
                        </span>
                      </div>
                      <div className="text-xs text-gray-600 space-y-0.5">
                        <p>ID: 50424</p>
                        <p>Computer Science</p>
                        <p className="text-gray-500">10:15 AM</p>
                      </div>
                    </div>

                    <div className="bg-gray-50 rounded p-2 border border-gray-100">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-gray-800 text-xs">Mike Johnson</span>
                        <span className="px-1 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          Entry
                        </span>
                      </div>
                      <div className="text-xs text-gray-600 space-y-0.5">
                        <p>ID: 50425</p>
                        <p>Business Administration</p>
                        <p className="text-gray-500">10:05 AM</p>
                      </div>
                    </div>
                  </>
                ) : (
                  entries.map((entry, index) => (
                    <div
                      key={index}
                      className="bg-gray-50 rounded p-2 border border-gray-100"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-gray-800 text-xs">{entry.name}</span>
                        <span className="px-1 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                          Entry
                        </span>
                      </div>
                      <div className="text-xs text-gray-600 space-y-0.5">
                        <p>ID: {entry.id}</p>
                        <p>{entry.department}</p>
                        <p className="text-gray-500">{entry.time}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default StaffView
