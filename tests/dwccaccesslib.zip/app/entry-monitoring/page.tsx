"use client";
import React, { useState } from "react";
import AdminView from "./AdminView";
import StaffView from "./StaffView";

function Entry() {
  const [userType, setUserType] = useState<"admin" | "staff">("staff"); // Default to staff for demo

  const entries = [
    {
      id: "50423",
      name: "John Doe",
      role: "Administrator",
      department: "Information and Technology",
      yearLevel: "4th Year",
      time: "10:30 AM",
    },
    {
      id: "50424",
      name: "Jane Smith",
      role: "Staff",
      department: "Human Resources",
      yearLevel: "N/A",
      time: "11:00 AM",
    },
  ];

  return (
    <>
      <div className="bg-gray-50">
        <div className="bg-white shadow-sm border-b">
          <div className="px-8 py-4 flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-semibold text-gray-800">
                {userType === "admin" ? "User Entry" : "User Entry Logs"}
              </h1>
              {/* Demo user type switcher - remove in production */}
              <select
                value={userType}
                onChange={(e) =>
                  setUserType(e.target.value as "admin" | "staff")
                }
                className="text-sm border border-gray-300 rounded px-2 py-1"
              >
                <option value="staff">Staff View</option>
                <option value="admin">Admin View</option>
              </select>
            </div>
          </div>
        </div>

        {/* Render appropriate view based on user type */}
        {userType === "admin" ? (
          <AdminView entries={entries} />
        ) : (
          <StaffView entries={entries} />
        )}
      </div>
    </>
  );
}

export default Entry;
           