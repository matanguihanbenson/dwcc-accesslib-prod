'use client'

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import {
  showSuccessAlert,
  showErrorAlert,
  showWarningAlert,
  showConfirmDialog
} from '@/app/utils/sweetalerts'

interface User {
  id: string
  name: string
  email: string
  role: string
  avatar?: string
}

function Profile() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [showUpdateModal, setShowUpdateModal] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [updateForm, setUpdateForm] = useState({
    full_name: '',
    username: '',
    user_type: ''
  })
  const [passwordForm, setPasswordForm] = useState({
    old_password: '',
    new_password: '',
    confirm_password: ''
  })
  const [validationErrors, setValidationErrors] = useState({
    username: '',
    old_password: '',
    new_password: '',
    confirm_password: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Fetch user profile data
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch('/api/users/profile', {
          credentials: 'include'
        })
        
        if (response.ok) {
          const data = await response.json()
          if (data.success) {
            setUser(data.data)
          } else {
            console.error('Profile fetch failed:', data.message)
            router.push('/login')
          }
        } else {
          console.error('Profile fetch failed with status:', response.status)
          router.push('/login')
        }
      } catch (error) {
        console.error('Error fetching profile:', error)
        router.push('/login')
      } finally {
        setLoading(false)
      }
    }

    if (status !== 'loading') {
      fetchProfile()
    }
  }, [status, router])

  if (loading || status === 'loading') {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-gray-600">Loading profile...</div>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const openUpdateModal = () => {
    setUpdateForm({
      full_name: user.name || '',
      username: user.id,
      user_type: 'STUDENT', // Default value since we don't have this in the API response
    });
    // Clear all validation errors when opening the modal
    setValidationErrors({
      username: '',
      old_password: '',
      new_password: '',
      confirm_password: '',
    });
    setShowUpdateModal(true)
  }

  const openPasswordModal = () => {
    setPasswordForm({
      old_password: '',
      new_password: '',
      confirm_password: ''
    })
    setValidationErrors({ username: '', old_password: '', new_password: '', confirm_password: '' })
    setShowPasswordModal(true)
  }

  const checkUsernameAvailability = async (username: string) => {
    // Clear any existing error first
    setValidationErrors((prev) => ({
      ...prev,
      username: '',
    }))

    // If it's the same as current username or too short, don't check
    if (username === user.id || username.length < 3) {
      return
    }
    
    // For now, just skip username validation since we don't have the API
    // In production, implement proper username checking API
    console.log('Username validation skipped for demo')
  }

  const validateOldPassword = async (password: string) => {
    if (password.length < 1) {
      setValidationErrors(prev => ({
        ...prev,
        old_password: 'Current password is required'
      }))
      return
    }
    
    try {
      const response = await fetch('/api/auth/verify-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ password })
      })
      const data = await response.json()
      
      setValidationErrors(prev => ({
        ...prev,
        old_password: data.valid ? '' : 'Current password is incorrect'
      }))
    } catch {
      setValidationErrors(prev => ({
        ...prev,
        old_password: 'Error verifying password'
      }))
    }
  }

  const validateNewPassword = (password: string) => {
    if (password.length < 1) {
      setValidationErrors(prev => ({
        ...prev,
        new_password: 'New password is required'
      }))
      return
    }
    
    if (password.length < 6) {
      setValidationErrors(prev => ({
        ...prev,
        new_password: 'Password must be at least 6 characters long'
      }))
    } else {
      setValidationErrors(prev => ({
        ...prev,
        new_password: ''
      }))
    }
  }

  const validateConfirmPassword = (confirmPassword: string) => {
    if (confirmPassword.length < 1) {
      setValidationErrors(prev => ({
        ...prev,
        confirm_password: 'Please confirm your password'
      }))
      return
    }
    
    if (confirmPassword !== passwordForm.new_password) {
      setValidationErrors(prev => ({
        ...prev,
        confirm_password: 'Passwords do not match'
      }))
    } else {
      setValidationErrors(prev => ({
        ...prev,
        confirm_password: ''
      }))
    }
  }

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (validationErrors.username) {
      showErrorAlert('Validation Error', 'Please fix the username error before submitting.')
      return
    }
    
    setIsSubmitting(true)
    
    try {
      // For now, just simulate successful update since we don't have the API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setShowUpdateModal(false)
      showSuccessAlert('Success', 'Profile updated successfully!')
      
      // Update the local user state with new data
      setUser(prev => prev ? {
        ...prev,
        name: updateForm.full_name || prev.name,
        id: updateForm.username || prev.id
      } : null)
      
    } catch (error) {
      console.error('Network error:', error)
      showErrorAlert('Error', 'Failed to update profile. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Validate all fields before submission
    if (!passwordForm.old_password) {
      setValidationErrors(prev => ({ ...prev, old_password: 'Current password is required' }))
    }
    if (!passwordForm.new_password) {
      setValidationErrors(prev => ({ ...prev, new_password: 'New password is required' }))
    }
    if (!passwordForm.confirm_password) {
      setValidationErrors(prev => ({ ...prev, confirm_password: 'Please confirm your password' }))
    }
    
    // Check if there are any validation errors or empty required fields
    if (validationErrors.old_password || validationErrors.new_password || validationErrors.confirm_password ||
        !passwordForm.old_password || !passwordForm.new_password || !passwordForm.confirm_password) {
      showErrorAlert('Validation Error', 'Please fix all validation errors before submitting.')
      return
    }
    
    setIsSubmitting(true)
    
    try {
      // For now, just simulate successful password change since we don't have the API
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      setShowPasswordModal(false)
      setPasswordForm({
        old_password: '',
        new_password: '',
        confirm_password: ''
      })
      showSuccessAlert('Success', 'Password changed successfully!')
      
    } catch (error) {
      console.error('Network error:', error)
      showErrorAlert('Error', 'Failed to change password. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="">
      <div className="bg-white shadow-sm border-b">
        <div className="px-6 py-3">
          <h1 className="text-xl font-semibold text-gray-800">
            User Profile
          </h1>
        </div>
      </div>

      <div className="px-6 py-4">
        <div className="bg-white shadow-md rounded-lg p-4">
          <div className="flex items-center mb-4">
            <div className="w-16 h-16 bg-gray-300 rounded-full flex items-center justify-center">
              <span className="text-xl font-bold text-gray-600">
                {user.name ? user.name.charAt(0).toUpperCase() : user.id.charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="ml-4">
              <h2 className="text-xl font-bold text-gray-800">{user.name || user.id}</h2>
              <p className="text-sm text-gray-600">{user.role}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-md font-semibold text-gray-800 mb-3">Personal Information</h3>
              <div className="space-y-2">
                <div>
                  <label className="block text-xs font-medium text-gray-600">Full Name</label>
                  <p className="text-sm text-gray-900">{user.name || 'N/A'}</p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600">Username/ID</label>
                  <p className="text-sm text-gray-900">{user.id}</p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600">Email</label>
                  <p className="text-sm text-gray-900">{user.email || 'N/A'}</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-md font-semibold text-gray-800 mb-3">Account Information</h3>
              <div className="space-y-2">
                <div>
                  <label className="block text-xs font-medium text-gray-600">Role</label>
                  <p className="text-sm text-gray-900">{user.role}</p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600">Account ID</label>
                  <p className="text-sm text-gray-900">{user.id}</p>
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600">Account Status</label>
                  <span className="px-2 py-1 inline-flex text-xs leading-4 font-semibold rounded-full bg-green-100 text-green-800">
                    Active
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 flex gap-3">
            <button 
              onClick={openUpdateModal}
              className="bg-blue-600 text-white px-4 py-2 text-sm rounded-md hover:bg-blue-700 transition-colors"
            >
              Update Profile
            </button>
            <button 
              onClick={openPasswordModal}
              className="bg-gray-600 text-white px-4 py-2 text-sm rounded-md hover:bg-gray-700 transition-colors"
            >
              Change Password
            </button>
          </div>
        </div>
      </div>

      {/* Update Profile Modal */}
      {showUpdateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 max-w-md">
            <h3 className="text-lg font-semibold mb-4">Update Profile</h3>
            <form onSubmit={handleUpdateProfile}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Full Name</label>
                  <input
                    type="text"
                    value={updateForm.full_name}
                    onChange={(e) => setUpdateForm(prev => ({ ...prev, full_name: e.target.value }))}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Username</label>
                  <input
                    type="text"
                    value={updateForm.username}
                    onChange={(e) => setUpdateForm(prev => ({ ...prev, username: e.target.value }))}
                    onBlur={(e) => checkUsernameAvailability(e.target.value)}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                  {validationErrors.username && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.username}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">User Type</label>
                  <select
                    value={updateForm.user_type}
                    onChange={(e) => setUpdateForm(prev => ({ ...prev, user_type: e.target.value }))}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="STUDENT">Student</option>
                    <option value="EMPLOYEE">Employee</option>
                    <option value="ALUMNI">Alumni</option>
                    <option value="GUEST">Guest</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowUpdateModal(false)}
                  className="px-4 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !!validationErrors.username}
                  className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {isSubmitting ? 'Updating...' : 'Update'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 max-w-md">
            <h3 className="text-lg font-semibold mb-4">Change Password</h3>
            <form onSubmit={handleChangePassword}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Current Password</label>
                  <input
                    type="password"
                    value={passwordForm.old_password}
                    onChange={(e) => setPasswordForm(prev => ({ ...prev, old_password: e.target.value }))}
                    onBlur={(e) => validateOldPassword(e.target.value)}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                  {validationErrors.old_password && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.old_password}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">New Password</label>
                  <input
                    type="password"
                    value={passwordForm.new_password}
                    onChange={(e) => setPasswordForm(prev => ({ ...prev, new_password: e.target.value }))}
                    onBlur={(e) => validateNewPassword(e.target.value)}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                  {validationErrors.new_password && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.new_password}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Confirm New Password</label>
                  <input
                    type="password"
                    value={passwordForm.confirm_password}
                    onChange={(e) => setPasswordForm(prev => ({ ...prev, confirm_password: e.target.value }))}
                    onBlur={(e) => validateConfirmPassword(e.target.value)}
                    required
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                  {validationErrors.confirm_password && (
                    <p className="text-red-500 text-xs mt-1">{validationErrors.confirm_password}</p>
                  )}
                </div>
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || Object.values(validationErrors).some(error => error !== '') || 
                           !passwordForm.old_password || !passwordForm.new_password || !passwordForm.confirm_password}
                  className="px-4 py-2 text-sm bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {isSubmitting ? 'Changing...' : 'Change Password'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default Profile
