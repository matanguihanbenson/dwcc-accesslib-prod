import type { Metadata } from "next";
import { Inter } from "next/font/google";
import Script from "next/script";
import "./globals.css";
import { SessionProvider, ConditionalSidebar, ErrorBoundary } from "@/components";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "DWCC AccessLib",
  description: "Digital library access management system",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${inter.className} antialiased`}
      >
        {/* FontAwesome Script */}
        <Script
          src="https://kit.fontawesome.com/b822ff51a6.js"
          crossOrigin="anonymous"
          strategy="beforeInteractive"
        />
        
        {/* App Layout */}
        <ErrorBoundary>
          <SessionProvider>
            <div className="min-h-screen">
              {/* Sidebar */}
              <ConditionalSidebar />
              
              {/* Main Content */}
              <div className="min-h-screen transition-all duration-300" id="main-content">
                {children}
              </div>
            </div>
          </SessionProvider>
        </ErrorBoundary>
      </body>
    </html>
  );
}

