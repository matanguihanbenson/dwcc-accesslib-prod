export interface ChartDataPoint {
  name: string
  value: number
  [key: string]: string | number
}

export interface TrendData {
  day: Array<{ name: string; entries: number; unique: number }>
  week: Array<{ name: string; entries: number; unique: number }>
  month: Array<{ name: string; entries: number; unique: number }>
  year: Array<{ name: string; entries: number; unique: number }>
}

export interface PieChartData {
  name: string
  value: number
  fill?: string
}

export const formatChartValue = (value: number): string => {
  if (value >= 1000) {
    return `${(value / 1000).toFixed(1)}k`
  }
  return value.toString()
}

export const generateColors = (count: number): string[] => {
  const colors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', 
    '#8B5CF6', '#F97316', '#06B6D4', '#84CC16',
    '#EC4899', '#6366F1'
  ]
  return colors.slice(0, count)
}

export const transformLockerDataForChart = (data: {
  occupiedLockers: number
  availableLockers: number
}): PieChartData[] => {
  const colors = ['#EF4444', '#10B981']
  return [
    {
      name: 'Occupied',
      value: data.occupiedLockers,
      fill: colors[0]
    },
    {
      name: 'Available', 
      value: data.availableLockers,
      fill: colors[1]
    }
  ]
}

export const transformBookDataForChart = (data: {
  borrowedToday: number
  borrowedThisWeek: number
  borrowedThisMonth: number
}): ChartDataPoint[] => {
  return [
    { name: 'Today', value: data.borrowedToday },
    { name: 'This Week', value: data.borrowedThisWeek },
    { name: 'This Month', value: data.borrowedThisMonth }
  ]
}

export const transformOverdueDataForChart = (data: {
  overdueBooks: number
  overdueLockers: number
}): PieChartData[] => {
  const colors = ['#F59E0B', '#EF4444']
  return [
    {
      name: 'Overdue Books',
      value: data.overdueBooks,
      fill: colors[0]
    },
    {
      name: 'Overdue Lockers',
      value: data.overdueLockers,
      fill: colors[1]
    }
  ]
}

export const getTimePeriodData = (
  chartData: TrendData, 
  period: 'day' | 'week' | 'month' | 'year'
): Array<{ name: string; entries: number; unique: number }> => {
  return chartData[period] || []
}

export const calculatePercentage = (value: number, total: number): number => {
  return total > 0 ? Math.round((value / total) * 100) : 0
}
