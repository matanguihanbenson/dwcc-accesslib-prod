# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

## Project Overview

DWCC Access Library is a Next.js 15 library management system with role-based access control. The application manages library users, books, entry monitoring, and locker systems for an academic institution.

## Development Commands

### Core Development
- `npm run dev` - Start development server with Turbopack (fastest)
- `npm run build` - Build production application with Turbopack
- `npm start` - Run production build
- `npm run lint` - Run ESLint code linting

### Database Operations
- `npx prisma generate` - Generate Prisma client after schema changes
- `npx prisma db push` - Push schema changes to development database
- `npx prisma studio` - Open Prisma Studio for database browsing
- `npx prisma migrate dev` - Create and apply new migration
- `npx prisma migrate reset` - Reset database and apply all migrations

## Architecture Overview

### Authentication & Authorization
- **Authentication**: NextAuth.js with credentials provider using bcrypt password hashing
- **Authorization**: Role-based access control with three user roles:
  - `SUPER_ADMIN`: Full system access, user management, audit logs
  - `ADMIN`: Administrative functions, reports, user management (limited)
  - `STAFF`: Day-to-day operations, entry monitoring, book management
- **Session Management**: JWT tokens with 30-minute expiration, dual authentication system (NextAuth + custom JWT)

### Database Architecture
- **ORM**: Prisma with MySQL database
- **Key Models**:
  - `User` - Library patrons (students, employees, alumni, guests)
  - `UserAccount` - Admin/staff login accounts with role-based permissions
  - `Book` & `BookTransaction` - Library book management and borrowing
  - `Locker` & `LockerTransaction` - Study locker rental system
  - `EntryLog` - RFID-based entry monitoring
  - `AuditLog` - System activity tracking
  - `Session` - User session management

### Component Architecture
- **Server Components**: Role-based navigation (`Sidebar.tsx`) with server-side session validation
- **Client Components**: Interactive UI elements, conditional rendering based on authentication
- **Services Layer**: Centralized in `lib/` directory
  - `lib/auth.ts` - NextAuth configuration and user validation
  - `lib/prisma.ts` - Database connection singleton
  - `lib/auth-context.ts` - Client-side authentication context

### Access Control Implementation
- **RoleGuard Pattern**: Navigation items filtered by user role using `allowedNavigationItems`
- **Centralized Role Logic**: Role definitions and permissions in navigation configuration
- **Dynamic UI**: Conditional sidebar rendering based on authentication state

## Code Organization Rules

### Services Pattern
- API calls and data transformations centralized in service files
- Database operations handled through Prisma in `lib/` directory
- Authentication logic separated from business logic

### Component Structure
- Large pages broken into focused components (Dashboard, UserManagement, etc.)
- UI components focused on rendering, logic extracted to services
- Role-based component visibility using centralized permission checks

### Reusability
- Shared utilities in `app/utils/` (e.g., `sweetalerts.ts` for consistent notifications)
- Common authentication patterns in `components/AuthProvider.tsx`
- Centralized type definitions in `types/` directory

## Key Technical Details

### Environment Requirements
- `DATABASE_URL` - MySQL connection string
- `JWT_SECRET` - Secret for JWT token signing
- `NEXTAUTH_SECRET` - NextAuth.js session encryption
- `NEXTAUTH_URL` - Application base URL for callbacks

### Database Schema Features
- Cascade deletes for data integrity
- Enum types for status management (UserRole, BookStatus, etc.)
- Decimal fields for financial tracking (penalties)
- Indexed foreign keys for performance

### Authentication Flow
1. User login via credentials provider
2. Password validation with bcrypt
3. JWT token generation with role information
4. Session refresh mechanism for role updates
5. Automatic last_login timestamp updates

### Role-Based Navigation
Navigation items defined with role arrays, filtered server-side for security. Each route protected with session validation and role checking.

## Development Guidelines

### When Adding New Features
1. Check existing services/utilities before creating new ones
2. Follow role-based access pattern for new pages
3. Use centralized authentication context for client components
4. Implement proper error handling with SweetAlert2 notifications

### Database Changes
1. Update Prisma schema first
2. Generate new client with `npx prisma generate`
3. Create migration for production: `npx prisma migrate dev`
4. Update TypeScript types as needed

### Authentication Integration
- Server components: Use `getServerSession(authOptions)`
- Client components: Use `useSession()` hook or custom `useAuth()`
- API routes: Validate session/JWT in each protected endpoint

## Architecture Patterns

### Dual Authentication System
The system supports both NextAuth sessions and custom JWT tokens for flexibility in different authentication scenarios.

### Service Layer Separation
Business logic separated from UI components, with centralized data fetching and transformation in service files.

### Role-Based Access Control
Permissions centralized in navigation configuration, with server-side validation for security-critical operations.
