import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Basic configuration for stable build
  output: 'standalone',
  poweredByHeader: false,
  
  // Minimal experimental features
  experimental: {
    // optimizeCss: true, // Disabled to avoid critters dependency issue
  },
  
  // Image optimization
  images: {
    formats: ['image/webp', 'image/avif'],
    minimumCacheTTL: 60,
  },
  
  // Security headers
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
