import { NextRequest } from 'next/server'
import jwt from 'jsonwebtoken'
import { JWTPayload } from '@/types'

/**
 * Extracts JWT token from request headers or cookies
 */
function extractTokenFromRequest(req: NextRequest): string | null {
  // Check Authorization header
  const authHeader = req.headers.get('authorization')
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7)
  }

  // Check cookie (for session-based auth)
  const tokenCookie = req.cookies.get('token')
  if (tokenCookie) {
    return tokenCookie.value
  }

  return null
}

/**
 * Verifies JWT token and returns decoded payload
 */
export async function verifyJWTAuth(req: NextRequest): Promise<JWTPayload | null> {
  try {
    const token = extractTokenFromRequest(req)
    
    if (!token) {
      return null
    }

    const jwtSecret = process.env.JWT_SECRET
    if (!jwtSecret) {
      console.error('JWT_SECRET environment variable is not set')
      return null
    }

    const decoded = jwt.verify(token, jwtSecret) as JWTPayload
    return decoded
  } catch (error) {
    console.error('JWT verification failed:', error)
    return null
  }
}

/**
 * Extracts user role from request using NextAuth token or JWT
 */
export async function extractUserRole(req: NextRequest): Promise<string | null> {
  try {
    // Try JWT first
    const jwtAuth = await verifyJWTAuth(req)
    if (jwtAuth?.role) {
      return jwtAuth.role
    }

    // For NextAuth, the role would be in the session token
    // This would be handled by the calling function using getToken()
    return null
  } catch (error) {
    console.error('Error extracting user role:', error)
    return null
  }
}

/**
 * Checks if user has required permission level
 */
export function hasPermission(userRole: string, requiredRole: string | string[]): boolean {
  const roleHierarchy = {
    'SUPER_ADMIN': 3,
    'ADMIN': 2,
    'STAFF': 1,
    'USER': 0
  }

  const userLevel = roleHierarchy[userRole as keyof typeof roleHierarchy] ?? -1
  
  if (Array.isArray(requiredRole)) {
    return requiredRole.some(role => {
      const requiredLevel = roleHierarchy[role as keyof typeof roleHierarchy] ?? 999
      return userLevel >= requiredLevel
    })
  } else {
    const requiredLevel = roleHierarchy[requiredRole as keyof typeof roleHierarchy] ?? 999
    return userLevel >= requiredLevel
  }
}
