import { showErrorAlert } from '@/app/utils/sweetalerts'
import { signOut } from 'next-auth/react'

export class UserStatusChecker {
  private static instance: UserStatusChecker
  private checkInterval: NodeJS.Timeout | null = null
  private isChecking = false

  private constructor() {}

  static getInstance(): UserStatusChecker {
    if (!UserStatusChecker.instance) {
      UserStatusChecker.instance = new UserStatusChecker()
    }
    return UserStatusChecker.instance
  }

  /**
   * Start periodic checking of user status
   */
  startChecking(intervalMs: number = 30000) { // Check every 30 seconds
    if (this.checkInterval) {
      return // Already checking
    }

    console.log('Starting user status monitoring...')
    
    // Check immediately
    this.checkUserStatus()
    
    // Then check periodically
    this.checkInterval = setInterval(() => {
      this.checkUserStatus()
    }, intervalMs)
  }

  /**
   * Stop periodic checking
   */
  stopChecking() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval)
      this.checkInterval = null
      console.log('Stopped user status monitoring')
    }
  }

  /**
   * Check current user's status
   */
  private async checkUserStatus() {
    if (this.isChecking) {
      return // Avoid concurrent checks
    }

    this.isChecking = true

    try {
      const response = await fetch('/api/users/status-check', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      if (response.status === 401) {
        // User is not authenticated, stop checking
        this.stopChecking()
        return
      }

      if (response.ok) {
        const data = await response.json()
        
        if (!data.is_active) {
          // User has been deactivated
          await this.handleDeactivatedUser()
        }
      } else if (response.status === 403) {
        // User account is deactivated
        await this.handleDeactivatedUser()
      }
    } catch (error) {
      // Network error or other issues - don't spam the user
      console.warn('User status check failed:', error)
    } finally {
      this.isChecking = false
    }
  }

  /**
   * Handle when user has been deactivated
   */
  private async handleDeactivatedUser() {
    console.log('User account has been deactivated, logging out...')
    
    // Stop checking to prevent multiple alerts
    this.stopChecking()

    try {
      // Show alert to user
      await showErrorAlert(
        'Account Deactivated',
        'Your account has been deactivated by an administrator. You will be logged out automatically.'
      )

      // Sign out user
      await this.performLogout()
    } catch (error) {
      console.error('Error handling deactivated user:', error)
      // Force logout even if alert fails
      await this.performLogout()
    }
  }

  /**
   * Perform logout
   */
  private async performLogout() {
    try {
      // Try NextAuth signOut first
      await signOut({ redirect: false })
      
      // Also clear any JWT tokens
      document.cookie = 'token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;'
      
      // Force page reload to login
      window.location.href = '/login'
    } catch (error) {
      console.error('Logout error:', error)
      // Force reload even if logout fails
      window.location.href = '/login'
    }
  }

  /**
   * Manual check for user status (can be called on user actions)
   */
  async checkNow(): Promise<boolean> {
    try {
      const response = await fetch('/api/users/status-check', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      })

      if (response.status === 401) {
        return false // Not authenticated
      }

      if (response.status === 403) {
        await this.handleDeactivatedUser()
        return false
      }

      if (response.ok) {
        const data = await response.json()
        
        if (!data.is_active) {
          await this.handleDeactivatedUser()
          return false
        }
        
        return true // User is active
      }

      return false
    } catch (error) {
      console.warn('Manual user status check failed:', error)
      return true // Assume user is active if check fails
    }
  }
}

// Export singleton instance
export const userStatusChecker = UserStatusChecker.getInstance()
