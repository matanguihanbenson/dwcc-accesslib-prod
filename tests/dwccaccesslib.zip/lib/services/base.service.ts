import { ApiResponse, ServiceResult, AppError } from '@/types'

export abstract class BaseService {
  protected readonly baseURL: string

  constructor(baseURL: string = '/api') {
    this.baseURL = baseURL
  }

  /**
   * Make a HTTP request with proper error handling
   */
  protected async makeRequest<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ServiceResult<T>> {
    try {
      const url = `${this.baseURL}${endpoint}`
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      })

      const data = await response.json()

      if (!response.ok) {
        return {
          success: false,
          error: data.error || `HTTP ${response.status}: ${response.statusText}`,
          message: data.message,
        }
      }

      return {
        success: true,
        data: data.data || data,
        message: data.message,
      }
    } catch (error) {
      console.error(`API Request failed for ${endpoint}:`, error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      }
    }
  }

  /**
   * GET request
   */
  protected async get<T>(endpoint: string, params?: Record<string, any>): Promise<ServiceResult<T>> {
    const url = params ? `${endpoint}?${new URLSearchParams(params)}` : endpoint
    return this.makeRequest<T>(url, { method: 'GET' })
  }

  /**
   * POST request
   */
  protected async post<T>(endpoint: string, body?: any): Promise<ServiceResult<T>> {
    return this.makeRequest<T>(endpoint, {
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
    })
  }

  /**
   * PUT request
   */
  protected async put<T>(endpoint: string, body?: any): Promise<ServiceResult<T>> {
    return this.makeRequest<T>(endpoint, {
      method: 'PUT',
      body: body ? JSON.stringify(body) : undefined,
    })
  }

  /**
   * DELETE request
   */
  protected async delete<T>(endpoint: string): Promise<ServiceResult<T>> {
    return this.makeRequest<T>(endpoint, { method: 'DELETE' })
  }

  /**
   * Handle service errors consistently
   */
  protected createError(message: string, statusCode: number = 500, code?: string): AppError {
    const error = new Error(message) as AppError
    error.statusCode = statusCode
    error.code = code
    return error
  }
}

/**
 * Create standardized API responses
 */
export class ApiResponseHelper {
  static success<T>(data?: T, message?: string): ApiResponse<T> {
    return {
      success: true,
      data,
      message,
    }
  }

  static error(error: string, message?: string): ApiResponse {
    return {
      success: false,
      error,
      message,
    }
  }
}
