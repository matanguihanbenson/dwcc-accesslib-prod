import { prisma } from "@/lib/prisma"
import { UserRole } from "@/types"
import logger from "@/lib/logger"

export interface AuditLogData {
  userId: number
  role: UserRole
  description: string
  details?: any
}

export class AuditService {
  /**
   * Log an audit event
   */
  static async logActivity(data: AuditLogData): Promise<void> {
    try {
      await prisma.auditLog.create({
        data: {
          user_id: data.userId,
          role: data.role,
          description: data.description,
          date_time_log: new Date()
        }
      })
      
      logger.info(`Audit log created: ${data.description}`, {
        userId: data.userId.toString(),
        role: data.role
      })
    } catch (error) {
      logger.error("Failed to create audit log", error instanceof Error ? error : new Error(String(error)))
      // Don't throw error to prevent breaking the main operation
    }
  }

  /**
   * Log user authentication events
   */
  static async logAuth(userId: number, role: UserRole, action: 'LOGIN' | 'LOGOUT', details?: string): Promise<void> {
    const description = action === 'LOGIN' ? 'User logged in' : 'User logged out'
    await this.logActivity({
      userId,
      role,
      description: details || description
    })
  }

  /**
   * Log user management events
   */
  static async logUserManagement(
    performedBy: number, 
    performedByRole: UserRole, 
    action: 'CREATED' | 'UPDATED' | 'DELETED' | 'ACTIVATED' | 'DEACTIVATED',
    targetUserId: number,
    targetUserName: string,
    details?: string
  ): Promise<void> {
    const actionMap = {
      'CREATED': `Created user: ${targetUserName}`,
      'UPDATED': `Updated user: ${targetUserName}`,
      'DELETED': `Deleted user: ${targetUserName}`,
      'ACTIVATED': `Activated user: ${targetUserName}`,
      'DEACTIVATED': `Deactivated user: ${targetUserName}`
    }

    await this.logActivity({
      userId: performedBy,
      role: performedByRole,
      description: actionMap[action] + (details ? ` - ${details}` : '')
    })
  }

  /**
   * Log password reset events
   */
  static async logPasswordReset(
    performedBy: number,
    performedByRole: UserRole,
    targetUserName: string,
    isAdminReset: boolean = false
  ): Promise<void> {
    const description = isAdminReset 
      ? `Admin reset password for user: ${targetUserName}`
      : `Password reset requested for user: ${targetUserName}`

    await this.logActivity({
      userId: performedBy,
      role: performedByRole,
      description
    })
  }

  /**
   * Log book transaction events
   */
  static async logBookTransaction(
    userId: number,
    role: UserRole,
    action: 'BORROWED' | 'RETURNED' | 'OVERDUE',
    bookTitle: string,
    details?: string
  ): Promise<void> {
    const actionMap = {
      'BORROWED': `Borrowed book: ${bookTitle}`,
      'RETURNED': `Returned book: ${bookTitle}`,
      'OVERDUE': `Book overdue: ${bookTitle}`
    }

    await this.logActivity({
      userId,
      role,
      description: actionMap[action] + (details ? ` - ${details}` : '')
    })
  }

  /**
   * Log system configuration changes
   */
  static async logSystemChange(
    performedBy: number,
    performedByRole: UserRole,
    action: string,
    details?: string
  ): Promise<void> {
    await this.logActivity({
      userId: performedBy,
      role: performedByRole,
      description: `System change: ${action}${details ? ` - ${details}` : ''}`
    })
  }

  /**
   * Log data export/import events
   */
  static async logDataOperation(
    performedBy: number,
    performedByRole: UserRole,
    operation: 'EXPORT' | 'IMPORT',
    dataType: string,
    details?: string
  ): Promise<void> {
    await this.logActivity({
      userId: performedBy,
      role: performedByRole,
      description: `${operation} ${dataType}${details ? ` - ${details}` : ''}`
    })
  }
}

// Export a default instance
export const auditService = new AuditService()
