import { BaseService } from './base.service'
import { ServiceResult, UserAccount, CreateUserAccountData, UserRole, PaginatedResponse } from '@/types'

class UserService extends BaseService {
  constructor() {
    super('/api/users')
  }

  /**
   * Get users by role
   */
  async getUsersByRole(role: UserRole, page = 1, limit = 10): Promise<ServiceResult<UserAccount[]>> {
    return this.get<UserAccount[]>(`/by-role/${role}`, { page, limit })
  }

  /**
   * Get current user role
   */
  async getCurrentUserRole(): Promise<ServiceResult<{ role: UserRole }>> {
    return this.get<{ role: UserRole }>('/current-role')
  }

  /**
   * Get user profile
   */
  async getUserProfile(): Promise<ServiceResult<UserAccount>> {
    return this.get<UserAccount>('/profile')
  }

  /**
   * Create new user account
   */
  async createUserAccount(data: CreateUserAccountData): Promise<ServiceResult<UserAccount>> {
    return this.post<UserAccount>('/create', data)
  }

  /**
   * Update user account
   */
  async updateUserAccount(id: number, data: Partial<CreateUserAccountData>): Promise<ServiceResult<UserAccount>> {
    return this.put<UserAccount>(`/${id}`, data)
  }

  /**
   * Delete user account
   */
  async deleteUserAccount(id: number): Promise<ServiceResult<void>> {
    return this.delete<void>(`/${id}`)
  }

  /**
   * Reset user password
   */
  async resetPassword(id: number): Promise<ServiceResult<{ newPassword: string }>> {
    return this.post<{ newPassword: string }>(`/${id}/reset-password`)
  }

  /**
   * Toggle user active status
   */
  async toggleUserStatus(id: number, isActive: boolean): Promise<ServiceResult<UserAccount>> {
    return this.put<UserAccount>(`/${id}/status`, { is_active: isActive })
  }

  /**
   * Search users
   */
  async searchUsers(query: string, role?: UserRole): Promise<ServiceResult<UserAccount[]>> {
    const params: Record<string, any> = { query }
    if (role) params.role = role
    return this.get<UserAccount[]>('/search', params)
  }
}

// Create singleton instance
export const userService = new UserService()
export default userService
