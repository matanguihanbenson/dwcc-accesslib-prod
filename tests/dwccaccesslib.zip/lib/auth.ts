import { NextAuthOptions } from "next-auth"
import { JWT } from "next-auth/jwt"
import CredentialsProvider from "next-auth/providers/credentials"
import bcrypt from "bcryptjs"
import { prisma } from "./prisma"
import { UserRole, UserType, AuthUser, JWTPayload } from "@/types"
import logger from "./logger"
import { AuditService } from "./services/audit.service"

export interface ExtendedSession {
  user: AuthUser
  expires: string
}

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.username || !credentials?.password) {
          return null
        }

        try {
          const userAccount = await prisma.userAccount.findUnique({
            where: {
              username: credentials.username,
              is_active: true
            },
            include: {
              user: true
            }
          })

          if (!userAccount || !userAccount.user) {
            return null
          }

          const isPasswordValid = await bcrypt.compare(
            credentials.password,
            userAccount.password_hash
          )

          if (!isPasswordValid) {
            return null
          }

          // Update last login
          await prisma.userAccount.update({
            where: { id: userAccount.id },
            data: { last_login: new Date() }
          })

          // Log successful login
          try {
            await AuditService.logAuth(
              userAccount.user.user_id,
              userAccount.role as UserRole,
              'LOGIN',
              `User ${userAccount.username} logged in successfully`
            )
          } catch (auditError) {
            // Don't fail login if audit logging fails
            logger.error("Failed to log login audit", auditError instanceof Error ? auditError : new Error(String(auditError)))
          }

          return {
            id: userAccount.user.user_id.toString(),
            email: userAccount.user.email || userAccount.username,
            name: userAccount.user.full_name,
            username: userAccount.username,
            role: userAccount.role as UserRole,
            userType: userAccount.user.user_type,
            accountId: userAccount.user.account_id
          }
        } catch (error) {
          console.error("Auth error:", error)
          return null
        }
      }
    })
  ],
  session: {
    strategy: "jwt",
    maxAge: 30 * 60 // 30 minutes - shorter session for testing
  },
  callbacks: {
    async jwt({ token, user }: { token: JWT; user?: any }) {
      if (user) {
        logger.authSuccess(user.username)
        token.role = user.role
        token.userType = user.userType
        token.username = user.username
        token.accountId = user.accountId
      } else {
        // On subsequent requests, fetch fresh data from database
        if (token.username) {
          try {
            const userAccount = await prisma.userAccount.findUnique({
              where: {
                username: token.username as string,
                is_active: true
              },
              include: {
                user: true
              }
            })

            if (userAccount && userAccount.user) {
              token.role = userAccount.role
              token.name = userAccount.user.full_name
              token.userType = userAccount.user.user_type
            }
          } catch (error) {
            logger.error("Error refreshing user data in JWT", error instanceof Error ? error : new Error(String(error)))
          }
        }
      }
      return token
    },
    async session({ session, token }: { session: any; token: JWT }) {
      if (token) {
        session.user.id = token.sub!
        session.user.role = token.role as UserRole
        session.user.name = token.name as string
        session.user.userType = token.userType as string
        session.user.username = token.username as string
        session.user.accountId = token.accountId as string
      }
      return session
    }
  },
  pages: {
    signIn: "/login",
    error: "/login"
  }
}
