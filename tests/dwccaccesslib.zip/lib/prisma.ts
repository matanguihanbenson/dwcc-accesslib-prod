import { PrismaClient } from '@prisma/client'
import logger from './logger'

// Extend global for Prisma client
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Prisma configuration based on environment
const prismaConfig = {
  log: (process.env.NODE_ENV === 'development' 
    ? ['query', 'info', 'warn', 'error']
    : ['warn', 'error']) as any,
  datasources: {
    db: {
      url: process.env.DATABASE_URL,
    },
  },
}

// Create Prisma client with optimized settings
export const prisma = globalForPrisma.prisma ?? new PrismaClient(prismaConfig)

// Add event listeners for logging
if (process.env.NODE_ENV === 'development') {
  (prisma as any).$on('query', (e: any) => {
    logger.debug('Database Query', {
      query: e.query,
      duration: `${e.duration}ms`,
      params: e.params,
    })
  })
}

(prisma as any).$on('error', (e: any) => {
  logger.error('Database Error', new Error(e.message), {
    target: e.target,
  })
})

// Ensure graceful shutdown
process.on('beforeExit', async () => {
  await prisma.$disconnect()
})

// Store in global for development hot reloading
if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma
}
