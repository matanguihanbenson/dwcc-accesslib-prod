"use client"

import { createContext, useContext } from 'react'

export type UserRole = "SUPER_ADMIN" | "ADMIN" | "STAFF"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  avatar?: string
}

export interface AuthContextType {
  user: User | null
  loading: boolean
  signOut: () => void
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
