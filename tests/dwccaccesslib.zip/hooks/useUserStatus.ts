import { useState, useEffect } from 'react'
import { userStatusChecker } from '@/lib/user-status-checker'

export interface UseUserStatusReturn {
  isActive: boolean | null
  isChecking: boolean
  checkUserStatus: () => Promise<boolean>
  lastChecked: Date | null
}

/**
 * React hook for checking user status
 * @param autoCheck - Whether to automatically check status on mount
 * @returns Object with user status information and check function
 */
export function useUserStatus(autoCheck: boolean = false): UseUserStatusReturn {
  const [isActive, setIsActive] = useState<boolean | null>(null)
  const [isChecking, setIsChecking] = useState(false)
  const [lastChecked, setLastChecked] = useState<Date | null>(null)

  const checkUserStatus = async (): Promise<boolean> => {
    if (isChecking) {
      return isActive || false
    }

    setIsChecking(true)
    
    try {
      const result = await userStatusChecker.checkNow()
      setIsActive(result)
      setLastChecked(new Date())
      return result
    } catch (error) {
      console.error('Error checking user status:', error)
      setIsActive(null)
      return false
    } finally {
      setIsChecking(false)
    }
  }

  useEffect(() => {
    if (autoCheck) {
      checkUserStatus()
    }
  }, [autoCheck])

  return {
    isActive,
    isChecking,
    checkUserStatus,
    lastChecked
  }
}

/**
 * React hook that checks user status before performing an action
 * @param action - The action to perform if user is active
 * @returns Function that checks status and performs action
 */
export function useProtectedAction() {
  const { checkUserStatus } = useUserStatus()

  const executeProtectedAction = async (action: () => void | Promise<void>) => {
    const isActive = await checkUserStatus()
    
    if (isActive) {
      await action()
    }
    // If user is not active, the status checker will handle logout and alert
  }

  return executeProtectedAction
}
