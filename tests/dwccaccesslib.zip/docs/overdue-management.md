# Overdue Management Module

## Overview
The Overdue Management module provides a comprehensive system for monitoring and managing overdue books and locker usage within the DWCC AccessLib system.

## Features

### 📚 Overdue Book Management
- **Real-time tracking** of overdue book loans
- **Automatic penalty calculation** (₱10 per day overdue)
- **Severity indicators** based on overdue duration:
  - Yellow: 1-14 days overdue
  - Orange: 15-30 days overdue  
  - Red: 31-60 days overdue
  - Dark Red: 60+ days overdue
- **Quick actions** for processing returns and sending reminders
- **User information display** including contact details and academic info

### 🔐 Overdue Locker Management
- **Real-time tracking** of locker usage beyond 24 hours
- **Automatic penalty calculation** (₱5 per day overdue)
- **Usage duration display** in hours and days
- **Force return functionality** for critical overdue lockers (7+ days)
- **Enhanced penalties** for force returns (₱10 per day, minimum ₱50)

### 🎛️ Management Interface
- **Tabbed interface** switching between books and lockers
- **Advanced filtering** by user type and severity
- **Search functionality** across multiple fields
- **Summary dashboard** showing totals and penalties
- **Responsive design** for all screen sizes

## File Structure

### API Endpoints
- `app/api/overdue/route.ts` - Main API for fetching overdue data
- `app/api/locker-transactions/[transaction_id]/return/route.ts` - Locker return processing
- `app/api/locker-transactions/[transaction_id]/force-return/route.ts` - Force return functionality

### Pages
- `app/overdue/page.tsx` - Main overdue management page

### Components
- `components/overdue/OverdueBooksTable.tsx` - Overdue books table with actions
- `components/overdue/OverdueLockerTable.tsx` - Overdue lockers table with actions

## API Endpoints

### GET /api/overdue
Fetches overdue books and locker data with automatic penalty calculations.

**Query Parameters:**
- `type` - Filter results ('books', 'lockers', or 'all')

**Response:**
```json
{
  "overdue_books": [...],
  "overdue_lockers": [...],
  "summary": {
    "total_overdue_books": 5,
    "total_overdue_lockers": 2,
    "total_book_penalties": 150.00,
    "total_locker_penalties": 75.00
  }
}
```

### PATCH /api/locker-transactions/[transaction_id]/return
Processes a locker return with penalty calculation.

### PATCH /api/locker-transactions/[transaction_id]/force-return
Forces return of an overdue locker with enhanced penalties.

## Permissions

### Role-based Access Control
- **SUPER_ADMIN**: Full access to all overdue management features
- **ADMIN**: Full access to all overdue management features
- **STAFF**: Full access to all overdue management features

## Business Logic

### Book Overdue Calculation
- Books are considered overdue after the due date
- Penalty: ₱10 per day overdue
- Minimum penalty: Current penalty amount in database

### Locker Overdue Calculation
- Lockers are considered overdue after 24 hours of usage
- Regular penalty: ₱5 per day overdue (first day free)
- Force return penalty: ₱10 per day with minimum ₱50

### Data Refresh
- Real-time calculations on each API call
- No caching to ensure accuracy
- Automatic refresh functionality in the UI

## User Interface

### Summary Cards
- Total overdue books count
- Total overdue lockers count
- Total book penalties amount
- Total locker penalties amount

### Filter Options
- **All Users**: Shows all overdue items
- **Students**: Filters by STUDENT user type
- **Employees**: Filters by EMPLOYEE user type  
- **Critical**: Shows items severely overdue (books: 30+ days, lockers: 7+ days)

### Search Functionality
- Books: Search by title, author, user name, account ID
- Lockers: Search by locker number, user name, account ID

### Action Buttons
- **Process Return** (✓): Marks item as returned with penalty calculation
- **Send Reminder** (✉): Sends reminder email (placeholder functionality)
- **Force Return** (⚠): Forces locker return with enhanced penalty (7+ days only)

## Integration Points

### Authentication
- Uses existing NextAuth and JWT token authentication
- Supports both session-based and token-based authentication

### Audit Logging
- All return actions logged via AuditService
- Force returns specially marked in audit logs
- Includes penalty amounts and duration details

### Database Integration
- Works with existing Prisma schema
- Handles Decimal types for penalty calculations
- Transaction-safe updates for data consistency

## Future Enhancements

### Email Integration
- Implement actual email sending for reminders
- Automated overdue notifications
- Escalation emails for critical overdue items

### Reporting
- Export functionality for overdue reports
- Historical overdue trend analysis
- Penalty collection reports

### Advanced Features
- Bulk actions for multiple items
- Custom penalty rates per user type
- Grace period configurations
- Automated return processing

## Navigation
The Overdue Management page is accessible through the main sidebar navigation for users with ADMIN or STAFF roles, located between "Lockers" and "Reports".

## Development Notes
- Built with Next.js 15 and TypeScript
- Uses Tailwind CSS for styling
- Implements responsive design principles
- Follows established code patterns from the existing codebase
- TypeScript compilation passes without errors
