'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/Button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { CalendarDays, Download, FileText, Mail, Printer } from "lucide-react"
import { showErrorAlert, showSuccessAlert, showInfoAlert } from '@/app/utils/sweetalerts'

interface ReportConfig {
  format: 'json' | 'csv' | 'pdf'
  period: 'daily' | 'weekly' | 'monthly' | 'custom'
  startDate?: string
  endDate?: string
  includeDetails: boolean
  includeTrends: boolean
  includeAnalytics: boolean
  includeBreakdowns: boolean
  emailRecipients?: string[]
}

interface ReportData {
  summary: any
  analytics: any
  trends: any
  breakdowns: any
  overdue_items: any
}

interface ReportGeneratorProps {
  data: ReportData
  className?: string
}

export default function ReportGenerator({ data, className = '' }: ReportGeneratorProps) {
  const [config, setConfig] = useState<ReportConfig>({
    format: 'json',
    period: 'weekly',
    includeDetails: true,
    includeTrends: false,
    includeAnalytics: true,
    includeBreakdowns: true
  })

  const [emailRecipient, setEmailRecipient] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)

  const generateReport = async () => {
    if (!data) {
      showErrorAlert('Error', 'No data available for report generation')
      return
    }

    setIsGenerating(true)
    
    try {
      // Build report content based on configuration
      const reportContent: any = {
        metadata: {
          generated_at: new Date().toISOString(),
          period: config.period,
          format: config.format,
          ...(config.startDate && { start_date: config.startDate }),
          ...(config.endDate && { end_date: config.endDate })
        },
        summary: data.summary
      }

      if (config.includeAnalytics) {
        reportContent.analytics = data.analytics
      }

      if (config.includeTrends) {
        reportContent.trends = data.trends
      }

      if (config.includeBreakdowns) {
        reportContent.breakdowns = data.breakdowns
      }

      if (config.includeDetails) {
        reportContent.overdue_items = {
          books_count: data.overdue_items.books.length,
          lockers_count: data.overdue_items.lockers.length,
          ...(config.format === 'json' && { 
            books: data.overdue_items.books,
            lockers: data.overdue_items.lockers 
          })
        }
      }

      await downloadReport(reportContent)
      
    } catch (error) {
      console.error('Error generating report:', error)
      showErrorAlert('Error', 'Failed to generate report')
    } finally {
      setIsGenerating(false)
    }
  }

  const downloadReport = async (content: any) => {
    const timestamp = new Date().toISOString().split('T')[0]
    const filename = `overdue-tracking-report-${timestamp}`

    switch (config.format) {
      case 'json':
        downloadJSON(content, `${filename}.json`)
        break
      case 'csv':
        downloadCSV(content, `${filename}.csv`)
        break
      case 'pdf':
        // For now, we'll generate a JSON and suggest PDF conversion
        downloadJSON(content, `${filename}.json`)
        showInfoAlert('Information', 'PDF export is not yet available. JSON file generated instead.')
        break
      default:
        downloadJSON(content, `${filename}.json`)
    }

    showSuccessAlert('Success', 'Report generated successfully')
  }

  const downloadJSON = (content: any, filename: string) => {
    const blob = new Blob([JSON.stringify(content, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const downloadCSV = (content: any, filename: string) => {
    // Convert summary data to CSV
    let csv = 'Report Summary\n'
    csv += 'Metric,Value\n'
    
    if (content.summary) {
      Object.entries(content.summary).forEach(([key, value]) => {
        csv += `${key.replace(/_/g, ' ').replace(/\b\w/g, (l: any) => l.toUpperCase())},${value}\n`
      })
    }
    
    csv += '\n'
    
    // Add breakdowns if included
    if (content.breakdowns?.departments) {
      csv += 'Department Breakdown\n'
      csv += 'Department,Books,Lockers,Total\n'
      Object.entries(content.breakdowns.departments).forEach(([dept, counts]: [string, any]) => {
        csv += `${dept},${counts.books},${counts.lockers},${counts.total}\n`
      })
      csv += '\n'
    }

    if (content.breakdowns?.user_types) {
      csv += 'User Type Breakdown\n'
      csv += 'User Type,Books,Lockers,Total\n'
      Object.entries(content.breakdowns.user_types).forEach(([type, counts]: [string, any]) => {
        csv += `${type},${counts.books},${counts.lockers},${counts.total}\n`
      })
      csv += '\n'
    }

    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const scheduleReport = () => {
    // This would integrate with a scheduling system
    showInfoAlert('Information', 'Report scheduling feature is coming soon')
  }

  const emailReport = () => {
    if (!emailRecipient.trim()) {
      showErrorAlert('Error', 'Please enter an email recipient')
      return
    }
    
    // This would integrate with an email service
    showInfoAlert('Information', 'Email report feature is coming soon')
  }

  const printReport = () => {
    // Generate a print-friendly version
    const printWindow = window.open('', '_blank')
    if (!printWindow) return

    const printContent = `
      <html>
        <head>
          <title>Overdue Items Tracking Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 20px; }
            .section { margin-bottom: 20px; }
            .metric { display: flex; justify-content: space-between; padding: 5px 0; }
            table { width: 100%; border-collapse: collapse; margin: 10px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f5f5f5; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>Overdue Items Tracking Report</h1>
            <p>Generated on: ${new Date().toLocaleDateString()}</p>
          </div>
          
          <div class="section">
            <h2>Summary</h2>
            ${Object.entries(data.summary || {}).map(([key, value]) => 
              `<div class="metric">
                <span>${key.replace(/_/g, ' ').replace(/\b\w/g, (l: any) => l.toUpperCase())}:</span>
                <strong>${value}</strong>
              </div>`
            ).join('')}
          </div>

          ${data.breakdowns?.departments ? `
          <div class="section">
            <h2>Department Breakdown</h2>
            <table>
              <tr><th>Department</th><th>Books</th><th>Lockers</th><th>Total</th></tr>
              ${Object.entries(data.breakdowns.departments).map(([dept, counts]: [string, any]) => 
                `<tr><td>${dept}</td><td>${counts.books}</td><td>${counts.lockers}</td><td>${counts.total}</td></tr>`
              ).join('')}
            </table>
          </div>` : ''}
        </body>
      </html>
    `

    printWindow.document.write(printContent)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="h-5 w-5 mr-2" />
          Report Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Report Configuration */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="format">Format</Label>
            <Select value={config.format} onValueChange={(value: any) => setConfig({...config, format: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select format" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="json">JSON</SelectItem>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="pdf">PDF (Coming Soon)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="period">Period</Label>
            <Select value={config.period} onValueChange={(value: any) => setConfig({...config, period: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
                <SelectItem value="custom">Custom Range</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Custom Date Range */}
        {config.period === 'custom' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={config.startDate || ''}
                onChange={(e) => setConfig({...config, startDate: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">End Date</Label>
              <Input
                id="endDate"
                type="date"
                value={config.endDate || ''}
                onChange={(e) => setConfig({...config, endDate: e.target.value})}
              />
            </div>
          </div>
        )}

        {/* Include Options */}
        <div className="space-y-3">
          <Label>Include in Report</Label>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="details"
                checked={config.includeDetails}
                onCheckedChange={(checked) => setConfig({...config, includeDetails: !!checked})}
              />
              <Label htmlFor="details" className="text-sm">Item Details</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="analytics"
                checked={config.includeAnalytics}
                onCheckedChange={(checked) => setConfig({...config, includeAnalytics: !!checked})}
              />
              <Label htmlFor="analytics" className="text-sm">Analytics</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="trends"
                checked={config.includeTrends}
                onCheckedChange={(checked) => setConfig({...config, includeTrends: !!checked})}
              />
              <Label htmlFor="trends" className="text-sm">Trends</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="breakdowns"
                checked={config.includeBreakdowns}
                onCheckedChange={(checked) => setConfig({...config, includeBreakdowns: !!checked})}
              />
              <Label htmlFor="breakdowns" className="text-sm">Breakdowns</Label>
            </div>
          </div>
        </div>

        {/* Email Configuration */}
        <div className="space-y-2">
          <Label htmlFor="emailRecipient">Email Recipient (Optional)</Label>
          <Input
            id="emailRecipient"
            type="email"
            placeholder="recipient@example.com"
            value={emailRecipient}
            onChange={(e) => setEmailRecipient(e.target.value)}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 pt-4 border-t">
          <Button 
            onClick={generateReport} 
            disabled={isGenerating}
            className="flex-1 md:flex-none"
          >
            <Download className="h-4 w-4 mr-2" />
            {isGenerating ? 'Generating...' : 'Generate Report'}
          </Button>
          
          <Button 
            variant="outline" 
            onClick={printReport}
            className="flex-1 md:flex-none"
          >
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          
          <Button 
            variant="outline" 
            onClick={emailReport}
            disabled={!emailRecipient.trim()}
            className="flex-1 md:flex-none"
          >
            <Mail className="h-4 w-4 mr-2" />
            Email
          </Button>
          
          <Button 
            variant="outline" 
            onClick={scheduleReport}
            className="flex-1 md:flex-none"
          >
            <CalendarDays className="h-4 w-4 mr-2" />
            Schedule
          </Button>
        </div>

        {/* Report Preview */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-medium text-gray-800 mb-2">Report Preview</h4>
          <div className="text-sm text-gray-600 space-y-1">
            <p>• Format: {config.format.toUpperCase()}</p>
            <p>• Period: {config.period}</p>
            <p>• Includes: {[
              config.includeDetails && 'Item Details',
              config.includeAnalytics && 'Analytics',
              config.includeTrends && 'Trends',
              config.includeBreakdowns && 'Breakdowns'
            ].filter(Boolean).join(', ') || 'Summary only'}</p>
            {data && (
              <p>• Data Points: {data.overdue_items?.books?.length + data.overdue_items?.lockers?.length || 0} overdue items</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
