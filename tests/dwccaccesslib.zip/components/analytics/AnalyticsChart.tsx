'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface ChartDataPoint {
  label: string
  value: number
  color?: string
  percentage?: number
}

interface AnalyticsChartProps {
  title: string
  data: ChartDataPoint[]
  type: 'bar' | 'donut' | 'severity'
  totalLabel?: string
  className?: string
  showPercentages?: boolean
}

export default function AnalyticsChart({ 
  title, 
  data, 
  type, 
  totalLabel,
  className = '',
  showPercentages = false
}: AnalyticsChartProps) {
  const total = data.reduce((sum, item) => sum + item.value, 0)
  
  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'low': return 'bg-green-100 text-green-800 border-green-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200'
      case 'critical': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getBarColor = (index: number) => {
    const colors = [
      'bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-red-500',
      'bg-purple-500', 'bg-indigo-500', 'bg-pink-500', 'bg-gray-500'
    ]
    return colors[index % colors.length]
  }

  const renderBarChart = () => {
    const maxValue = Math.max(...data.map(d => d.value))
    
    return (
      <div className="space-y-3">
        {data.map((item, index) => {
          const percentage = total > 0 ? (item.value / total * 100) : 0
          const barWidth = maxValue > 0 ? (item.value / maxValue * 100) : 0
          
          return (
            <div key={index} className="space-y-1">
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-gray-700">{item.label}</span>
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{item.value}</span>
                  {showPercentages && (
                    <span className="text-xs text-gray-500">({percentage.toFixed(1)}%)</span>
                  )}
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${getBarColor(index)}`}
                  style={{ width: `${barWidth}%` }}
                />
              </div>
            </div>
          )
        })}
        {totalLabel && (
          <div className="pt-3 mt-3 border-t border-gray-200">
            <div className="flex justify-between items-center font-semibold">
              <span>{totalLabel}</span>
              <span>{total}</span>
            </div>
          </div>
        )}
      </div>
    )
  }

  const renderDonutChart = () => {
    if (total === 0) {
      return (
        <div className="flex items-center justify-center h-32">
          <p className="text-gray-500">No data available</p>
        </div>
      )
    }

    const centerX = 80
    const centerY = 80
    const radius = 60
    const innerRadius = 35
    
    let cumulativePercentage = 0
    
    return (
      <div className="flex items-center justify-between">
        <div className="relative">
          <svg width="160" height="160" className="transform -rotate-90">
            <circle
              cx={centerX}
              cy={centerY}
              r={radius}
              fill="none"
              stroke="#f3f4f6"
              strokeWidth="25"
            />
            {data.map((item, index) => {
              const percentage = (item.value / total) * 100
              const strokeArray = 2 * Math.PI * radius
              const strokeOffset = strokeArray - (strokeArray * percentage) / 100
              const rotation = (cumulativePercentage * 360) / 100
              
              cumulativePercentage += percentage
              
              return (
                <circle
                  key={index}
                  cx={centerX}
                  cy={centerY}
                  r={radius}
                  fill="none"
                  stroke={item.color || getBarColor(index).replace('bg-', '#').replace('-500', '')}
                  strokeWidth="25"
                  strokeDasharray={strokeArray}
                  strokeDashoffset={strokeOffset}
                  transform={`rotate(${rotation} ${centerX} ${centerY})`}
                  className="transition-all duration-300"
                />
              )
            })}
            <text
              x={centerX}
              y={centerY}
              textAnchor="middle"
              dominantBaseline="central"
              className="text-lg font-bold fill-gray-700"
              transform={`rotate(90 ${centerX} ${centerY})`}
            >
              {total}
            </text>
          </svg>
        </div>
        <div className="flex-1 ml-6 space-y-2">
          {data.map((item, index) => {
            const percentage = total > 0 ? (item.value / total * 100) : 0
            return (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div 
                    className={`w-3 h-3 rounded-full mr-2 ${getBarColor(index)}`}
                  />
                  <span className="text-sm text-gray-700">{item.label}</span>
                </div>
                <div className="text-sm font-medium">
                  {item.value} ({percentage.toFixed(1)}%)
                </div>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  const renderSeverityChart = () => {
    return (
      <div className="space-y-3">
        {data.map((item, index) => {
          const percentage = total > 0 ? (item.value / total * 100) : 0
          
          return (
            <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
              <div className="flex items-center gap-3">
                <Badge className={getSeverityColor(item.label)}>
                  {item.label.toUpperCase()}
                </Badge>
                <div className="text-sm text-gray-600">
                  {/* Show severity range descriptions */}
                  {item.label.toLowerCase() === 'low' && type === 'severity' && '≤14 days'}
                  {item.label.toLowerCase() === 'medium' && type === 'severity' && '15-30 days'}
                  {item.label.toLowerCase() === 'high' && type === 'severity' && '31-60 days'}
                  {item.label.toLowerCase() === 'critical' && type === 'severity' && '>60 days'}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-lg">{item.value}</span>
                <span className="text-xs text-gray-500">({percentage.toFixed(1)}%)</span>
              </div>
            </div>
          )
        })}
        {totalLabel && total > 0 && (
          <div className="pt-3 mt-3 border-t border-gray-200">
            <div className="flex justify-between items-center font-semibold text-gray-800">
              <span>{totalLabel}</span>
              <span>{total}</span>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-800">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {type === 'bar' && renderBarChart()}
        {type === 'donut' && renderDonutChart()}
        {type === 'severity' && renderSeverityChart()}
        
        {total === 0 && type !== 'donut' && (
          <div className="flex items-center justify-center h-24">
            <p className="text-gray-500">No data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
