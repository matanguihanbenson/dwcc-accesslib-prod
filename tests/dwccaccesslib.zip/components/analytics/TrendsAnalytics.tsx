'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface TrendDataPoint {
  period: string
  value: number
  change?: number
  changeType?: 'increase' | 'decrease' | 'stable'
}

interface TrendsAnalyticsProps {
  title: string
  data: TrendDataPoint[]
  type: 'line' | 'area' | 'comparison'
  period: 'daily' | 'weekly' | 'monthly'
  metric: string
  className?: string
  showTrendIndicators?: boolean
}

export default function TrendsAnalytics({ 
  title, 
  data, 
  type,
  period,
  metric,
  className = '',
  showTrendIndicators = true
}: TrendsAnalyticsProps) {
  
  const maxValue = Math.max(...data.map(d => d.value))
  const minValue = Math.min(...data.map(d => d.value))
  const range = maxValue - minValue
  
  const getTrendIcon = (changeType: 'increase' | 'decrease' | 'stable' | undefined) => {
    switch (changeType) {
      case 'increase': return <TrendingUp className="h-3 w-3 text-red-500" />
      case 'decrease': return <TrendingDown className="h-3 w-3 text-green-500" />
      case 'stable': return <Minus className="h-3 w-3 text-gray-500" />
      default: return null
    }
  }
  
  const getTrendColor = (changeType: 'increase' | 'decrease' | 'stable' | undefined) => {
    switch (changeType) {
      case 'increase': return 'text-red-600 bg-red-50'
      case 'decrease': return 'text-green-600 bg-green-50'
      case 'stable': return 'text-gray-600 bg-gray-50'
      default: return 'text-gray-600'
    }
  }

  const formatPeriod = (period: string) => {
    // Format period string for display
    const date = new Date(period)
    if (!isNaN(date.getTime())) {
      if (period === 'daily') {
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      } else if (period === 'weekly') {
        return `Week ${Math.ceil(date.getDate() / 7)}`
      } else if (period === 'monthly') {
        return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
      }
    }
    return period
  }

  const renderLineChart = () => {
    if (data.length === 0) {
      return (
        <div className="flex items-center justify-center h-48">
          <p className="text-gray-500">No trend data available</p>
        </div>
      )
    }

    const chartHeight = 120
    const chartWidth = 400
    const padding = 20

    return (
      <div className="space-y-4">
        <div className="relative">
          <svg 
            width="100%" 
            height={chartHeight + padding * 2} 
            className="overflow-visible"
            viewBox={`0 0 ${chartWidth} ${chartHeight + padding * 2}`}
          >
            {/* Grid lines */}
            {[0, 25, 50, 75, 100].map((y) => (
              <line
                key={y}
                x1={padding}
                y1={padding + (chartHeight * y) / 100}
                x2={chartWidth - padding}
                y2={padding + (chartHeight * y) / 100}
                stroke="#f3f4f6"
                strokeWidth="1"
              />
            ))}
            
            {/* Line path */}
            <path
              d={data.map((point, index) => {
                const x = padding + (index * (chartWidth - padding * 2)) / (data.length - 1)
                const normalizedValue = range > 0 ? (point.value - minValue) / range : 0.5
                const y = padding + chartHeight - (normalizedValue * chartHeight)
                return `${index === 0 ? 'M' : 'L'} ${x} ${y}`
              }).join(' ')}
              fill="none"
              stroke="#3b82f6"
              strokeWidth="2"
              className="transition-all duration-300"
            />
            
            {/* Data points */}
            {data.map((point, index) => {
              const x = padding + (index * (chartWidth - padding * 2)) / (data.length - 1)
              const normalizedValue = range > 0 ? (point.value - minValue) / range : 0.5
              const y = padding + chartHeight - (normalizedValue * chartHeight)
              
              return (
                <circle
                  key={index}
                  cx={x}
                  cy={y}
                  r="4"
                  fill="#3b82f6"
                  className="transition-all duration-300 hover:r-6 cursor-pointer"
                />
              )
            })}
          </svg>
        </div>
        
        {/* Legend */}
        <div className="flex flex-wrap justify-between text-xs text-gray-600">
          {data.map((point, index) => (
            <div key={index} className="text-center">
              <div className="font-medium">{point.value}</div>
              <div>{formatPeriod(point.period)}</div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  const renderAreaChart = () => {
    if (data.length === 0) {
      return (
        <div className="flex items-center justify-center h-48">
          <p className="text-gray-500">No trend data available</p>
        </div>
      )
    }

    const chartHeight = 120
    const chartWidth = 400
    const padding = 20

    return (
      <div className="space-y-4">
        <div className="relative">
          <svg 
            width="100%" 
            height={chartHeight + padding * 2} 
            className="overflow-visible"
            viewBox={`0 0 ${chartWidth} ${chartHeight + padding * 2}`}
          >
            <defs>
              <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.1" />
              </linearGradient>
            </defs>
            
            {/* Grid lines */}
            {[0, 25, 50, 75, 100].map((y) => (
              <line
                key={y}
                x1={padding}
                y1={padding + (chartHeight * y) / 100}
                x2={chartWidth - padding}
                y2={padding + (chartHeight * y) / 100}
                stroke="#f3f4f6"
                strokeWidth="1"
              />
            ))}
            
            {/* Area path */}
            <path
              d={
                data.map((point, index) => {
                  const x = padding + (index * (chartWidth - padding * 2)) / (data.length - 1)
                  const normalizedValue = range > 0 ? (point.value - minValue) / range : 0.5
                  const y = padding + chartHeight - (normalizedValue * chartHeight)
                  return `${index === 0 ? 'M' : 'L'} ${x} ${y}`
                }).join(' ') + 
                ` L ${chartWidth - padding} ${padding + chartHeight} L ${padding} ${padding + chartHeight} Z`
              }
              fill="url(#areaGradient)"
              stroke="#3b82f6"
              strokeWidth="2"
              className="transition-all duration-300"
            />
            
            {/* Data points */}
            {data.map((point, index) => {
              const x = padding + (index * (chartWidth - padding * 2)) / (data.length - 1)
              const normalizedValue = range > 0 ? (point.value - minValue) / range : 0.5
              const y = padding + chartHeight - (normalizedValue * chartHeight)
              
              return (
                <circle
                  key={index}
                  cx={x}
                  cy={y}
                  r="3"
                  fill="#3b82f6"
                  stroke="#fff"
                  strokeWidth="2"
                  className="transition-all duration-300 hover:r-5 cursor-pointer"
                />
              )
            })}
          </svg>
        </div>
        
        {/* Legend */}
        <div className="flex flex-wrap justify-between text-xs text-gray-600">
          {data.map((point, index) => (
            <div key={index} className="text-center">
              <div className="font-medium">{point.value}</div>
              <div>{formatPeriod(point.period)}</div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  const renderComparison = () => {
    return (
      <div className="space-y-3">
        {data.map((item, index) => (
          <div key={index} className="flex items-center justify-between p-3 rounded-lg border bg-gray-50/50">
            <div className="flex items-center gap-3">
              <div className="text-sm font-medium text-gray-700">
                {formatPeriod(item.period)}
              </div>
              {showTrendIndicators && item.changeType && (
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${getTrendColor(item.changeType)}`}>
                  {getTrendIcon(item.changeType)}
                  {item.change && <span>{Math.abs(item.change)}%</span>}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-lg">{item.value}</span>
              <span className="text-xs text-gray-500">{metric}</span>
            </div>
          </div>
        ))}
        
        {data.length === 0 && (
          <div className="flex items-center justify-center h-24">
            <p className="text-gray-500">No comparison data available</p>
          </div>
        )}
      </div>
    )
  }

  const getSummaryStats = () => {
    if (data.length === 0) return null
    
    const total = data.reduce((sum, item) => sum + item.value, 0)
    const average = total / data.length
    const trend = data.length > 1 ? 
      (data[data.length - 1].value > data[0].value ? 'increasing' : 
       data[data.length - 1].value < data[0].value ? 'decreasing' : 'stable') : 'stable'
    
    return { total, average: Math.round(average), trend }
  }

  const stats = getSummaryStats()

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold text-gray-800">{title}</CardTitle>
          {stats && (
            <div className="flex items-center gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">{stats.total}</div>
                <div className="text-gray-500">Total</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">{stats.average}</div>
                <div className="text-gray-500">Avg</div>
              </div>
              <Badge variant={stats.trend === 'increasing' ? 'destructive' : 
                              stats.trend === 'decreasing' ? 'default' : 'secondary'}>
                {stats.trend}
              </Badge>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {type === 'line' && renderLineChart()}
        {type === 'area' && renderAreaChart()}
        {type === 'comparison' && renderComparison()}
      </CardContent>
    </Card>
  )
}
