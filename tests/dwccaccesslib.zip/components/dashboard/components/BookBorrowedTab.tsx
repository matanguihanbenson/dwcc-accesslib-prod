'use client'

import React from 'react'
import { BarChart } from '@/components/charts'
import { transformBookDataForChart } from '@/services/chartService'

interface BookBorrowedData {
  borrowedToday: number
  borrowedThisWeek: number
  borrowedThisMonth: number
  popularBook: string
  averageBorrowDuration: string
  returnRate: number
}

interface BookBorrowedTabProps {
  bookBorrowedData: BookBorrowedData
}

function BookBorrowedTab({ bookBorrowedData }: BookBorrowedTabProps): React.ReactElement {
  const chartData = transformBookDataForChart({
    borrowedToday: bookBorrowedData.borrowedToday,
    borrowedThisWeek: bookBorrowedData.borrowedThisWeek,
    borrowedThisMonth: bookBorrowedData.borrowedThisMonth
  })

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-800">Book Borrowing Analytics</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-600">Today</p>
              <p className="text-2xl font-bold text-green-800">{bookBorrowedData.borrowedToday}</p>
            </div>
            <i className="fas fa-book text-green-500 text-xl"></i>
          </div>
        </div>

        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-blue-600">This Week</p>
              <p className="text-2xl font-bold text-blue-800">{bookBorrowedData.borrowedThisWeek}</p>
            </div>
            <i className="fas fa-calendar-week text-blue-500 text-xl"></i>
          </div>
        </div>

        <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-600">This Month</p>
              <p className="text-2xl font-bold text-purple-800">{bookBorrowedData.borrowedThisMonth}</p>
            </div>
            <i className="fas fa-calendar-alt text-purple-500 text-xl"></i>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
          <h4 className="text-sm font-semibold text-gray-800 mb-2">Borrowing Statistics</h4>
          <div className="space-y-2">
            <p className="text-gray-600">
              <span className="font-medium">Most Popular Book:</span> {bookBorrowedData.popularBook}
            </p>
            <p className="text-gray-600">
              <span className="font-medium">Average Duration:</span> {bookBorrowedData.averageBorrowDuration}
            </p>
            <p className="text-gray-600">
              <span className="font-medium">Return Rate:</span> {bookBorrowedData.returnRate}%
            </p>
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <h4 className="text-sm font-semibold text-gray-800 mb-4">Borrowing Trends</h4>
          <div className="h-64">
            <BarChart
              data={chartData}
              bars={[
                { dataKey: 'value', fill: '#10B981', name: 'Books Borrowed' }
              ]}
              height={220}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default BookBorrowedTab
