'use client'

import React, { useState } from 'react'
import UserEntryTab from './components/UserEntryTab'
import LockerUsageTab from './components/LockerUsageTab'
import BookBorrowedTab from './components/BookBorrowedTab'
import OverduesTab from './components/OverduesTab'

interface AdminViewProps {
  className?: string
}

type UserEntryData = {
  totalToday: number
  totalThisWeek: number
  totalThisMonth: number
  uniqueUsersToday: number
  uniqueUsersWeek: number
  uniqueUsersMonth: number
  peakHour: string
  trend: 'up' | 'down' | 'stable'
}

type LockerUsageData = {
  totalLockers: number
  occupiedLockers: number
  availableLockers: number
  averageUsageTime: string
  mostUsedLocker: string
  utilizationRate: number
}

type BookBorrowedData = {
  borrowedToday: number
  borrowedThisWeek: number
  borrowedThisMonth: number
  popularBook: string
  averageBorrowDuration: string
  returnRate: number
}

type OverdueData = {
  totalOverdue: number
  overdueBooks: number
  overdueLockers: number
  totalFines: number
  oldestOverdue: string
  averageOverdueDays: number
}

type ChartData = {
  day: Array<{ name: string; entries: number; unique: number }>
  week: Array<{ name: string; entries: number; unique: number }>
  month: Array<{ name: string; entries: number; unique: number }>
  year: Array<{ name: string; entries: number; unique: number }>
}

function AdminView({ className }: AdminViewProps): React.ReactElement {
  const [activeTab, setActiveTab] = useState<'userEntry' | 'lockerUsage' | 'bookBorrowed' | 'overdues'>('userEntry')

  const [userEntryData] = useState<UserEntryData>({
    totalToday: 127,
    totalThisWeek: 892,
    totalThisMonth: 3456,
    uniqueUsersToday: 89,
    uniqueUsersWeek: 456,
    uniqueUsersMonth: 1234,
    peakHour: '2:00 PM - 3:00 PM',
    trend: 'up'
  })

  const [lockerUsageData] = useState<LockerUsageData>({
    totalLockers: 50,
    occupiedLockers: 38,
    availableLockers: 12,
    averageUsageTime: '2.5 hours',
    mostUsedLocker: 'L-15',
    utilizationRate: 76
  })

  const [bookBorrowedData] = useState<BookBorrowedData>({
    borrowedToday: 45,
    borrowedThisWeek: 312,
    borrowedThisMonth: 1289,
    popularBook: 'Introduction to Programming',
    averageBorrowDuration: '7 days',
    returnRate: 94.5
  })

  const [overdueData] = useState<OverdueData>({
    totalOverdue: 23,
    overdueBooks: 18,
    overdueLockers: 5,
    totalFines: 1450,
    oldestOverdue: '15 days',
    averageOverdueDays: 8
  })

  const [chartData] = useState<ChartData>({
    day: [
      { name: '6AM', entries: 12, unique: 8 },
      { name: '8AM', entries: 45, unique: 32 },
      { name: '10AM', entries: 67, unique: 48 },
      { name: '12PM', entries: 89, unique: 65 },
      { name: '2PM', entries: 123, unique: 89 },
      { name: '4PM', entries: 78, unique: 56 },
      { name: '6PM', entries: 34, unique: 25 },
      { name: '8PM', entries: 15, unique: 12 }
    ],
    week: [
      { name: 'Mon', entries: 145, unique: 98 },
      { name: 'Tue', entries: 167, unique: 112 },
      { name: 'Wed', entries: 189, unique: 134 },
      { name: 'Thu', entries: 201, unique: 145 },
      { name: 'Fri', entries: 223, unique: 167 },
      { name: 'Sat', entries: 156, unique: 89 },
      { name: 'Sun', entries: 89, unique: 67 }
    ],
    month: [
      { name: 'Week 1', entries: 892, unique: 456 },
      { name: 'Week 2', entries: 1045, unique: 523 },
      { name: 'Week 3', entries: 967, unique: 487 },
      { name: 'Week 4', entries: 1134, unique: 567 }
    ],
    year: [
      { name: 'Jan', entries: 3456, unique: 1234 },
      { name: 'Feb', entries: 3789, unique: 1345 },
      { name: 'Mar', entries: 4123, unique: 1456 },
      { name: 'Apr', entries: 3897, unique: 1298 },
      { name: 'May', entries: 4234, unique: 1567 },
      { name: 'Jun', entries: 4567, unique: 1678 },
      { name: 'Jul', entries: 4123, unique: 1456 },
      { name: 'Aug', entries: 3945, unique: 1398 },
      { name: 'Sep', entries: 4267, unique: 1523 },
      { name: 'Oct', entries: 4089, unique: 1445 },
      { name: 'Nov', entries: 3756, unique: 1334 },
      { name: 'Dec', entries: 3234, unique: 1156 }
    ]
  })

  return (
    <div className={`p-4 space-y-4 ${className || ''}`}>
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-gray-800">Library Overview Reports</h2>
        <div className="text-xs text-gray-500">
          Last updated: {new Date().toLocaleString()}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-400 p-4">
        <h3 className="text-sm font-semibold text-gray-800 mb-3">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-xs font-medium transition-colors flex items-center gap-1">
            <i className="fas fa-chart-bar text-xs"></i>
            View Reports
          </button>
          <button className="bg-teal-600 hover:bg-teal-700 text-white px-3 py-2 rounded text-xs font-medium transition-colors flex items-center gap-1">
            <i className="fas fa-user-tie text-xs"></i>
            Manage Staff
          </button>
          <button className="bg-orange-600 hover:bg-orange-700 text-white px-3 py-2 rounded text-xs font-medium transition-colors flex items-center gap-1">
            <i className="fas fa-archive text-xs"></i>
            Manage Lockers
          </button>
          <button className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded text-xs font-medium transition-colors flex items-center gap-1">
            <i className="fas fa-book text-xs"></i>
            Book Management
          </button>
          <button className="bg-red-600 hover:bg-red-700 text-white px-3 py-2 rounded text-xs font-medium transition-colors flex items-center gap-1">
            <i className="fas fa-exclamation-triangle text-xs"></i>
            Handle Overdues
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-6 px-4" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('userEntry')}
              className={`py-3 px-1 border-b-2 font-medium text-xs ${
                activeTab === 'userEntry'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fas fa-users mr-1 text-xs"></i>
              User Entry
            </button>
            <button
              onClick={() => setActiveTab('lockerUsage')}
              className={`py-3 px-1 border-b-2 font-medium text-xs ${
                activeTab === 'lockerUsage'
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fas fa-archive mr-1 text-xs"></i>
              Locker Usage
            </button>
            <button
              onClick={() => setActiveTab('bookBorrowed')}
              className={`py-3 px-1 border-b-2 font-medium text-xs ${
                activeTab === 'bookBorrowed'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fas fa-book mr-1 text-xs"></i>
              Book Borrowed
            </button>
            <button
              onClick={() => setActiveTab('overdues')}
              className={`py-3 px-1 border-b-2 font-medium text-xs ${
                activeTab === 'overdues'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fas fa-exclamation-triangle mr-1 text-xs"></i>
              Overdues
            </button>
          </nav>
        </div>

        <div className="p-4">
          {activeTab === 'userEntry' && (
            <UserEntryTab userEntryData={userEntryData} chartData={chartData} />
          )}

          {activeTab === 'lockerUsage' && (
            <LockerUsageTab lockerUsageData={lockerUsageData} />
          )}

          {activeTab === 'bookBorrowed' && (
            <BookBorrowedTab bookBorrowedData={bookBorrowedData} />
          )}

          {activeTab === 'overdues' && (
            <OverduesTab overdueData={overdueData} />
          )}
        </div>
      </div>
    </div>
  )
}

export default AdminView
