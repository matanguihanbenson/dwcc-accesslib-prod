"use client"

import { usePathname } from "next/navigation"
import { useState, useEffect, useCallback, useMemo } from "react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import SidebarClient from "./SidebarClient"
import { NavigationItem, UserInfo, UserRole } from "@/types"
import { authService } from "@/lib/services/auth.service"
import { userStatusChecker } from "@/lib/user-status-checker"
import logger from "@/lib/logger"

const hiddenRoutes = ["/", "/login", "/browse"]

// Navigation items with role-based access
const navigationItems: NavigationItem[] = [
  {
    name: "Dashboard",
    href: "/dashboard", 
    icon: "fas fa-chart-pie",
    roles: ["SUPER_ADMIN", "ADMIN", "STAFF"] as const,
  },
  {
    name: "Admin Accounts",
    href: "/admin-accounts",
    icon: "fas fa-user-shield", 
    roles: ["SUPER_ADMIN"] as const,
  },
  {
    name: "Staff Accounts",
    href: "/staff-accounts",
    icon: "fas fa-users-cog",
    roles: ["ADMIN"] as const,
  },
  {
    name: "Library Users",
    href: "/library-users",
    icon: "fas fa-users",
    roles: ["SUPER_ADMIN"] as const,
  },

  {
    name: "Activity Logs",
    href: "/activity-logs",
    icon: "fas fa-history",
    roles: ["SUPER_ADMIN"] as const,
  },
  {
    name: "Entry Monitoring",
    href: "/entry-monitoring", 
    icon: "fas fa-door-open",
    roles: ["ADMIN", "STAFF"] as const,
  },
  {
    name: "Books",
    href: "/books",
    icon: "fas fa-book", 
    roles: ["ADMIN", "STAFF"] as const,
  },
  {
    name: "Lockers",
    href: "/lockers",
    icon: "fas fa-lock",
    roles: ["ADMIN", "STAFF"] as const,
  },
  {
    name: "Overdue Tracking",
    href: "/admin/overdue-tracking",
    icon: "fas fa-chart-bar",
    roles: ["ADMIN", "SUPER_ADMIN"] as const,
  },
  {
    name: "Overdue Management",
    href: "/overdue",
    icon: "fas fa-exclamation-triangle",
    roles: ["STAFF"] as const,
  },
  {
    name: "Reports",
    href: "/reports",
    icon: "fas fa-chart-line",
    roles: ["ADMIN"] as const,
  },
  {
    name: "Email Notifications",
    href: "/notifications",
    icon: "fas fa-envelope",
    roles: ["ADMIN"] as const,
  },
  {
    name: "Settings", 
    href: "/settings",
    icon: "fas fa-cog",
    roles: ["SUPER_ADMIN", "ADMIN"] as const,
  },
]

interface UserSession {
  user: {
    name: string
    role: UserRole
    username: string
  }
}

export function ConditionalSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { data: session, status } = useSession()
  const [userSession, setUserSession] = useState<UserSession | null>(null)
  const [loading, setLoading] = useState(true)
  const [isCollapsed, setIsCollapsed] = useState(false)

  // Don't show sidebar on hidden routes
  const shouldShowSidebar = useMemo(() => {
    return !hiddenRoutes.includes(pathname)
  }, [pathname])

  const processSession = useCallback(async () => {
    if (status === 'loading') {
      setLoading(true)
      return
    }

    setLoading(true)

    try {
      // If we have a NextAuth session, use it directly
      if (status === 'authenticated' && session?.user?.username) {
        logger.debug('Using NextAuth session for sidebar')
        
        setUserSession({
          user: {
            name: session.user.name || 'Unknown',
            role: session.user.role as UserRole,
            username: session.user.username
          }
        })
        setLoading(false)
        return
      }

      // If no NextAuth session, try JWT token authentication
      if (status === 'unauthenticated' || !session) {
        logger.debug('Attempting JWT token authentication for sidebar')
        
        const result = await authService.getUserProfile()
        
        if (result.success && result.data) {
          setUserSession({
            user: {
              name: result.data.name,
              role: result.data.role,
              username: result.data.username || result.data.id
            }
          })
        } else {
          logger.warn('Failed to authenticate user for sidebar')
          router.push('/login')
          return
        }
      }
    } catch (error) {
      logger.error('Error processing session for sidebar', error instanceof Error ? error : new Error(String(error)))
      router.push('/login')
    } finally {
      setLoading(false)
    }
  }, [status, session?.user?.username, router])

  useEffect(() => {
    if (shouldShowSidebar) {
      processSession()
    }
  }, [shouldShowSidebar, processSession])

  // Start user status monitoring when user is authenticated
  useEffect(() => {
    if (userSession?.user) {
      // Start monitoring user status
      userStatusChecker.startChecking(30000) // Check every 30 seconds
      
      return () => {
        // Stop monitoring when component unmounts or user changes
        userStatusChecker.stopChecking()
      }
    } else {
      // Stop monitoring if no user session
      userStatusChecker.stopChecking()
    }
  }, [userSession])

  // Manage main content margin based on sidebar state
  useEffect(() => {
    const mainContent = document.getElementById('main-content')
    if (mainContent) {
      if (!shouldShowSidebar) {
        mainContent.style.marginLeft = '0px'
      } else if (userSession?.user) {
        // Only apply margin if user is authenticated and sidebar should be shown
        mainContent.style.marginLeft = isCollapsed ? '48px' : '224px'
      }
    }
  }, [shouldShowSidebar, isCollapsed, userSession])

  // Set initial margin when component mounts and user is authenticated
  useEffect(() => {
    const mainContent = document.getElementById('main-content')
    if (mainContent && shouldShowSidebar && userSession?.user) {
      mainContent.style.marginLeft = isCollapsed ? '48px' : '224px'
    }
  }, [userSession, shouldShowSidebar, isCollapsed])

  if (!shouldShowSidebar) {
    return null
  }

  // Show loading during initial authentication check
  if (loading) {
    return (
      <div className="w-56 fixed left-0 top-0 h-full bg-green-800 flex items-center justify-center z-40 shadow-lg">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-2"></div>
          <div className="text-sm">Loading...</div>
        </div>
      </div>
    )
  }

  // If no user session, don't render anything (redirect will happen)
  if (!userSession?.user) {
    return null
  }

  const currentUserRole = userSession.user.role
  const allowedNavigationItems = navigationItems.filter((item) => 
    item.roles.includes(currentUserRole)
  )

  const userInfo: UserInfo = {
    name: userSession.user.name || "Unknown User",
    role: currentUserRole,
    initials: userSession.user.name 
      ? userSession.user.name.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2)
      : "??"
  }

  return (
    <SidebarClient 
      allowedNavigationItems={allowedNavigationItems}
      userInfo={userInfo}
      isCollapsed={isCollapsed}
      onToggleCollapse={() => setIsCollapsed(!isCollapsed)}
    />
  )
}
