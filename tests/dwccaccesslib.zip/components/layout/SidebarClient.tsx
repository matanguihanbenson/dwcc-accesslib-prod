"use client"

import { usePathname } from "next/navigation"
import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { signOut } from "next-auth/react"
import Link from "next/link"
import { UserRole } from "@/types"

type NavigationItem = {
	readonly name: string
	readonly href: string
	readonly icon: string
	readonly roles: readonly UserRole[]
}

type UserInfo = {
	name: string
	role: string
	initials: string
}

interface SidebarClientProps {
	allowedNavigationItems: readonly NavigationItem[]
	userInfo: UserInfo
	isCollapsed: boolean
	onToggleCollapse: () => void
}

export default function SidebarClient({ allowedNavigationItems, userInfo, isCollapsed, onToggleCollapse }: SidebarClientProps) {
	const pathname = usePathname()
	const router = useRouter()
	const [showProfileDropdown, setShowProfileDropdown] = useState(false)
	const dropdownRef = useRef<HTMLDivElement>(null)

	// Close dropdown when clicking outside
	useEffect(() => {
		const handleClickOutside = (event: MouseEvent) => {
			if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
				setShowProfileDropdown(false)
			}
		}

		document.addEventListener('mousedown', handleClickOutside)
		return () => {
			document.removeEventListener('mousedown', handleClickOutside)
		}
	}, [])

	// Close dropdown when sidebar collapses
	useEffect(() => {
		if (isCollapsed) {
			setShowProfileDropdown(false)
		}
	}, [isCollapsed])

	const handleLogout = async () => {
		try {
			// Try NextAuth signOut first
			await signOut({ redirect: false })
			
			// Also clear any JWT tokens
			document.cookie = 'token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;'
			
			// Redirect to login
			router.push('/login')
		} catch (error) {
			console.error('Logout error:', error)
			// Force redirect even if logout fails
			router.push('/login')
		}
	}

		return (
		<div
			className={`bg-green-800 text-white transition-all duration-300 ${
				isCollapsed ? "w-12" : "w-56"
			} fixed left-0 top-0 h-full flex flex-col z-40 shadow-lg`}
		>
			{/* Header */}
			<div className="p-3 border-b border-green-700">
				<div className="flex items-center justify-between">
					{!isCollapsed && (
						<div className="flex items-center gap-2">
							<h2 className="text-lg font-semibold text-white">
								DWCC AccessLib
							</h2>
						</div>
					)}
					<button
						onClick={onToggleCollapse}
						className="p-1.5 rounded-md hover:bg-green-700 transition-colors"
					>
						<i
							className={`fas ${
								isCollapsed
									? "fa-chevron-right"
									: "fa-chevron-left"
							} text-sm`}
						></i>
					</button>
				</div>
			</div>

			{/* Navigation */}
			<nav className="flex-1 p-2">
				<ul className="space-y-1">
					{allowedNavigationItems.map((item) => {
						const isActive = pathname === item.href
						return (
							<li key={item.href}>
								<Link
									href={item.href}
									className={`flex items-center rounded-md transition-colors ${
										isCollapsed
											? "w-full justify-center py-2 px-1"
											: "px-3 py-2"
									} ${
								isActive
											? "bg-green-600 text-white"
											: "text-gray-300 hover:bg-green-700 hover:text-white"
									}`}
								>
									<i
										className={`${
											item.icon
										} ${
											isCollapsed ? "text-base" : "text-sm"
										}`}
									></i>
									{!isCollapsed && (
										<span className="ml-3 text-sm font-medium">
											{item.name}
										</span>
									)}
								</Link>
							</li>
						)
					})}
				</ul>
			</nav>

			{/* Profile Section */}
			<div className="p-3 border-t border-green-700 relative" ref={dropdownRef}>
				{isCollapsed ? (
					<div className="flex justify-center">
						<button
							onClick={() => setShowProfileDropdown(!showProfileDropdown)}
							className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-sm font-semibold hover:bg-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 focus:ring-offset-green-800"
						>
							{userInfo.initials}
						</button>
					</div>
				) : (
					<button
						onClick={() => setShowProfileDropdown(!showProfileDropdown)}
						className="w-full flex items-center space-x-3 p-2 rounded-md hover:bg-green-900 transition-colors focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 focus:ring-offset-green-800"
					>
						<div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-sm font-semibold">
							{userInfo.initials}
						</div>
						<div className="flex-1 min-w-0 text-left">
							<p className="text-sm font-medium text-white truncate">
								{userInfo.name}
							</p>
							<p className="text-xs text-gray-400 truncate">
								{userInfo.role}
							</p>
						</div>
						<i className={`fas fa-chevron-up text-xs text-gray-400 transition-transform duration-200 ${showProfileDropdown ? 'rotate-180' : ''}`}></i>
					</button>
				)}

				{/* Profile Dropdown */}
				{showProfileDropdown && (
					<div 
						className={`absolute bottom-full mb-2 bg-white rounded-md shadow-lg border border-gray-200 min-w-48 z-50 ${
							isCollapsed ? 'left-full ml-2' : 'left-0 right-0'
						}`}
					>
						<div className="py-1">
							<Link
								href="/profile"
								className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
								onClick={() => setShowProfileDropdown(false)}
							>
								<i className="fas fa-user text-gray-500 mr-3 w-4"></i>
								View Profile
							</Link>
							<Link
								href="/change-password"
								className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
								onClick={() => setShowProfileDropdown(false)}
							>
								<i className="fas fa-key text-gray-500 mr-3 w-4"></i>
								Change Password
							</Link>
							<hr className="my-1 border-gray-200" />
							<button
								onClick={() => {
									setShowProfileDropdown(false)
									handleLogout()
								}}
								className="w-full flex items-center px-4 py-2 text-sm text-red-700 hover:bg-red-50 transition-colors"
							>
								<i className="fas fa-sign-out-alt text-red-500 mr-3 w-4"></i>
								Logout
							</button>
						</div>
					</div>
				)}
			</div>

			{/* Footer */}
			<div className="p-3 border-t border-green-700">
			{!isCollapsed && (
					<div className="text-xs text-gray-400">
						© 2025 DWCC AccessLib
					</div>
				)}
			</div>
		</div>
	)
}
