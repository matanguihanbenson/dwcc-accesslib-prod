import * as React from "react"

type BadgeVariant = "default" | "secondary" | "destructive" | "outline"

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: BadgeVariant
}

const getBadgeClasses = (variant: BadgeVariant = "default", className?: string) => {
  const baseClasses = "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
  
  const variantClasses = {
    default: "bg-blue-500 text-white hover:bg-blue-600",
    secondary: "bg-gray-100 text-gray-900 hover:bg-gray-200",
    destructive: "bg-red-500 text-white hover:bg-red-600",
    outline: "border border-gray-200 text-gray-900 hover:bg-gray-100"
  }
  
  return `${baseClasses} ${variantClasses[variant]} ${className || ''}`
}

function Badge({ className, variant = "default", ...props }: BadgeProps) {
  return (
    <div
      className={getBadgeClasses(variant, className)}
      {...props}
    />
  )
}

export { Badge, type BadgeProps }
