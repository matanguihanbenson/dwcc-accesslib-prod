'use client'

import React, { useState } from 'react'
import {
  showConfirmDialog,
  showSuccessAlert,
  showErrorAlert
} from '@/app/utils/sweetalerts'

interface OverdueBook {
  transaction_id: number
  borrow_date: string
  due_date: string
  penalty: number
  days_overdue: number
  calculated_penalty: number
  book: {
    title: string
    book_author: string
    category: string
  }
  user: {
    full_name: string
    email: string
    user_type: string
    course?: string
    department?: string
    contact_number?: string
    account_id: string
  }
}

interface OverdueBooksTableProps {
  books: OverdueBook[]
  onRefresh: () => void
}

export default function OverdueBooksTable({ books, onRefresh }: OverdueBooksTableProps) {
  const [processingId, setProcessingId] = useState<number | null>(null)

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const getSeverityColor = (daysOverdue: number) => {
    if (daysOverdue > 60) return 'text-red-700 bg-red-100'
    if (daysOverdue > 30) return 'text-red-600 bg-red-50'
    if (daysOverdue > 14) return 'text-orange-600 bg-orange-50'
    return 'text-yellow-600 bg-yellow-50'
  }

  const getUserTypeBadge = (userType: string) => {
    const colors = {
      STUDENT: 'bg-blue-100 text-blue-800',
      EMPLOYEE: 'bg-green-100 text-green-800',
      ALUMNI: 'bg-purple-100 text-purple-800',
      GUEST: 'bg-gray-100 text-gray-800'
    }
    return colors[userType as keyof typeof colors] || colors.GUEST
  }

  const handleProcessReturn = async (transactionId: number, bookTitle: string, userName: string) => {
    const confirmed = await showConfirmDialog(
      'Process Book Return',
      `Mark "${bookTitle}" as returned by ${userName}? This will calculate and apply any applicable penalties.`,
      'Yes, Process Return'
    )

    if (confirmed) {
      try {
        setProcessingId(transactionId)
        const response = await fetch(`/api/borrowing-transactions/${transactionId}/return`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include'
        })

        if (response.ok) {
          const result = await response.json()
          showSuccessAlert(
            'Return Processed',
            `Book return processed successfully. ${result.penalty_applied ? `Penalty: ₱${result.transaction.penalty}` : 'No penalty applied.'}`
          )
          onRefresh()
        } else {
          const error = await response.json()
          showErrorAlert('Error', error.message || 'Failed to process return')
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
      } finally {
        setProcessingId(null)
      }
    }
  }

  const handleSendReminder = async (transactionId: number, email: string, userName: string, bookTitle: string) => {
    const confirmed = await showConfirmDialog(
      'Send Reminder',
      `Send overdue reminder email to ${userName} (${email}) about "${bookTitle}"?`,
      'Yes, Send Reminder'
    )

    if (confirmed) {
      try {
        // For now, just show success - in a real app, you'd implement email sending
        showSuccessAlert('Reminder Sent', `Overdue reminder sent to ${email}`)
      } catch (error) {
        showErrorAlert('Error', 'Failed to send reminder')
      }
    }
  }

  if (books.length === 0) {
    return (
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="p-8 text-center">
          <div className="text-gray-500 mb-2">
            <i className="fas fa-book text-4xl mb-4"></i>
          </div>
          <div className="text-gray-600">No overdue books found</div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Book & User
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Dates
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Days Overdue
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Penalty
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Contact
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {books.map((book) => (
              <tr key={book.transaction_id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="space-y-2">
                    <div>
                      <div className="text-sm font-medium text-gray-900 truncate max-w-xs" title={book.book.title}>
                        {book.book.title}
                      </div>
                      <div className="text-sm text-gray-500">by {book.book.book_author}</div>
                      <div className="text-xs text-gray-400">{book.book.category}</div>
                    </div>
                    <div className="border-t pt-2">
                      <div className="text-sm font-medium text-gray-900">{book.user.full_name}</div>
                      <div className="text-sm text-gray-500">{book.user.account_id}</div>
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getUserTypeBadge(book.user.user_type)}`}>
                        {book.user.user_type}
                      </span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    <div><strong>Borrowed:</strong> {formatDate(book.borrow_date)}</div>
                    <div className="text-red-600"><strong>Due:</strong> {formatDate(book.due_date)}</div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getSeverityColor(book.days_overdue)}`}>
                    {book.days_overdue} days
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm">
                    <div className="font-semibold text-red-600">₱{book.calculated_penalty.toFixed(2)}</div>
                    {book.penalty !== book.calculated_penalty && (
                      <div className="text-xs text-gray-500">
                        (Current: ₱{Number(book.penalty).toFixed(2)})
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {book.user.email && (
                      <div className="truncate max-w-xs" title={book.user.email}>
                        <i className="fas fa-envelope mr-1"></i>
                        {book.user.email}
                      </div>
                    )}
                    {book.user.contact_number && (
                      <div>
                        <i className="fas fa-phone mr-1"></i>
                        {book.user.contact_number}
                      </div>
                    )}
                    {(book.user.course || book.user.department) && (
                      <div className="text-xs text-gray-500 mt-1">
                        {book.user.course || book.user.department}
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleProcessReturn(
                        book.transaction_id,
                        book.book.title,
                        book.user.full_name
                      )}
                      disabled={processingId === book.transaction_id}
                      className="text-green-600 hover:text-green-900 px-2 py-1 text-sm border border-green-600 hover:bg-green-50 rounded transition-colors disabled:opacity-50"
                      title="Process Return"
                    >
                      {processingId === book.transaction_id ? (
                        <i className="fas fa-spinner fa-spin"></i>
                      ) : (
                        <i className="fas fa-check"></i>
                      )}
                    </button>
                    
                    {book.user.email && (
                      <button
                        onClick={() => handleSendReminder(
                          book.transaction_id,
                          book.user.email!,
                          book.user.full_name,
                          book.book.title
                        )}
                        className="text-blue-600 hover:text-blue-900 px-2 py-1 text-sm border border-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Send Reminder Email"
                      >
                        <i className="fas fa-envelope"></i>
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {books.length > 0 && (
        <div className="bg-gray-50 px-6 py-3 text-sm text-gray-600 border-t">
          Showing {books.length} overdue book{books.length !== 1 ? 's' : ''}
        </div>
      )}
    </div>
  )
}
