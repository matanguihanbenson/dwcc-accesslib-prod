'use client'

import React, { useState } from 'react'
import {
  showConfirmDialog,
  showSuccessAlert,
  showErrorAlert
} from '@/app/utils/sweetalerts'

interface OverdueLocker {
  transaction_id: number
  borrow_time: string
  penalty: number
  hours_used: number
  days_used: number
  calculated_penalty: number
  locker: {
    locker_number: string
    status: string
  }
  user: {
    full_name: string
    email: string
    user_type: string
    course?: string
    department?: string
    contact_number?: string
    account_id: string
  }
}

interface OverdueLockerTableProps {
  lockers: OverdueLocker[]
  onRefresh: () => void
}

export default function OverdueLockerTable({ lockers, onRefresh }: OverdueLockerTableProps) {
  const [processingId, setProcessingId] = useState<number | null>(null)

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formatDuration = (hours: number) => {
    if (hours < 24) {
      return `${hours} hours`
    }
    const days = Math.floor(hours / 24)
    const remainingHours = hours % 24
    return `${days}d ${remainingHours}h`
  }

  const getSeverityColor = (daysUsed: number) => {
    if (daysUsed > 14) return 'text-red-700 bg-red-100'
    if (daysUsed > 7) return 'text-red-600 bg-red-50'
    if (daysUsed > 3) return 'text-orange-600 bg-orange-50'
    return 'text-yellow-600 bg-yellow-50'
  }

  const getUserTypeBadge = (userType: string) => {
    const colors = {
      STUDENT: 'bg-blue-100 text-blue-800',
      EMPLOYEE: 'bg-green-100 text-green-800',
      ALUMNI: 'bg-purple-100 text-purple-800',
      GUEST: 'bg-gray-100 text-gray-800'
    }
    return colors[userType as keyof typeof colors] || colors.GUEST
  }

  const getLockerStatusBadge = (status: string) => {
    const colors = {
      AVAILABLE: 'bg-green-100 text-green-800',
      OCCUPIED: 'bg-yellow-100 text-yellow-800',
      DAMAGED: 'bg-red-100 text-red-800',
      MAINTENANCE: 'bg-gray-100 text-gray-800'
    }
    return colors[status as keyof typeof colors] || colors.OCCUPIED
  }

  const handleProcessReturn = async (transactionId: number, lockerNumber: string, userName: string) => {
    const confirmed = await showConfirmDialog(
      'Process Locker Return',
      `Mark locker ${lockerNumber} as returned by ${userName}? This will calculate and apply any applicable penalties.`,
      'Yes, Process Return'
    )

    if (confirmed) {
      try {
        setProcessingId(transactionId)
        // Note: You'll need to create this endpoint for locker returns
        const response = await fetch(`/api/locker-transactions/${transactionId}/return`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include'
        })

        if (response.ok) {
          const result = await response.json()
          showSuccessAlert(
            'Return Processed',
            `Locker return processed successfully. ${result.penalty_applied ? `Penalty: ₱${result.transaction.penalty}` : 'No penalty applied.'}`
          )
          onRefresh()
        } else {
          const error = await response.json()
          showErrorAlert('Error', error.message || 'Failed to process return')
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
      } finally {
        setProcessingId(null)
      }
    }
  }

  const handleSendReminder = async (transactionId: number, email: string, userName: string, lockerNumber: string) => {
    const confirmed = await showConfirmDialog(
      'Send Reminder',
      `Send overdue reminder email to ${userName} (${email}) about locker ${lockerNumber}?`,
      'Yes, Send Reminder'
    )

    if (confirmed) {
      try {
        // For now, just show success - in a real app, you'd implement email sending
        showSuccessAlert('Reminder Sent', `Overdue reminder sent to ${email}`)
      } catch (error) {
        showErrorAlert('Error', 'Failed to send reminder')
      }
    }
  }

  const handleForceReturn = async (transactionId: number, lockerNumber: string, userName: string) => {
    const confirmed = await showConfirmDialog(
      'Force Locker Return',
      `Force return locker ${lockerNumber} from ${userName}? This will immediately free the locker and apply maximum penalty.`,
      'Yes, Force Return'
    )

    if (confirmed) {
      try {
        setProcessingId(transactionId)
        // Note: You'll need to create this endpoint
        const response = await fetch(`/api/locker-transactions/${transactionId}/force-return`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include'
        })

        if (response.ok) {
          const result = await response.json()
          showSuccessAlert('Force Return Processed', `Locker ${lockerNumber} has been forcibly returned. Penalty: ₱${result.transaction.penalty}`)
          onRefresh()
        } else {
          const error = await response.json()
          showErrorAlert('Error', error.message || 'Failed to process force return')
        }
      } catch (error) {
        showErrorAlert('Error', 'Network error occurred')
      } finally {
        setProcessingId(null)
      }
    }
  }

  if (lockers.length === 0) {
    return (
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <div className="p-8 text-center">
          <div className="text-gray-500 mb-2">
            <i className="fas fa-lock text-4xl mb-4"></i>
          </div>
          <div className="text-gray-600">No overdue lockers found</div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Locker & User
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Usage Time
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Duration
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Penalty
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Contact
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {lockers.map((locker) => (
              <tr key={locker.transaction_id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="space-y-2">
                    <div>
                      <div className="text-sm font-medium text-gray-900 flex items-center">
                        <i className="fas fa-lock mr-2"></i>
                        Locker {locker.locker.locker_number}
                      </div>
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getLockerStatusBadge(locker.locker.status)}`}>
                        {locker.locker.status}
                      </span>
                    </div>
                    <div className="border-t pt-2">
                      <div className="text-sm font-medium text-gray-900">{locker.user.full_name}</div>
                      <div className="text-sm text-gray-500">{locker.user.account_id}</div>
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getUserTypeBadge(locker.user.user_type)}`}>
                        {locker.user.user_type}
                      </span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    <div><strong>Started:</strong> {formatDateTime(locker.borrow_time)}</div>
                    <div className="text-orange-600 text-xs mt-1">
                      <i className="fas fa-clock mr-1"></i>
                      Still in use
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full ${getSeverityColor(locker.days_used)}`}>
                    {formatDuration(locker.hours_used)}
                  </span>
                  <div className="text-xs text-gray-500 mt-1">
                    ({locker.days_used} days)
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm">
                    <div className="font-semibold text-red-600">₱{locker.calculated_penalty.toFixed(2)}</div>
                    {locker.penalty !== locker.calculated_penalty && (
                      <div className="text-xs text-gray-500">
                        (Current: ₱{Number(locker.penalty).toFixed(2)})
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900">
                    {locker.user.email && (
                      <div className="truncate max-w-xs" title={locker.user.email}>
                        <i className="fas fa-envelope mr-1"></i>
                        {locker.user.email}
                      </div>
                    )}
                    {locker.user.contact_number && (
                      <div>
                        <i className="fas fa-phone mr-1"></i>
                        {locker.user.contact_number}
                      </div>
                    )}
                    {(locker.user.course || locker.user.department) && (
                      <div className="text-xs text-gray-500 mt-1">
                        {locker.user.course || locker.user.department}
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleProcessReturn(
                        locker.transaction_id,
                        locker.locker.locker_number,
                        locker.user.full_name
                      )}
                      disabled={processingId === locker.transaction_id}
                      className="text-green-600 hover:text-green-900 px-2 py-1 text-sm border border-green-600 hover:bg-green-50 rounded transition-colors disabled:opacity-50"
                      title="Process Return"
                    >
                      {processingId === locker.transaction_id ? (
                        <i className="fas fa-spinner fa-spin"></i>
                      ) : (
                        <i className="fas fa-check"></i>
                      )}
                    </button>
                    
                    {locker.user.email && (
                      <button
                        onClick={() => handleSendReminder(
                          locker.transaction_id,
                          locker.user.email!,
                          locker.user.full_name,
                          locker.locker.locker_number
                        )}
                        className="text-blue-600 hover:text-blue-900 px-2 py-1 text-sm border border-blue-600 hover:bg-blue-50 rounded transition-colors"
                        title="Send Reminder Email"
                      >
                        <i className="fas fa-envelope"></i>
                      </button>
                    )}

                    {locker.days_used > 7 && (
                      <button
                        onClick={() => handleForceReturn(
                          locker.transaction_id,
                          locker.locker.locker_number,
                          locker.user.full_name
                        )}
                        disabled={processingId === locker.transaction_id}
                        className="text-red-600 hover:text-red-900 px-2 py-1 text-sm border border-red-600 hover:bg-red-50 rounded transition-colors disabled:opacity-50"
                        title="Force Return (7+ days overdue)"
                      >
                        <i className="fas fa-exclamation-triangle"></i>
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {lockers.length > 0 && (
        <div className="bg-gray-50 px-6 py-3 text-sm text-gray-600 border-t">
          Showing {lockers.length} overdue locker{lockers.length !== 1 ? 's' : ''}
        </div>
      )}
    </div>
  )
}
