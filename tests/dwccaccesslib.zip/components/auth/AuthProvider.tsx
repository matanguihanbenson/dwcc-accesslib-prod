"use client"

import { useState, useEffect, ReactNode } from 'react'
import { useSession } from 'next-auth/react'
import { AuthContext, User, UserRole } from '@/lib/auth-context'

interface AuthProviderProps {
  children: ReactNode
}

export function AuthProvider({ children }: AuthProviderProps) {
  const { data: session, status } = useSession()
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchUserData() {
      if (session?.user?.username) {
        try {
          // Use the auth refresh API to get fresh user data from database
          const response = await fetch('/api/auth/refresh', {
            method: 'POST',
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json',
            },
          })
          
          if (response.ok) {
            const userData = await response.json()
            setUser({
              id: session.user.username,
              name: userData.name || session.user.name || 'Unknown',
              email: session.user.email || 'No email',
              role: (userData.role || session.user.role) as UserRole,
              avatar: userData.avatar || undefined,
            })
          } else {
            // Fallback to session data if refresh fails
            setUser({
              id: session.user.username,
              name: session.user.name || 'Unknown',
              email: session.user.email || 'No email',
              role: session.user.role as UserRole,
              avatar: undefined,
            })
          }
        } catch (error) {
          console.error('Failed to fetch fresh user data:', error)
          // Fallback to session data
          setUser({
            id: session.user.username,
            name: session.user.name || 'Unknown',
            email: session.user.email || 'No email',
            role: session.user.role as UserRole,
            avatar: undefined,
          })
        }
      }
      setLoading(false)
    }

    if (status === 'loading') {
      return
    }

    if (status === 'authenticated' && session) {
      fetchUserData()
    } else {
      setUser(null)
      setLoading(false)
    }
  }, [session, status])

  const signOut = async () => {
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}
