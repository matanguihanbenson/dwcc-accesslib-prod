import { UserRole, UserType, UserStatus, BookStatus, LockerStatus } from '@prisma/client'

// Core user types
export interface User {
  id: string
  name: string
  email?: string
  role: UserRole
  userType?: UserType
  username?: string
  accountId?: string
  avatar?: string | null
}

// Authentication types
export interface AuthUser extends User {
  username: string
  accountId: string
  userType: UserType
}

export interface AuthSession {
  user: AuthUser
  expires: string
}

// JWT payload type
export interface JWTPayload {
  userId: number
  username: string
  role: UserRole
  userType: UserType
  accountId: string
  iat?: number
  exp?: number
}

// API Response types
export interface ApiResponse<T = any> {
  data?: T
  message?: string
  error?: string
  success: boolean
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

// Database model types
export interface LibraryUser {
  user_id: number
  account_id: string
  full_name: string
  user_type: UserType
  course?: string
  department?: string
  year_level?: string
  email?: string
  rfid_code?: string
  purpose?: string
  contact_number?: string
  status: UserStatus
}

export interface UserAccount {
  id: number
  username: string
  role: UserRole
  last_login?: Date
  user_id: number
  created_at: Date
  updated_at?: Date
  is_active: boolean
  user: LibraryUser
}

export interface Book {
  book_id: number
  title: string
  book_author: string
  category: string
  status: BookStatus
}

export interface BookTransaction {
  transaction_id: number
  borrow_date: Date
  return_date?: Date
  due_date: Date
  penalty: number
  book_id: number
  user_id: number
  book: Book
  user: LibraryUser
}

// Component props types
export interface NavigationItem {
  name: string
  href: string
  icon: string
  roles: readonly UserRole[]
}

export interface UserInfo {
  name: string
  role: string
  initials: string
}

// Form types
export interface LoginCredentials {
  username: string
  password: string
}

export interface CreateUserData {
  full_name: string
  account_id: string
  user_type: UserType
  course?: string
  department?: string
  year_level?: string
  email?: string
  contact_number?: string
}

export interface CreateUserAccountData {
  username: string
  password: string
  role: UserRole
  user_data: CreateUserData
}

// Service response types
export interface ServiceResult<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// Error types
export interface AppError extends Error {
  code?: string
  statusCode?: number
  details?: any
}

// Environment types
export interface AppConfig {
  DATABASE_URL: string
  JWT_SECRET: string
  NEXTAUTH_SECRET: string
  NEXTAUTH_URL: string
  NODE_ENV: 'development' | 'production' | 'test'
}

// Re-export Prisma enums
export { UserRole, UserType, UserStatus, BookStatus, LockerStatus }
